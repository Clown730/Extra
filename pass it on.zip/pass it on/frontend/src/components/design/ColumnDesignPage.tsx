import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { ChevronDown, Play, Download, Check, Settings, Plus, Trash2, Search, AlertTriangle, X } from "lucide-react";
import type { EtabsInstance, ColumnDesignRow, ColumnPmmRow, SkippedColumnEntry } from "@/types/electron";
import IcosahedronLoader from "@/components/ui/IcosahedronLoader";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface ColumnDesignPageProps {
  categoryColor: string;
  onBack: () => void;
  className?: string;
}

type Tab = "Section Details" | "Reinforcement Ratio" | "Detailing";
type SolutionType = "s1" | "s2";
type DesignStateKey = "story-s1" | "story-s2" | "column-s1" | "column-s2";
const ALL_STATE_KEYS: DesignStateKey[] = ["story-s1", "story-s2", "column-s1", "column-s2"];

interface GroupRange {
  id: string;
  min: number;
  max: number | null; // null = infinity (> min)
}

interface StoryBand {
  id: string;
  fromStory: string;
  toStory: string;
}

interface ColumnDetailData {
  columnLabel: string;
  story: string;
  requiredAs: number;
  providedAs: number;
  numBars: number;
  mainDia: number;
  cornerDia: number;
  barsWidth: number;
  barsDepth: number;
  requiredV: number;
  providedV: number;
  stirrupDia: number;
  stirrupSpacing: number;
  numRings: number;
  cover: number;
  isModified: boolean;
}

interface SubDetail {
  id: string;
  name: string;
  columnLabels: string[];
  story: string;
}

interface SubDetailParams {
  barsWidth: number;
  barsDepth: number;
  mainDia: number;
  cornerDia: number;
  cover: number;
  stirrupDia: number;
  stirrupSpacing: number;
  numRings: number;
}

interface ColumnGroupStoryData {
  story: string;
  maxRequiredAs: number;
  maxRequiredShear: number;
  provided: number;
  ratio: number;
}

interface ColumnGroup {
  displayId: string;
  rangeLabel: string;
  groupKey: string;
  columns: Array<{ label: string; pmmRatio: number; row: ColumnDesignRow }>;
  maxRequiredAs: number;
  maxRequiredShear: number;
  provided: number;
  ratio: number;
  storyData?: ColumnGroupStoryData[]; // only for "Based on Column"
}

// ── Helper: Group by section ──────────────────────────────────────────────────
const groupBySection = (rows: ColumnDesignRow[]) => {
  const map = new Map<string, ColumnDesignRow[]>();
  for (const r of rows) {
    const key = `${r.sectionName} (${r.width}x${r.depth})`;
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(r);
  }
  return map;
};

const bestSolution = (r: ColumnDesignRow): string => {
  if (r.s1) return `1-s${r.s1}`;
  if (r.s2) return `2-s${r.s2}`;
  if (r.s3a) return `3-s${r.s3a}`;
  return "Custom";
};

// ── Detailing helpers ─────────────────────────────────────────────────────────
const getRatioColor = (ratio: number): string => {
  if (ratio < 1) return '#ef4444';
  if (ratio < 1.5) return '#16a34a';
  return '#3b82f6';
};

const BAR_DIAMETERS = [8, 10, 12, 16, 20, 25, 32, 40];
const SOLUTION_DIAMETERS = [8, 12, 16, 20, 25, 32, 40];
const barArea = (dia: number) => Math.PI * (dia / 2) ** 2;

// Solution 1: all bars same diameter — find smallest dia where numBars*area >= requiredAs
const solveS1 = (numBars: number, requiredAs: number, maxDia = 40, minDia = 0): { mainDia: number; cornerDia: number } => {
  const pool = SOLUTION_DIAMETERS.filter(d => d >= minDia && d <= maxDia);
  const effective = pool.length > 0 ? pool : SOLUTION_DIAMETERS;
  for (const dia of effective) {
    if (numBars * barArea(dia) >= requiredAs) return { mainDia: dia, cornerDia: dia };
  }
  const max = effective[effective.length - 1];
  return { mainDia: max, cornerDia: max };
};

// Solution 2: 4 corner bars can differ — main bars at most 2 sizes smaller than corner
// Finds smallest total area that satisfies requiredAs
const solveS2 = (numBars: number, requiredAs: number, maxDia = 40, minDia = 0): { mainDia: number; cornerDia: number } => {
  const pool = SOLUTION_DIAMETERS.filter(d => d >= minDia && d <= maxDia);
  const effective = pool.length > 0 ? pool : SOLUTION_DIAMETERS;
  const numMain = Math.max(0, numBars - 4);
  for (let ci = 0; ci < effective.length; ci++) {
    const cornerDia = effective[ci];
    // valid main diameters: same as corner or up to 2 sizes smaller
    const validMain = effective.slice(Math.max(0, ci - 2), ci + 1).reverse();
    for (const mainDia of validMain) {
      const area = 4 * barArea(cornerDia) + numMain * barArea(mainDia);
      if (area >= requiredAs) return { mainDia, cornerDia };
    }
  }
  const max = effective[effective.length - 1];
  return { mainDia: max, cornerDia: max };
};

const calcBarsPerFace = (width: number, depth: number) => {
  const barsWidth = Math.max(2, Math.floor(width / 100));
  const barsDepth = Math.max(2, Math.floor(depth / 100));
  return { barsWidth, barsDepth };
};

const parseBarDias = (s?: string): { mainDia: number; cornerDia?: number } => {
  if (!s) return { mainDia: 16 };
  const two = s.match(/\d+[×xX]?[Øø](\d+)[+]\d+[×xX]?[Øø](\d+)/i);
  if (two) return { cornerDia: parseInt(two[1]), mainDia: parseInt(two[2]) };
  const one = s.match(/[Øø](\d+)/i);
  if (one) return { mainDia: parseInt(one[1]) };
  return { mainDia: 16 };
};

// ── Shear solver ─────────────────────────────────────────────────────────────
const SHEAR_DIAS = [8, 10, 12, 16, 20];
const SHEAR_SPACINGS = [200, 175, 150, 125, 100, 75];

// Count all possible rings (both Set A + Set B) without needing SVG coords
const countMaxRings = (barsWidth: number, barsDepth: number): number => {
  let c = 1; // outer
  for (let i = 2; ; i++) { const jL = 2*i-1, jR = barsWidth-2*(i-1); if (jL >= jR) break; c++; }
  for (let i = 1; ; i++) { const jL = 2*i,   jR = barsWidth-2*i+1;   if (jL >= jR) break; c++; }
  for (let i = 2; ; i++) { const jT = 2*i-1, jB = barsDepth-2*(i-1); if (jT >= jB) break; c++; }
  for (let i = 1; ; i++) { const jT = 2*i,   jB = barsDepth-2*i+1;   if (jT >= jB) break; c++; }
  return c;
};

// Minimum shear solution: dia→rings→spacing tried in order (smallest first)
const solveShear = (
  shearReq: number, maxRings: number,
): { dia: number; nRings: number; spacing: number; provided: number } | null => {
  if (shearReq <= 0) return { dia: 8, nRings: 1, spacing: 200, provided: 0 };
  for (const dia of SHEAR_DIAS) {
    for (let nRings = 1; nRings <= maxRings; nRings++) {
      const legs = 2 * nRings;
      for (const spacing of SHEAR_SPACINGS) {
        const provided = (legs * barArea(dia) * 1000) / spacing;
        if (provided >= shearReq) return { dia, nRings, spacing, provided };
      }
    }
  }
  return null;
};

// Compute ring rectangles for SVG drawing.
// Ring 1 = outer perimeter (full width × full depth).
// Width inner rings: span FULL depth, shrink width only.
//   Set A (odd-start):  jL = 3,5,...       jR = nW-2, nW-4,...
//   Set B (even-start): jL = 2,4,...        jR = nW-1, nW-3,...
// Depth inner rings: span FULL width, shrink depth only (same two sets).
// Larger dimension goes first. Max rings ≈ 2×floor((nW-1)/2) + 2×floor((nD-1)/2) - 1.
const computeRings = (
  barsWidth: number, barsDepth: number,
  ox: number, oy: number, cW: number, cH: number, cornerOff: number,
): { x: number; y: number; w: number; h: number }[] => {
  if (barsWidth < 2 || barsDepth < 2) return [];
  const bsW = (cW - 2 * cornerOff) / Math.max(1, barsWidth - 1);
  const bsD = (cH - 2 * cornerOff) / Math.max(1, barsDepth - 1);

  const outerX = ox + cornerOff;
  const outerY = oy + cornerOff;
  const outerW = cW - 2 * cornerOff;
  const outerH = cH - 2 * cornerOff;

  const rings: { x: number; y: number; w: number; h: number }[] = [];
  rings.push({ x: outerX, y: outerY, w: outerW, h: outerH }); // Ring 1: outer

  const widthInner: { x: number; y: number; w: number; h: number }[] = [];
  for (let i = 2; ; i++) {                       // Set A: jL = 2i-1
    const jL = 2 * i - 1, jR = barsWidth - 2 * (i - 1);
    if (jL >= jR) break;
    widthInner.push({ x: ox + cornerOff + (jL - 1) * bsW, y: outerY, w: (jR - jL) * bsW, h: outerH });
  }
  for (let i = 1; ; i++) {                       // Set B: jL = 2i
    const jL = 2 * i, jR = barsWidth - 2 * i + 1;
    if (jL >= jR) break;
    widthInner.push({ x: ox + cornerOff + (jL - 1) * bsW, y: outerY, w: (jR - jL) * bsW, h: outerH });
  }

  const depthInner: { x: number; y: number; w: number; h: number }[] = [];
  for (let i = 2; ; i++) {                       // Set A: jT = 2i-1
    const jT = 2 * i - 1, jB = barsDepth - 2 * (i - 1);
    if (jT >= jB) break;
    depthInner.push({ x: outerX, y: oy + cornerOff + (jT - 1) * bsD, w: outerW, h: (jB - jT) * bsD });
  }
  for (let i = 1; ; i++) {                       // Set B: jT = 2i
    const jT = 2 * i, jB = barsDepth - 2 * i + 1;
    if (jT >= jB) break;
    depthInner.push({ x: outerX, y: oy + cornerOff + (jT - 1) * bsD, w: outerW, h: (jB - jT) * bsD });
  }

  // Larger dimension first
  if (barsDepth >= barsWidth) {
    rings.push(...depthInner, ...widthInner);
  } else {
    rings.push(...widthInner, ...depthInner);
  }
  return rings;
};

// ── Numeric input that allows full editing (clearing, selecting all, retyping) ─
const NumericInput = ({
  value, onChange, min, max, className,
}: {
  value: number; onChange: (v: number) => void; min?: number; max?: number; className?: string;
}) => {
  const [raw, setRaw] = useState(String(value));
  // Keep in sync when parent changes value (e.g. clamping from maxRings)
  useEffect(() => { setRaw(String(value)); }, [value]);

  return (
    <input
      type="text"
      inputMode="numeric"
      value={raw}
      className={className}
      onChange={e => {
        setRaw(e.target.value);
        const v = parseInt(e.target.value, 10);
        if (!isNaN(v)) {
          const inRange = (min === undefined || v >= min) && (max === undefined || v <= max);
          if (inRange) onChange(v);
        }
      }}
      onBlur={() => {
        const v = parseInt(raw, 10);
        if (isNaN(v) || (min !== undefined && v < min) || (max !== undefined && v > max)) {
          const clamped = isNaN(v) ? (min ?? value) : min !== undefined && v < min ? min : max !== undefined && v > max ? max : v;
          setRaw(String(clamped));
          onChange(clamped);
        } else {
          setRaw(String(v));
        }
      }}
    />
  );
};

// ── Check Detail Popup ────────────────────────────────────────────────────────
const parseDiaFromSizeName = (name?: string): number => {
  if (!name) return 0;
  const m = name.match(/(\d+)/);
  return m ? parseInt(m[1]) : 0;
};

// Format bar size with T-prefix (e.g. "20" → "T20", "Ø20" → "T20")
const formatBarWithT = (barSize?: string): string => {
  if (!barSize) return '—';
  const m = barSize.match(/[Øø](\d+)/i) ?? barSize.match(/^(\d+)$/);
  return m ? `T${m[1]}` : barSize;
};

// Compute provided steel area from ETABS-assigned check bar data
const computeCheckProvidedAs = (r: ColumnDesignRow): number => {
  const mDia = parseDiaFromSizeName(r.checkLongBarSize) || 16;
  const cDia = parseDiaFromSizeName(r.checkCornerBarSize) || mDia;
  const { barsWidth, barsDepth } = calcBarsPerFace(r.width, r.depth);
  const total = Math.max(4, 2 * barsWidth + 2 * barsDepth - 4);
  return 4 * barArea(cDia) + Math.max(0, total - 4) * barArea(mDia);
};

const CheckDetailPopup = ({ row, onClose }: { row: ColumnDesignRow; onClose: () => void }) => {
  const mainDia    = parseDiaFromSizeName(row.checkLongBarSize)   || 16;
  const cornerDia  = parseDiaFromSizeName(row.checkCornerBarSize) || mainDia;
  const stirrupDia = parseDiaFromSizeName(row.checkTieBarSize)    || 8;
  const { barsWidth, barsDepth } = calcBarsPerFace(row.width, row.depth);

  const canvasSize = 300;
  const pad = 22;
  const { width, depth } = row;
  const sc  = width > 0 && depth > 0 ? Math.min((canvasSize - 2 * pad) / width, (canvasSize - 2 * pad) / depth) : 1;
  const cW  = width * sc, cH = depth * sc;
  const ox  = (canvasSize - cW) / 2, oy = (canvasSize - cH) / 2;
  const stirrupW = Math.max(1.5, stirrupDia * sc);
  const cornerOff = (40 + stirrupDia + cornerDia / 2) * sc;
  const mainOff   = (40 + stirrupDia + mainDia   / 2) * sc;
  const numRings  = Math.max(1, Math.ceil(Math.max(row.checkNumTies2Dir ?? 0, row.checkNumTies3Dir ?? 0) / 2));
  const ringRects = computeRings(barsWidth, barsDepth, ox, oy, cW, cH, cornerOff).slice(0, numRings);

  const cornerR = Math.max(2.5, (cornerDia / 2) * sc);
  const sideR   = Math.max(2,   (mainDia   / 2) * sc);
  const svgBars: { x: number; y: number; r: number; isCorner: boolean }[] = [
    { x: ox + cornerOff,      y: oy + cornerOff,      r: cornerR, isCorner: true },
    { x: ox + cW - cornerOff, y: oy + cornerOff,      r: cornerR, isCorner: true },
    { x: ox + cornerOff,      y: oy + cH - cornerOff, r: cornerR, isCorner: true },
    { x: ox + cW - cornerOff, y: oy + cH - cornerOff, r: cornerR, isCorner: true },
  ];
  if (barsWidth > 2) {
    for (let i = 1; i <= barsWidth - 2; i++) {
      const t = i / (barsWidth - 1);
      const x = ox + cornerOff + t * (cW - 2 * cornerOff);
      svgBars.push({ x, y: oy + mainOff,      r: sideR, isCorner: false });
      svgBars.push({ x, y: oy + cH - mainOff, r: sideR, isCorner: false });
    }
  }
  if (barsDepth > 2) {
    for (let i = 1; i <= barsDepth - 2; i++) {
      const t = i / (barsDepth - 1);
      const y = oy + cornerOff + t * (cH - 2 * cornerOff);
      svgBars.push({ x: ox + mainOff,      y, r: sideR, isCorner: false });
      svgBars.push({ x: ox + cW - mainOff, y, r: sideR, isCorner: false });
    }
  }

  const field = (label: string, value: string | number | undefined) => (
    <div className="flex items-center justify-between gap-4 text-xs">
      <span style={{ color: 'rgba(255,255,255,0.55)' }}>{label}</span>
      <span className="font-mono font-semibold" style={{ color: '#fff' }}>{value || '—'}</span>
    </div>
  );

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={onClose}>
      <div className="border border-white/10 rounded-2xl shadow-2xl p-5 flex gap-5 max-w-[700px] w-full mx-4"
        style={{ background: '#1c1c24' }}
        onClick={e => e.stopPropagation()}>

        {/* Left: SVG cross-section */}
        <div className="flex flex-col items-center gap-2 shrink-0">
          <p className="text-xs font-semibold" style={{ color: '#fff' }}>{width} × {depth} mm</p>
          <svg width={canvasSize} height={canvasSize} className="rounded-xl border border-white/10"
            style={{ background: '#f0ede8' }}>
            <defs>
              <pattern id="hatch-chk" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)">
                <line x1="0" y1="0" x2="0" y2="6" stroke="#ccc" strokeWidth="0.8" />
              </pattern>
            </defs>
            <rect x={ox} y={oy} width={cW} height={cH} fill="url(#hatch-chk)" stroke="#333" strokeWidth={1.5} />
            {ringRects.map((r, i) => (
              <rect key={i} x={r.x} y={r.y} width={r.w} height={r.h}
                fill="none" stroke="#1a1a1a" strokeWidth={stirrupW} rx={stirrupW / 2} />
            ))}
            {svgBars.map((b, i) => (
              <g key={i}>
                <circle cx={b.x} cy={b.y} r={b.r + 0.6} fill="#999" />
                <circle cx={b.x} cy={b.y} r={b.r}        fill={b.isCorner ? '#1a1a1a' : '#444'} />
              </g>
            ))}
            <text x={ox + cW / 2} y={Math.max(10, oy - 5)} textAnchor="middle" fontSize={9} fill="#555">{width}</text>
            <text x={Math.max(8, ox - 8)} y={oy + cH / 2} textAnchor="middle" fontSize={9} fill="#555"
              transform={`rotate(-90,${Math.max(8, ox - 8)},${oy + cH / 2})`}>{depth}</text>
          </svg>
          <div className="text-[10px]" style={{ color: 'rgba(255,255,255,0.5)' }}>
            Total bars: <b style={{ color: '#fff' }}>{Math.max(4, 2 * barsWidth + 2 * barsDepth - 4)}</b>
          </div>
        </div>

        {/* Right: info panel */}
        <div className="flex flex-col gap-3 flex-1 min-w-[240px]">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm font-semibold" style={{ color: '#fff' }}>{row.label}</span>
              <span className="text-[10px] ml-2" style={{ color: 'rgba(255,255,255,0.45)' }}>{row.sectionName}</span>
            </div>
            <button onClick={onClose}
              className="w-6 h-6 rounded-full flex items-center justify-center hover:bg-white/10 transition-colors text-lg leading-none"
              style={{ color: 'rgba(255,255,255,0.5)' }}>×</button>
          </div>
          <p className="text-[10px] -mt-1.5" style={{ color: 'rgba(255,255,255,0.35)' }}>
            Story: {row.story} · ETABS Check Design
          </p>

          <div className="border-t pt-2.5 flex flex-col gap-2" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
            <p className="text-[10px] font-semibold uppercase tracking-wider mb-0.5" style={{ color: 'rgba(255,255,255,0.35)' }}>Assigned Reinforcement</p>
            {field('Longitudinal Bar Size', row.checkLongBarSize)}
            {field('Corner Bar Size',       row.checkCornerBarSize)}
            {field('Tie Bar Size',          row.checkTieBarSize)}
            {field('Tie Spacing (mm)',      row.checkTieSpacing)}
            {field('Number Ties 3-Dir',     row.checkNumTies3Dir)}
            {field('Number Ties 2-Dir',     row.checkNumTies2Dir)}
          </div>

          <div className="border-t pt-2.5 flex flex-col gap-2" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
            <p className="text-[10px] font-semibold uppercase tracking-wider mb-0.5" style={{ color: 'rgba(255,255,255,0.35)' }}>Section</p>
            {field('Dimensions',      `${row.width} × ${row.depth} mm`)}
            {field('Concrete',        `${row.concreteMaterial}  fc = ${row.fc} MPa`)}
            {field('Rebar Material',  `${row.flexureRebarMaterial}  fy = ${row.fy} MPa`)}
            {field('Required As',     `${row.requiredAs} mm²`)}
          </div>
        </div>
      </div>
    </div>
  );
};

// ── Check Design Popup (editable, with status + PMM + D/C) ───────────────────
const pmmRatioTextColor = (r: number) =>
  r <= 0 ? '#94a3b8' : r < 0.8 ? '#16a34a' : r < 1.0 ? '#d97706' : '#ef4444';

const CheckDesignPopup = ({
  row, pmmRatio, initialParams, initialStatus,
  onSave, onStatusChange, onClose,
}: {
  row: ColumnDesignRow;
  pmmRatio: number;
  initialParams?: SubDetailParams;
  initialStatus?: 'untouched' | 'hold' | 'done';
  onSave: (key: string, params: SubDetailParams, flexProv: number) => void;
  onStatusChange: (key: string, status: 'untouched' | 'hold' | 'done') => void;
  onClose: () => void;
}) => {
  const cellKey = `${row.story}|${row.label}`;

  // Defaults from ETABS check data — only used when no saved params exist
  const etabsMainDia   = parseDiaFromSizeName(row.checkLongBarSize)   || 16;
  const etabsCornerDia = parseDiaFromSizeName(row.checkCornerBarSize) || etabsMainDia;
  const etabsTieDia    = parseDiaFromSizeName(row.checkTieBarSize)    || 8;
  const { barsWidth: etabsBW, barsDepth: etabsBD } = calcBarsPerFace(row.width, row.depth);
  const etabsSpacing   = row.checkTieSpacing || 200;
  const etabsNumRings  = Math.max(1, Math.ceil(Math.max(row.checkNumTies2Dir ?? 0, row.checkNumTies3Dir ?? 0) / 2));

  const seed = initialParams ?? {
    barsWidth: etabsBW, barsDepth: etabsBD, mainDia: etabsMainDia,
    cornerDia: etabsCornerDia, cover: 40, stirrupDia: etabsTieDia,
    stirrupSpacing: etabsSpacing, numRings: etabsNumRings,
  };

  const [barsWidth,      setBarsWidth]      = useState(seed.barsWidth);
  const [barsDepth,      setBarsDepth]      = useState(seed.barsDepth);
  const [mainDia,        setMainDia]        = useState(seed.mainDia);
  const [cornerDia,      setCornerDia]      = useState(seed.cornerDia);
  const [cover,          setCover]          = useState(seed.cover);
  const [stirrupDia,     setStirrupDia]     = useState(seed.stirrupDia);
  const [stirrupSpacing, setStirrupSpacing] = useState(seed.stirrupSpacing);
  const [numRings,       setNumRings]       = useState(seed.numRings);
  const [status, setStatus] = useState<'untouched' | 'hold' | 'done'>(initialStatus ?? 'untouched');

  const totalBars   = Math.max(4, 2 * barsWidth + 2 * barsDepth - 4);
  const providedArea = 4 * barArea(cornerDia) + Math.max(0, totalBars - 4) * barArea(mainDia);
  const dcRatio     = row.requiredAs > 0 ? providedArea / row.requiredAs : 0;

  const canvasSize = 300; const pad = 22;
  const { width, depth } = row;
  const sc  = Math.min((canvasSize - 2 * pad) / width, (canvasSize - 2 * pad) / depth);
  const cW  = width * sc, cH = depth * sc;
  const ox  = (canvasSize - cW) / 2, oy = (canvasSize - cH) / 2;
  const stirrupW  = Math.max(1.5, stirrupDia * sc);
  const cornerOff = (cover + stirrupDia + cornerDia / 2) * sc;
  const mainOff   = (cover + stirrupDia + mainDia   / 2) * sc;

  const ringRects = computeRings(barsWidth, barsDepth, ox, oy, cW, cH, cornerOff);
  const maxRings  = Math.max(1, ringRects.length);
  useEffect(() => { setNumRings(prev => Math.min(prev, maxRings)); }, [maxRings]);
  const activeRings = ringRects.slice(0, numRings);
  const legs      = 2 * numRings;
  const shearProv = stirrupSpacing > 0 ? (legs * barArea(stirrupDia) * 1000) / stirrupSpacing : 0;

  // Live-save to parent so main table updates as user edits
  const onSaveRef = useRef(onSave);
  useEffect(() => { onSaveRef.current = onSave; });
  useEffect(() => {
    onSaveRef.current(cellKey, { barsWidth, barsDepth, mainDia, cornerDia, cover, stirrupDia, stirrupSpacing, numRings }, providedArea);
  }, [cellKey, barsWidth, barsDepth, mainDia, cornerDia, cover, stirrupDia, stirrupSpacing, numRings, providedArea]);

  const handleClose = () => {
    onSave(cellKey, { barsWidth, barsDepth, mainDia, cornerDia, cover, stirrupDia, stirrupSpacing, numRings }, providedArea);
    onClose();
  };

  const handleStatus = (s: 'untouched' | 'hold' | 'done') => {
    setStatus(s);
    onStatusChange(cellKey, s);
  };

  const STATUS_CFG_LOCAL = {
    untouched: { label: 'Untouched', bg: 'transparent',  text: 'rgba(255,255,255,0.35)', border: 'rgba(255,255,255,0.15)' },
    hold:      { label: 'Hold',      bg: '#422006',       text: '#fcd34d',               border: '#92400e' },
    done:      { label: 'Done',      bg: '#052e16',       text: '#4ade80',               border: '#166534' },
  };

  const cornerR = Math.max(2.5, (cornerDia / 2) * sc);
  const sideR   = Math.max(2,   (mainDia   / 2) * sc);
  const svgBars: { x: number; y: number; r: number; isCorner: boolean }[] = [
    { x: ox + cornerOff,      y: oy + cornerOff,      r: cornerR, isCorner: true },
    { x: ox + cW - cornerOff, y: oy + cornerOff,      r: cornerR, isCorner: true },
    { x: ox + cornerOff,      y: oy + cH - cornerOff, r: cornerR, isCorner: true },
    { x: ox + cW - cornerOff, y: oy + cH - cornerOff, r: cornerR, isCorner: true },
  ];
  if (barsWidth > 2) {
    for (let i = 1; i <= barsWidth - 2; i++) {
      const t = i / (barsWidth - 1);
      const x = ox + cornerOff + t * (cW - 2 * cornerOff);
      svgBars.push({ x, y: oy + mainOff,      r: sideR, isCorner: false });
      svgBars.push({ x, y: oy + cH - mainOff, r: sideR, isCorner: false });
    }
  }
  if (barsDepth > 2) {
    for (let i = 1; i <= barsDepth - 2; i++) {
      const t = i / (barsDepth - 1);
      const y = oy + cornerOff + t * (cH - 2 * cornerOff);
      svgBars.push({ x: ox + mainOff,      y, r: sideR, isCorner: false });
      svgBars.push({ x: ox + cW - mainOff, y, r: sideR, isCorner: false });
    }
  }

  const inputCls  = "w-16 h-7 px-2 text-xs font-mono text-center rounded outline-none border focus:border-white/40 bg-white/10 border-white/20 text-white";
  const selectCls = "w-16 h-7 px-1 text-xs font-mono rounded outline-none border bg-[#2a2a36] border-white/20 text-white";
  const infoRow   = (label: string, value: string | number | undefined) => (
    <div className="flex items-center justify-between gap-4 text-xs">
      <span style={{ color: 'rgba(255,255,255,0.55)' }}>{label}</span>
      <span className="font-mono font-semibold" style={{ color: '#fff' }}>{value || '—'}</span>
    </div>
  );

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={handleClose}>
      <div className="border border-white/10 rounded-2xl shadow-2xl p-5 flex gap-5 max-w-[900px] w-full mx-4 max-h-[92vh]"
        style={{ background: '#1c1c24' }}
        onClick={e => e.stopPropagation()}>

        {/* Left: SVG cross-section */}
        <div className="flex flex-col items-center gap-2 shrink-0">
          <p className="text-xs font-semibold" style={{ color: '#fff' }}>{width} × {depth} mm</p>
          <svg width={canvasSize} height={canvasSize} className="rounded-xl border border-white/10"
            style={{ background: '#f0ede8' }}>
            <defs>
              <pattern id="hatch-chkd" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)">
                <line x1="0" y1="0" x2="0" y2="6" stroke="#ccc" strokeWidth="0.8" />
              </pattern>
            </defs>
            <rect x={ox} y={oy} width={cW} height={cH} fill="url(#hatch-chkd)" stroke="#333" strokeWidth={1.5} />
            {activeRings.map((r, i) => (
              <rect key={i} x={r.x} y={r.y} width={r.w} height={r.h}
                fill="none" stroke="#1a1a1a" strokeWidth={stirrupW} rx={stirrupW / 2} />
            ))}
            {svgBars.map((b, i) => (
              <g key={i}>
                <circle cx={b.x} cy={b.y} r={b.r + 0.6} fill="#999" />
                <circle cx={b.x} cy={b.y} r={b.r}        fill={b.isCorner ? '#1a1a1a' : '#444'} />
              </g>
            ))}
            <text x={ox + cW / 2} y={Math.max(10, oy - 5)} textAnchor="middle" fontSize={9} fill="#555">{width}</text>
            <text x={Math.max(8, ox - 8)} y={oy + cH / 2} textAnchor="middle" fontSize={9} fill="#555"
              transform={`rotate(-90,${Math.max(8, ox - 8)},${oy + cH / 2})`}>{depth}</text>
          </svg>
          <div className="text-[10px] flex gap-3" style={{ color: 'rgba(255,255,255,0.6)' }}>
            <span>Bars: <b style={{ color: '#fff' }}>{totalBars}</b></span>
            <span>A<sub>prov</sub>: <b style={{ color: '#fff' }}>{providedArea.toFixed(0)} mm²</b></span>
          </div>
          {/* Ratio summary */}
          <div className="w-full rounded-lg px-3 py-2 flex flex-col gap-1.5"
            style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div className="flex items-center justify-between text-[11px]">
              <span style={{ color: 'rgba(255,255,255,0.45)' }}>ETABS PMM Ratio</span>
              <span className="font-mono font-bold" style={{ color: pmmRatioTextColor(pmmRatio) }}>
                {pmmRatio > 0 ? pmmRatio.toFixed(3) : '—'}
              </span>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span style={{ color: 'rgba(255,255,255,0.45)' }}>D/C (prov/req)</span>
              <span className="font-mono font-bold" style={{ color: getRatioColor(dcRatio) }}>
                {dcRatio > 0 ? `${dcRatio.toFixed(3)} ${dcRatio >= 1 ? '✓' : '✗'}` : '—'}
              </span>
            </div>
          </div>
        </div>

        {/* Right: edit panel */}
        <div className="flex flex-col gap-2.5 flex-1 min-w-[300px] overflow-y-auto"
          style={{ maxHeight: 'min(780px, 85vh)' }}>
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm font-semibold" style={{ color: '#fff' }}>{row.label}</span>
              <span className="text-[10px] ml-2" style={{ color: 'rgba(255,255,255,0.5)' }}>{row.sectionName}</span>
            </div>
            <button onClick={handleClose}
              className="w-6 h-6 rounded-full flex items-center justify-center hover:bg-white/10 transition-colors text-lg leading-none"
              style={{ color: 'rgba(255,255,255,0.5)' }}>×</button>
          </div>
          <p className="text-[10px] -mt-1.5" style={{ color: 'rgba(255,255,255,0.35)' }}>
            Story: {row.story} · ETABS Check Design
          </p>

          {/* Status buttons */}
          <div className="flex gap-2 flex-wrap -mt-0.5">
            {(['untouched', 'hold', 'done'] as const).map(s => (
              <button key={s} onClick={() => handleStatus(s)}
                className="text-[10px] font-semibold px-2.5 py-1 rounded-full border transition-all"
                style={{
                  background:   status === s ? STATUS_CFG_LOCAL[s].bg     : 'transparent',
                  color:        status === s ? STATUS_CFG_LOCAL[s].text   : 'rgba(255,255,255,0.3)',
                  borderColor:  status === s ? STATUS_CFG_LOCAL[s].border : 'rgba(255,255,255,0.1)',
                }}>
                {STATUS_CFG_LOCAL[s].label}
              </button>
            ))}
          </div>

          {/* Longitudinal reinforcement */}
          <div className="border-t pt-2.5 flex flex-col gap-2" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
            <p className="text-[10px] font-semibold uppercase tracking-wider mb-0.5"
              style={{ color: 'rgba(255,255,255,0.35)' }}>Longitudinal Reinforcement</p>
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-1.5 text-xs" style={{ color: 'rgba(255,255,255,0.55)' }}>
                <span>Bars W</span>
                <NumericInput value={barsWidth} onChange={setBarsWidth} min={2} max={20} className={inputCls} />
              </div>
              <div className="flex items-center gap-1.5 text-xs" style={{ color: 'rgba(255,255,255,0.55)' }}>
                <span>Bars D</span>
                <NumericInput value={barsDepth} onChange={setBarsDepth} min={2} max={20} className={inputCls} />
              </div>
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-1.5 text-xs" style={{ color: 'rgba(255,255,255,0.55)' }}>
                <span>Main Ø</span>
                <select value={mainDia} onChange={e => setMainDia(+e.target.value)} className={selectCls}>
                  {BAR_DIAMETERS.map(d => <option key={d} value={d}>T{d}</option>)}
                </select>
              </div>
              <div className="flex items-center gap-1.5 text-xs" style={{ color: 'rgba(255,255,255,0.55)' }}>
                <span>Corner Ø</span>
                <select value={cornerDia} onChange={e => setCornerDia(+e.target.value)} className={selectCls}>
                  {BAR_DIAMETERS.map(d => <option key={d} value={d}>T{d}</option>)}
                </select>
              </div>
              <div className="flex items-center gap-1.5 text-xs" style={{ color: 'rgba(255,255,255,0.55)' }}>
                <span>Cover</span>
                <NumericInput value={cover} onChange={setCover} min={20} max={80} className={inputCls} />
              </div>
            </div>
          </div>

          {/* Shear reinforcement */}
          <div className="border-t pt-2.5 flex flex-col gap-2" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
            <p className="text-[10px] font-semibold uppercase tracking-wider mb-0.5"
              style={{ color: 'rgba(255,255,255,0.35)' }}>Shear Reinforcement</p>
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-1.5 text-xs" style={{ color: 'rgba(255,255,255,0.55)' }}>
                <span>Tie Ø</span>
                <select value={stirrupDia} onChange={e => setStirrupDia(+e.target.value)} className={selectCls}>
                  {SHEAR_DIAS.map(d => <option key={d} value={d}>T{d}</option>)}
                </select>
              </div>
              <div className="flex items-center gap-1.5 text-xs" style={{ color: 'rgba(255,255,255,0.55)' }}>
                <span>Spacing</span>
                <select value={stirrupSpacing} onChange={e => setStirrupSpacing(+e.target.value)} className={selectCls}>
                  {SHEAR_SPACINGS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="flex items-center gap-1.5 text-xs" style={{ color: 'rgba(255,255,255,0.55)' }}>
                <span>Rings</span>
                <NumericInput value={numRings} onChange={setNumRings} min={1} max={maxRings} className={inputCls} />
              </div>
            </div>
            <div className="text-[10px] font-mono" style={{ color: 'rgba(255,255,255,0.45)' }}>
              A<sub>v,prov</sub> = {shearProv.toFixed(1)} mm²/m
              {row.requiredVMinRebar > 0 && (
                <span className="ml-2" style={{ color: getRatioColor(shearProv / (row.requiredVMinRebar * 1000)) }}>
                  ({(shearProv / (row.requiredVMinRebar * 1000)).toFixed(2)}×)
                </span>
              )}
            </div>
          </div>

          {/* Section info */}
          <div className="border-t pt-2.5 flex flex-col gap-1.5" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
            <p className="text-[10px] font-semibold uppercase tracking-wider mb-0.5"
              style={{ color: 'rgba(255,255,255,0.35)' }}>Section</p>
            {infoRow('Dimensions',   `${row.width} × ${row.depth} mm`)}
            {infoRow('Concrete',     `${row.concreteMaterial}  fc = ${row.fc} MPa`)}
            {infoRow('Rebar',        `${row.flexureRebarMaterial}  fy = ${row.fy} MPa`)}
            {infoRow('Required As',  `${row.requiredAs} mm²`)}
          </div>
        </div>
      </div>
    </div>
  );
};

// ── Column Detail Popup ───────────────────────────────────────────────────────
type CellStatus = 'untouched' | 'hold' | 'done';
const STATUS_CFG: Record<CellStatus, { label: string; bg: string; text: string; border: string }> = {
  untouched: { label: 'Untouched', bg: 'transparent',  text: 'rgba(255,255,255,0.35)', border: 'rgba(255,255,255,0.15)' },
  hold:      { label: 'Hold',      bg: '#422006',       text: '#fcd34d',               border: '#92400e' },
  done:      { label: 'Done',      bg: '#052e16',       text: '#4ade80',               border: '#166534' },
};

const ColumnDetailPopup = ({
  group, story, allColumns, solutionType, onUpdate, onStatusChange, onClose,
  fullGroup, subDetails, activeSubDetailId, onSelectSubDetail, onAddSubDetail, onDeleteSubDetail,
  initialParams, onParamsChange, maxDia, minDia,
}: {
  group: ColumnGroup;
  story: string;
  allColumns: ColumnDesignRow[];
  solutionType: SolutionType;
  onUpdate: (groupId: string, story: string, data: { flexProv: number; shearProv: number }) => void;
  onStatusChange: (groupId: string, story: string, status: CellStatus) => void;
  onClose: () => void;
  fullGroup?: ColumnGroup;
  subDetails?: SubDetail[];
  activeSubDetailId?: string | null;
  onSelectSubDetail?: (id: string | null) => void;
  onAddSubDetail?: (labels: string[], id: string, story: string) => void;
  onDeleteSubDetail?: (id: string) => void;
  initialParams?: SubDetailParams;
  onParamsChange?: (params: SubDetailParams) => void;
  maxDia?: number;
  minDia?: number;
}) => {
  const govRow = (() => {
    const candidates: ColumnDesignRow[] = story
      ? allColumns.filter(c => c.story === story && group.columns.some(gc => gc.label === c.label))
      : group.columns.map(gc => gc.row);
    if (candidates.length === 0) return group.columns[0].row;
    return candidates.reduce((a, b) => a.requiredAs >= b.requiredAs ? a : b);
  })();

  // Pre-compute initial values (used only for useState initializers)
  const { barsWidth: initBW, barsDepth: initBD } = calcBarsPerFace(govRow.width, govRow.depth);
  const initTotalBars = Math.max(4, 2 * initBW + 2 * initBD - 4);
  const initParsed = solutionType === 's1'
    ? solveS1(initTotalBars, govRow.requiredAs, maxDia ?? 40, minDia ?? 0)
    : solveS2(initTotalBars, govRow.requiredAs, maxDia ?? 40, minDia ?? 0);
  const shearReq = govRow.requiredVMinRebar * 1000;
  const initSol = solveShear(shearReq, countMaxRings(initBW, initBD));

  // ── State ───────────────────────────────────────────────────────────────────
  const [barsWidth, setBarsWidth] = useState(() => initialParams?.barsWidth ?? initBW);
  const [barsDepth, setBarsDepth] = useState(() => initialParams?.barsDepth ?? initBD);
  const [mainDia, setMainDia] = useState(() => initialParams?.mainDia ?? initParsed.mainDia);
  const [cornerDia, setCornerDia] = useState(() => initialParams?.cornerDia ?? initParsed.cornerDia);
  const [cover, setCover] = useState(() => initialParams?.cover ?? 40);
  const [stirrupDia, setStirrupDia] = useState(() => initialParams?.stirrupDia ?? (initSol?.dia ?? 8));
  const [stirrupSpacing, setStirrupSpacing] = useState(() => initialParams?.stirrupSpacing ?? (initSol?.spacing ?? 200));
  const [numRings, setNumRings] = useState(() => initialParams?.numRings ?? (initSol?.nRings ?? 1));
  const [status, setStatus] = useState<CellStatus>('untouched');
  const isMounted = useRef(false);

  // ── Derived geometry ────────────────────────────────────────────────────────
  const totalBars = Math.max(4, 2 * barsWidth + 2 * barsDepth - 4);
  const providedArea = 4 * barArea(cornerDia) + Math.max(0, totalBars - 4) * barArea(mainDia);
  const ratio = govRow.requiredAs > 0 && providedArea > 0 ? providedArea / govRow.requiredAs : 0;

  const canvasSize = 300;
  const pad = 22;
  const { width, depth } = govRow;
  const sc = Math.min((canvasSize - 2 * pad) / width, (canvasSize - 2 * pad) / depth);
  const cW = width * sc, cH = depth * sc;
  const ox = (canvasSize - cW) / 2, oy = (canvasSize - cH) / 2;
  const stirrupW = Math.max(1.5, stirrupDia * sc);
  const cornerOff = (cover + stirrupDia + cornerDia / 2) * sc;
  const mainOff = (cover + stirrupDia + mainDia / 2) * sc;

  const ringRects = computeRings(barsWidth, barsDepth, ox, oy, cW, cH, cornerOff);
  const maxRings = Math.max(1, ringRects.length);
  useEffect(() => { setNumRings(prev => Math.min(prev, maxRings)); }, [maxRings]);

  const activeRings = ringRects.slice(0, numRings);
  const legs = 2 * numRings;
  const shearProv = stirrupSpacing > 0 ? (legs * barArea(stirrupDia) * 1000) / stirrupSpacing : 0;
  const shearRatio = shearReq > 0 && shearProv > 0 ? shearProv / shearReq : 0;

  useEffect(() => {
    onUpdate(group.displayId, story, { flexProv: providedArea, shearProv });
  }, [providedArea, shearProv]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!isMounted.current) { isMounted.current = true; return; }
    onParamsChange?.({ barsWidth, barsDepth, mainDia, cornerDia, cover, stirrupDia, stirrupSpacing, numRings });
  }, [barsWidth, barsDepth, mainDia, cornerDia, cover, stirrupDia, stirrupSpacing, numRings]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Handlers ────────────────────────────────────────────────────────────────
  const handleStatus = (s: CellStatus) => {
    setStatus(s);
    onStatusChange(group.displayId, story, s);
  };

  // ── SVG bars ────────────────────────────────────────────────────────────────
  const cornerR = Math.max(2.5, (cornerDia / 2) * sc);
  const sideR = Math.max(2, (mainDia / 2) * sc);
  const svgBars: { x: number; y: number; r: number; isCorner: boolean }[] = [
    { x: ox + cornerOff, y: oy + cornerOff, r: cornerR, isCorner: true },
    { x: ox + cW - cornerOff, y: oy + cornerOff, r: cornerR, isCorner: true },
    { x: ox + cornerOff, y: oy + cH - cornerOff, r: cornerR, isCorner: true },
    { x: ox + cW - cornerOff, y: oy + cH - cornerOff, r: cornerR, isCorner: true },
  ];
  if (barsWidth > 2) {
    for (let i = 1; i <= barsWidth - 2; i++) {
      const t = i / (barsWidth - 1);
      const x = ox + cornerOff + t * (cW - 2 * cornerOff);
      svgBars.push({ x, y: oy + mainOff, r: sideR, isCorner: false });
      svgBars.push({ x, y: oy + cH - mainOff, r: sideR, isCorner: false });
    }
  }
  if (barsDepth > 2) {
    for (let i = 1; i <= barsDepth - 2; i++) {
      const t = i / (barsDepth - 1);
      const y = oy + cornerOff + t * (cH - 2 * cornerOff);
      svgBars.push({ x: ox + mainOff, y, r: sideR, isCorner: false });
      svgBars.push({ x: ox + cW - mainOff, y, r: sideR, isCorner: false });
    }
  }

  const inputCls = "w-16 h-7 px-2 text-xs font-mono text-center rounded outline-none border focus:border-white/40"
    + " bg-white/10 border-white/20 text-white";
  const selectCls = "w-16 h-7 px-1 text-xs font-mono rounded outline-none border bg-[#2a2a36] border-white/20 text-white";

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={onClose}>
      <div className="border border-white/10 rounded-2xl shadow-2xl p-5 flex gap-5 max-w-[1020px] w-full mx-4 max-h-[92vh]"
        style={{ background: '#1c1c24' }}
        onClick={e => e.stopPropagation()}>

        {/* Left: SVG drawing */}
        <div className="flex flex-col items-center gap-2 shrink-0">
          <p className="text-xs font-semibold" style={{ color: '#fff' }}>{width} × {depth} mm</p>
          <svg width={canvasSize} height={canvasSize} className="rounded-xl border border-white/10"
            style={{ background: '#f0ede8' }}>
            <defs>
              <pattern id="hatch" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)">
                <line x1="0" y1="0" x2="0" y2="6" stroke="#ccc" strokeWidth="0.8" />
              </pattern>
            </defs>
            <rect x={ox} y={oy} width={cW} height={cH} fill="url(#hatch)" stroke="#333" strokeWidth={1.5} />
            {activeRings.map((r, i) => (
              <rect key={i} x={r.x} y={r.y} width={r.w} height={r.h}
                fill="none" stroke="#1a1a1a" strokeWidth={stirrupW} rx={stirrupW / 2} />
            ))}
            {svgBars.map((b, i) => (
              <g key={i}>
                <circle cx={b.x} cy={b.y} r={b.r + 0.6} fill="#999" />
                <circle cx={b.x} cy={b.y} r={b.r} fill={b.isCorner ? '#1a1a1a' : '#444'} />
              </g>
            ))}
            <text x={ox + cW / 2} y={Math.max(10, oy - 5)} textAnchor="middle" fontSize={9} fill="#555">{width}</text>
            <text x={Math.max(8, ox - 8)} y={oy + cH / 2} textAnchor="middle" fontSize={9} fill="#555"
              transform={`rotate(-90,${Math.max(8, ox - 8)},${oy + cH / 2})`}>{depth}</text>
          </svg>
          <div className="text-[10px] flex gap-3" style={{ color: 'rgba(255,255,255,0.6)' }}>
            <span>Bars: <b style={{ color: '#fff' }}>{totalBars}</b></span>
            <span>A<sub>prov</sub>: <b style={{ color: '#fff' }}>{providedArea.toFixed(0)} mm²</b></span>
          </div>
          <div className="text-sm font-bold" style={{ color: getRatioColor(ratio) }}>
            Ratio: {ratio.toFixed(3)} {ratio >= 1 ? '✓' : '✗'}
          </div>
        </div>

        {/* Right: Edit panel */}
        <div className="flex flex-col gap-2.5 flex-1 min-w-[300px] overflow-y-auto" style={{ maxHeight: 'min(780px, 85vh)' }}>
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm font-semibold" style={{ color: '#fff' }}>{group.displayId}</span>
              <span className="text-[10px] ml-2" style={{ color: 'rgba(255,255,255,0.5)' }}>{govRow.sectionName}</span>
            </div>
            <button onClick={onClose}
              className="w-6 h-6 rounded-full flex items-center justify-center hover:bg-white/10 transition-colors text-lg leading-none"
              style={{ color: 'rgba(255,255,255,0.5)' }}>×</button>
          </div>
          <p className="text-[10px] -mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>
            {story ? `Story: ${story} · ` : ''}PMM {group.rangeLabel}
          </p>

          {/* Status toggle */}
          <div className="flex gap-1.5">
            {(['untouched', 'hold', 'done'] as CellStatus[]).map(s => (
              <button key={s} onClick={() => handleStatus(s)}
                className="flex-1 py-1 rounded text-[10px] font-semibold border transition-colors"
                style={status === s
                  ? { background: STATUS_CFG[s].bg, color: STATUS_CFG[s].text, borderColor: STATUS_CFG[s].border }
                  : { background: 'transparent', color: 'rgba(255,255,255,0.3)', borderColor: 'rgba(255,255,255,0.1)' }}>
                {STATUS_CFG[s].label}
              </button>
            ))}
          </div>

          {/* Sub-detail selector */}
          {(subDetails && subDetails.length > 0) && (
            <div className="flex gap-1 flex-wrap">
              <button onClick={() => onSelectSubDetail?.(null)}
                className="px-2 py-0.5 rounded text-[10px] font-semibold border transition-colors"
                style={!activeSubDetailId
                  ? { background: 'rgba(255,255,255,0.15)', color: '#fff', borderColor: 'rgba(255,255,255,0.3)' }
                  : { background: 'transparent', color: 'rgba(255,255,255,0.4)', borderColor: 'rgba(255,255,255,0.1)' }}>
                Main
              </button>
              {subDetails.map(sd => (
                <div key={sd.id} className="flex items-center rounded border overflow-hidden"
                  style={activeSubDetailId === sd.id
                    ? { borderColor: 'rgba(255,255,255,0.3)' }
                    : { borderColor: 'rgba(255,255,255,0.1)' }}>
                  <button onClick={() => onSelectSubDetail?.(sd.id)}
                    className="px-2 py-0.5 text-[10px] font-semibold transition-colors"
                    style={activeSubDetailId === sd.id
                      ? { background: 'rgba(255,255,255,0.15)', color: '#fff' }
                      : { background: 'transparent', color: 'rgba(255,255,255,0.4)' }}>
                    {sd.name}
                  </button>
                  <button onClick={e => { e.stopPropagation(); onDeleteSubDetail?.(sd.id); }}
                    className="px-1 py-0.5 text-[10px] transition-colors hover:bg-red-500/30"
                    style={{ color: 'rgba(255,255,255,0.35)', borderLeft: '1px solid rgba(255,255,255,0.1)' }}>
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Bar Arrangement */}
          <div className="border-t pt-2 flex flex-col gap-2" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
            <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'rgba(255,255,255,0.4)' }}>Bar Arrangement</p>
            <label className="flex items-center justify-between gap-2 text-xs" style={{ color: '#fff' }}>
              <span>Bars (width face)</span>
              <NumericInput value={barsWidth} onChange={v => setBarsWidth(v)} min={2} className={inputCls} />
            </label>
            <label className="flex items-center justify-between gap-2 text-xs" style={{ color: '#fff' }}>
              <span>Bars (depth face)</span>
              <NumericInput value={barsDepth} onChange={v => setBarsDepth(v)} min={2} className={inputCls} />
            </label>
            <label className="flex items-center justify-between gap-2 text-xs" style={{ color: '#fff' }}>
              <span>Main bar Ø (mm)</span>
              <select value={mainDia} onChange={e => setMainDia(parseInt(e.target.value))} className={selectCls}>
                {BAR_DIAMETERS.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </label>
            <label className="flex items-center justify-between gap-2 text-xs" style={{ color: '#fff' }}>
              <span>Corner bar Ø (mm)</span>
              <select value={cornerDia} onChange={e => setCornerDia(parseInt(e.target.value))} className={selectCls}>
                {BAR_DIAMETERS.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </label>
          </div>

          {/* Confinement */}
          <div className="border-t pt-2 flex flex-col gap-2" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'rgba(255,255,255,0.4)' }}>Confinement</p>
              <span className="text-[9px] font-mono" style={{ color: shearRatio >= 1 ? '#4ade80' : '#f87171' }}>
                T{stirrupDia}@{stirrupSpacing} · {numRings}R · {legs}L
              </span>
            </div>
            <label className="flex items-center justify-between gap-2 text-xs" style={{ color: '#fff' }}>
              <span>Stirrup Ø (mm)</span>
              <select value={stirrupDia} onChange={e => setStirrupDia(parseInt(e.target.value))} className={selectCls}>
                {SHEAR_DIAS.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </label>
            <label className="flex items-center justify-between gap-2 text-xs" style={{ color: '#fff' }}>
              <span>Spacing (mm)</span>
              <NumericInput value={stirrupSpacing} onChange={v => setStirrupSpacing(v)} min={50} className={inputCls} />
            </label>
            <label className="flex items-center justify-between gap-2 text-xs" style={{ color: '#fff' }}>
              <span>Rings <span style={{ color: 'rgba(255,255,255,0.35)' }}>(max {maxRings})</span></span>
              <NumericInput value={numRings} onChange={v => setNumRings(v)} min={1} max={maxRings} className={inputCls} />
            </label>
            <label className="flex items-center justify-between gap-2 text-xs" style={{ color: '#fff' }}>
              <span>Clear cover (mm)</span>
              <NumericInput value={cover} onChange={v => setCover(v)} min={20} className={inputCls} />
            </label>
          </div>

          {/* Results */}
          <div className="border-t pt-2" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
            <p className="text-[10px] font-semibold uppercase tracking-wider mb-1.5" style={{ color: 'rgba(255,255,255,0.4)' }}>Results</p>
            <div className="rounded-lg px-3 py-2 flex flex-col gap-1" style={{ background: 'rgba(255,255,255,0.04)' }}>
              <div className="text-xs font-mono">
                <span style={{ color: 'rgba(255,255,255,0.4)' }}>F: </span>
                <span style={{ color: '#fff' }}>{govRow.requiredAs > 0 ? govRow.requiredAs.toFixed(0) : '—'}</span>
                <span style={{ color: 'rgba(255,255,255,0.3)' }}> / </span>
                <span style={{ color: '#fff' }}>{providedArea.toFixed(0)}</span>
                <span style={{ color: 'rgba(255,255,255,0.3)' }}> / </span>
                <span className="font-bold" style={{ color: getRatioColor(ratio) }}>{ratio.toFixed(2)}</span>
                <span className="ml-1" style={{ color: ratio >= 1 ? '#4ade80' : '#f87171' }}>{ratio >= 1 ? '✓' : '✗'}</span>
              </div>
              <div className="text-xs font-mono">
                <span style={{ color: 'rgba(255,255,255,0.4)' }}>S: </span>
                <span style={{ color: '#fff' }}>{shearReq > 0 ? shearReq.toFixed(0) : '—'}</span>
                <span style={{ color: 'rgba(255,255,255,0.3)' }}> / </span>
                <span style={{ color: '#fff' }}>{shearProv > 0 ? shearProv.toFixed(0) : '—'}</span>
                <span style={{ color: 'rgba(255,255,255,0.3)' }}> / </span>
                <span className="font-bold" style={{ color: shearRatio > 0 ? getRatioColor(shearRatio) : '#555' }}>{shearRatio > 0 ? shearRatio.toFixed(2) : '—'}</span>
                {shearRatio > 0 && <span className="ml-1" style={{ color: shearRatio >= 1 ? '#4ade80' : '#f87171' }}>{shearRatio >= 1 ? '✓' : '✗'}</span>}
              </div>
            </div>
          </div>

          {/* Columns in group — click any column to give it its own sub-detail */}
          <div className="border-t pt-2" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
            <p className="text-[10px] font-semibold uppercase tracking-wider mb-1.5" style={{ color: 'rgba(255,255,255,0.4)' }}>
              {(fullGroup ?? group).columns.length} Columns
              <span className="normal-case font-normal ml-1" style={{ color: 'rgba(255,255,255,0.25)' }}>— click to separate detail</span>
            </p>
            <div className="flex flex-col gap-0.5">
              {(fullGroup ?? group).columns.map(c => {
                const colRatio = providedArea > 0 && c.row.requiredAs > 0 ? providedArea / c.row.requiredAs : 0;
                const inSub = subDetails?.find(sd => sd.columnLabels.includes(c.label) && sd.story === story);
                const isActive = activeSubDetailId && inSub?.id === activeSubDetailId;
                return (
                  <div key={c.label}
                    className="flex items-center gap-1.5 px-1.5 py-0.5 rounded cursor-pointer select-none transition-colors hover:bg-white/10"
                    style={{ background: isActive ? 'rgba(255,255,255,0.12)' : 'transparent' }}
                    onClick={() => {
                      if (inSub) {
                        onSelectSubDetail?.(inSub.id);
                      } else {
                        const newId = `sub_${Date.now()}`;
                        onAddSubDetail?.([c.label], newId, story);
                        onSelectSubDetail?.(newId);
                      }
                    }}>
                    <span className="text-[10px] font-semibold w-10 shrink-0" style={{ color: '#fff' }}>{c.label}</span>
                    <span className="text-[9px]" style={{ color: 'rgba(255,255,255,0.35)' }}>PMM</span>
                    <span className="text-[9px] font-mono" style={{ color: getRatioColor(c.pmmRatio) }}>{c.pmmRatio.toFixed(2)}</span>
                    <span className="text-[9px]" style={{ color: 'rgba(255,255,255,0.2)' }}>·</span>
                    <span className="text-[9px]" style={{ color: 'rgba(255,255,255,0.35)' }}>Flex</span>
                    <span className="text-[9px] font-mono" style={{ color: colRatio > 0 ? getRatioColor(colRatio) : '#555' }}>{colRatio > 0 ? colRatio.toFixed(2) : '—'}</span>
                    <span className="ml-auto text-[8px] px-1 py-px rounded"
                      style={inSub
                        ? { background: 'rgba(255,255,255,0.12)', color: '#fff' }
                        : { background: 'transparent', color: 'rgba(255,255,255,0.2)' }}>
                      {inSub ? inSub.name : '+ sub'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ── Shared table components ───────────────────────────────────────────────────
const Td = ({ children, right = false, mono = false, accent = false, color }: {
  children: React.ReactNode; right?: boolean; mono?: boolean; accent?: boolean; color?: string;
}) => (
  <td className={cn(
    "px-3 py-2 text-xs whitespace-nowrap",
    right ? "text-right" : "text-left",
    mono  ? "font-mono" : "",
    accent ? "font-semibold font-mono" : "text-muted-foreground"
  )} style={accent ? { color: color || "#22c55e" } : {}}>
    {children}
  </td>
);

const Th = ({ children, right = false }: { children: React.ReactNode; right?: boolean }) => (
  <th className={cn(
    "px-3 py-2.5 text-[10px] font-semibold uppercase tracking-wider whitespace-nowrap sticky top-0 z-10",
    right ? "text-right" : "text-left",
    "bg-surface/90 backdrop-blur-md text-muted-foreground border-b border-border/40"
  )}>
    {children}
  </th>
);

const DEFAULT_GROUP_RANGES: GroupRange[] = [
  { id: "g1", min: 0.8, max: 1.0 },
  { id: "g2", min: 1.0, max: 1.2 },
  { id: "g3", min: 1.2, max: 1.5 },
  { id: "g4", min: 1.5, max: 2.0 },
  { id: "g5", min: 2.0, max: null },
];

interface GroupingCriteria {
  size: boolean;
  concreteGrade: boolean;
  flexureGrade: boolean;
  shearGrade: boolean;
  story: boolean;
}
const DEFAULT_CRITERIA: GroupingCriteria = {
  size: true, concreteGrade: true, flexureGrade: true, shearGrade: false, story: true,
};

// ── Pure grouping helpers (accept data directly) ──────────────────────────────
const computeStoryGroups = (
  story: string,
  ranges: GroupRange[],
  solType: SolutionType,
  colData: ColumnDesignRow[],
  pmmMap: Map<string, number>
): ColumnGroup[] => {
  const storyCols = colData.filter(r => r.story === story);
  const groups: ColumnGroup[] = [];
  let idx = 0;

  for (const range of ranges) {
    const inRange = storyCols.filter(col => {
      const ratio = pmmMap.get(`${col.story}|${col.label}`) ?? -1;
      if (ratio < range.min) return false;
      if (range.max !== null && ratio >= range.max) return false;
      return true;
    });
    if (inRange.length === 0) continue;

    const subMap = new Map<string, ColumnDesignRow[]>();
    for (const col of inRange) {
      const key = `${col.width}x${col.depth}|${col.fc}|${col.fy}`;
      if (!subMap.has(key)) subMap.set(key, []);
      subMap.get(key)!.push(col);
    }

    for (const [gKey, cols] of subMap) {
      idx++;
      const maxAs = Math.max(...cols.map(c => c.requiredAs));
      const maxShear = Math.max(...cols.map(c => c.requiredVMinRebar));
      const maxAsCol = cols.reduce((a, b) => a.requiredAs >= b.requiredAs ? a : b);
      const provided = solType === "s1" ? (maxAsCol.s1Area ?? 0) : (maxAsCol.s2Area ?? 0);
      const rangeLabel = range.max !== null ? `${range.min} – ${range.max}` : `> ${range.min}`;

      groups.push({
        displayId: `G${idx}`,
        rangeLabel,
        groupKey: gKey,
        columns: cols.map(c => ({
          label: c.label,
          pmmRatio: pmmMap.get(`${c.story}|${c.label}`) ?? 0,
          row: c,
        })),
        maxRequiredAs: maxAs,
        maxRequiredShear: maxShear,
        provided,
        ratio: provided > 0 ? provided / maxAs : 0,
      });
    }
  }
  return groups;
};

const computeColumnGroups = (
  ranges: GroupRange[],
  solType: SolutionType,
  colData: ColumnDesignRow[],
  pmmMap: Map<string, number>,
  allStories: string[],
  allLabels: string[],
  criteria: GroupingCriteria = DEFAULT_CRITERIA,
  storyBands: StoryBand[] = [],
  orderedStories: string[] = []
): ColumnGroup[] => {
  const groups: ColumnGroup[] = [];
  let idx = 0;

  const getPmmBandMin = (pmm: number): number => {
    for (const r of ranges) {
      if (pmm >= r.min && (r.max === null || pmm < r.max)) return r.min;
    }
    return -1;
  };

  // Compute sub-group key for a label (within its PMM range bucket)
  const getLabelSubKey = (label: string): string => {
    const labelStories = allStories.filter(s => colData.some(c => c.story === s && c.label === label));
    const parts: string[] = [];

    if (criteria.story) {
      // Map each story to its band key (or itself if not in any band), deduplicate
      const bandKeys = [...labelStories]
        .map(s => getStoryBandKey(s, storyBands, orderedStories.length > 0 ? orderedStories : allStories))
        .filter((v, i, a) => a.indexOf(v) === i)
        .sort();
      parts.push('S:' + bandKeys.join(','));
      // PMM band per band-key: use max pmm across all stories in the band
      const ord = orderedStories.length > 0 ? orderedStories : allStories;
      for (const bk of bandKeys) {
        const storiesInBand = getStoriesInBand(bk, storyBands, ord);
        const maxPmm = Math.max(...storiesInBand.map(s => pmmMap.get(`${s}|${label}`) ?? 0));
        parts.push(`${bk}~${getPmmBandMin(maxPmm)}`);
      }
    }

    // Per-story property criteria — one representative per band key
    const ord2 = orderedStories.length > 0 ? orderedStories : allStories;
    const relevantStories = criteria.story
      ? (() => {
          const seen = new Set<string>();
          return [...labelStories].filter(s => {
            const bk = getStoryBandKey(s, storyBands, ord2);
            if (seen.has(bk)) return false;
            seen.add(bk);
            return true;
          });
        })()
      : labelStories.slice(0, 1);
    for (const s of relevantStories) {
      const row = colData.find(c => c.story === s && c.label === label);
      if (!row) continue;
      const p: string[] = [];
      if (criteria.size) p.push(`${row.width}x${row.depth}`);
      if (criteria.concreteGrade) p.push(row.concreteMaterial);
      if (criteria.flexureGrade) p.push(row.flexureRebarMaterial);
      if (criteria.shearGrade) p.push(row.shearRebarMaterial ?? '');
      if (p.length > 0) parts.push(`${s}:[${p.join('/')}]`);
    }

    return parts.join('|');
  };

  // Helper: get effective PMM for a label (treat missing/no-data as 0)
  const getEffectivePmm = (label: string): number => {
    let maxPmm = -1;
    allStories.forEach(story => {
      const r = pmmMap.get(`${story}|${label}`);
      if (r !== undefined && r > maxPmm) maxPmm = r;
    });
    return maxPmm < 0 ? 0 : maxPmm;
  };

  const assignedLabels = new Set<string>();

  const pushGroup = (labels: string[], rangeLabel: string) => {
    const subMap = new Map<string, string[]>();
    for (const label of labels) {
      const key = getLabelSubKey(label);
      if (!subMap.has(key)) subMap.set(key, []);
      subMap.get(key)!.push(label);
    }
    for (const [, lbls] of subMap) {
      idx++;
      const storyData: ColumnGroupStoryData[] = allStories.map(story => {
        const sCols = colData.filter(c => c.story === story && lbls.includes(c.label));
        if (sCols.length === 0) return { story, maxRequiredAs: 0, maxRequiredShear: 0, provided: 0, ratio: 0 };
        const maxAs = Math.max(...sCols.map(c => c.requiredAs));
        const maxShear = Math.max(...sCols.map(c => c.requiredVMinRebar));
        const maxAsCol = sCols.reduce((a, b) => a.requiredAs >= b.requiredAs ? a : b);
        const provided = solType === "s1" ? (maxAsCol.s1Area ?? 0) : (maxAsCol.s2Area ?? 0);
        return { story, maxRequiredAs: maxAs, maxRequiredShear: maxShear, provided, ratio: provided > 0 ? provided / maxAs : 0 };
      });
      const overallMaxAs = Math.max(...storyData.map(d => d.maxRequiredAs));
      const overallMaxShear = Math.max(...storyData.map(d => d.maxRequiredShear));
      const overallProv = Math.max(...storyData.map(d => d.provided));
      const firstRow = colData.find(c => c.label === lbls[0]);
      const gKey = firstRow
        ? `${firstRow.width}x${firstRow.depth}|${firstRow.concreteMaterial}|${firstRow.flexureRebarMaterial}`
        : '';
      groups.push({
        displayId: `G${idx}`,
        rangeLabel,
        groupKey: gKey,
        columns: lbls.map(label => ({
          label,
          pmmRatio: getEffectivePmm(label),
          row: colData.find(c => c.label === label) ?? colData[0],
        })),
        maxRequiredAs: overallMaxAs,
        maxRequiredShear: overallMaxShear,
        provided: overallProv,
        ratio: overallMaxAs > 0 ? overallProv / overallMaxAs : 0,
        storyData,
      });
    }
  };

  for (const range of ranges) {
    const inRange = allLabels.filter(label => {
      const maxPmm = getEffectivePmm(label);
      if (maxPmm < range.min) return false;
      if (range.max !== null && maxPmm >= range.max) return false;
      return true;
    });
    if (inRange.length === 0) continue;
    inRange.forEach(l => assignedLabels.add(l));
    pushGroup(inRange, range.max !== null ? `${range.min} – ${range.max}` : `> ${range.min}`);
  }

  // Catch-all: any column in colData not assigned to any range (e.g. PMM < lowest range min).
  // Exclude columns with no design data at all (requiredAs=0 everywhere and PMM=0) — those were
  // never run through design in ETABS and would only produce empty rows in the schedule.
  const unassigned = allLabels.filter(l => {
    if (assignedLabels.has(l)) return false;
    if (!colData.some(c => c.label === l)) return false;
    const hasDesignData = colData.some(c => c.label === l && c.requiredAs > 0)
      || allStories.some(s => (pmmMap.get(`${s}|${l}`) ?? 0) > 0);
    return hasDesignData;
  });
  if (unassigned.length > 0) {
    pushGroup(unassigned, `< ${ranges.length > 0 ? ranges[0].min : '–'}`);
  }

  return groups;
};

// ── Story band helpers ────────────────────────────────────────────────────────
const getStoryBandKey = (story: string, bands: StoryBand[], orderedStories: string[]): string => {
  for (let i = 0; i < bands.length; i++) {
    const band = bands[i];
    const fromIdx = orderedStories.indexOf(band.fromStory);
    const toIdx   = orderedStories.indexOf(band.toStory);
    const storyIdx = orderedStories.indexOf(story);
    if (fromIdx === -1 || toIdx === -1 || storyIdx === -1) continue;
    const lo = Math.min(fromIdx, toIdx);
    const hi = Math.max(fromIdx, toIdx);
    if (storyIdx >= lo && storyIdx <= hi) return `band-${i}`;
  }
  return story;
};

const getStoriesInBand = (bandKey: string, bands: StoryBand[], orderedStories: string[]): string[] => {
  if (!bandKey.startsWith('band-')) return [bandKey];
  const idx = parseInt(bandKey.slice(5), 10);
  const band = bands[idx];
  if (!band) return [];
  const fromIdx = orderedStories.indexOf(band.fromStory);
  const toIdx   = orderedStories.indexOf(band.toStory);
  if (fromIdx === -1 || toIdx === -1) return [];
  return orderedStories.slice(Math.min(fromIdx, toIdx), Math.max(fromIdx, toIdx) + 1);
};

// ── Per-column detail computation ─────────────────────────────────────────────
const computeColumnDetailData = (
  row: ColumnDesignRow,
  solType: SolutionType,
  maxDia = 40,
  minDia = 0,
): Omit<ColumnDetailData, 'columnLabel' | 'story' | 'isModified'> => {
  const { barsWidth, barsDepth } = calcBarsPerFace(row.width, row.depth);
  const numBars = Math.max(4, 2 * barsWidth + 2 * barsDepth - 4);
  const { mainDia, cornerDia } = solType === 's1'
    ? solveS1(numBars, row.requiredAs, maxDia, minDia)
    : solveS2(numBars, row.requiredAs, maxDia, minDia);
  const providedAs = 4 * barArea(cornerDia) + Math.max(0, numBars - 4) * barArea(mainDia);
  const requiredV = row.requiredVMinRebar * 1000;
  const shearSol = solveShear(requiredV, countMaxRings(barsWidth, barsDepth));
  return {
    requiredAs: row.requiredAs,
    providedAs,
    numBars,
    mainDia,
    cornerDia,
    barsWidth,
    barsDepth,
    requiredV,
    providedV: shearSol?.provided ?? 0,
    stirrupDia: shearSol?.dia ?? 8,
    stirrupSpacing: shearSol?.spacing ?? 200,
    numRings: shearSol?.nRings ?? 1,
    cover: 40,
  };
};

// ── Session data cache — survives navigation AND Vite HMR by living on window ──
interface _ColDesignCache {
  selectedInstance: EtabsInstance;
  columns: ColumnDesignRow[];
  pmmData: ColumnPmmRow[];
  allOverrides: Record<DesignStateKey, [string, { flexProv: number; shearProv: number }][]>;
  allStatuses: Record<DesignStateKey, [string, CellStatus][]>;
}
const _getCache = (): _ColDesignCache | null => (window as any).__colDesignCache ?? null;
const _setCache = (v: _ColDesignCache | null) => { (window as any).__colDesignCache = v; };

type DiaConstraintMode = 'factor' | 'manual';

// ── Main component ────────────────────────────────────────────────────────────
const ColumnDesignPage = ({ categoryColor, onBack, className }: ColumnDesignPageProps) => {
  const [etabsInstances, setEtabsInstances] = useState<EtabsInstance[]>([]);
  const [selectedInstance, setSelectedInstance] = useState<EtabsInstance | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStage, setLoadingStage] = useState("");

  const [columns, setColumns] = useState<ColumnDesignRow[]>([]);
  const [pmmData, setPmmData] = useState<ColumnPmmRow[]>([]);
  const [dataLoaded, setDataLoaded] = useState(false);
  const [selectedCheckRow, setSelectedCheckRow] = useState<ColumnDesignRow | null>(null);
  const [checkFilter, setCheckFilter] = useState('');
  const [checkCellStatuses,  setCheckCellStatuses]  = useState<Map<string, CellStatus>>(new Map());
  const [checkCellOverrides, setCheckCellOverrides] = useState<Map<string, { flexProv: number; params: SubDetailParams }>>(new Map());

  const handleCheckSave = (key: string, params: SubDetailParams, flexProv: number) => {
    setCheckCellOverrides(prev => new Map(prev).set(key, { flexProv, params }));
  };
  const handleCheckStatusChange = (key: string, status: CellStatus) => {
    setCheckCellStatuses(prev => new Map(prev).set(key, status));
  };

  const [activeTab, setActiveTab] = useState<Tab>("Section Details");

  type SectionProperty = 'Section Name' | 'Grade' | 'Rebar Material' | 'Shear Material';
  const SECTION_PROPERTIES: SectionProperty[] = ['Section Name', 'Grade', 'Rebar Material', 'Shear Material'];
  const [sectionProperty, setSectionProperty] = useState<SectionProperty>('Section Name');

  const [pmmColors, setPmmColors] = useState({
    veryLow: '#fca5a5', low: '#a3f5d4', mid1: '#407e57',
    mid2: '#93c5fd', mid3: '#3b82f6', high: '#1e40af', veryHigh: '#111827',
  });
  const [pmmTextColors, setPmmTextColors] = useState({
    veryLow: '#ffffff', low: '#ffffff', mid1: '#ffffff',
    mid2: '#111827', mid3: '#ffffff', high: '#ffffff', veryHigh: '#ffffff',
  });
  const [showPmmColorPicker, setShowPmmColorPicker] = useState(false);

  // ── Grouping state ─────────────────────────────────────────────────────────
  const [showGroupingPopup, setShowGroupingPopup] = useState(false);
  const [groupRanges, setGroupRanges] = useState<GroupRange[]>(() => {
    try { const s = localStorage.getItem('col-design-group-ranges'); if (s) return JSON.parse(s); } catch {}
    return DEFAULT_GROUP_RANGES;
  });
  const [solutionType, setSolutionType] = useState<SolutionType>(() => {
    try { const s = localStorage.getItem('col-design-solution-type'); if (s) return s as SolutionType; } catch {}
    return "s1";
  });
  const [groupingCriteria, setGroupingCriteria] = useState<GroupingCriteria>(() => {
    try { const s = localStorage.getItem('col-design-grouping-criteria'); if (s) return JSON.parse(s); } catch {}
    return DEFAULT_CRITERIA;
  });
  const [appliedGroups, setAppliedGroups] = useState<ColumnGroup[]>([]);
  const [appliedSolutionType, setAppliedSolutionType] = useState<SolutionType>("s1");
  const [columnFilter, setColumnFilter] = useState("");
  const [storyBands, setStoryBands] = useState<StoryBand[]>(() => {
    try { const s = localStorage.getItem('col-design-story-bands'); if (s) return JSON.parse(s); } catch {}
    return [];
  });

  // ── Diameter constraint state ───────────────────────────────────────────────
  const [diaConstraintMode, setDiaConstraintMode] = useState<DiaConstraintMode>(() => {
    try { const s = localStorage.getItem('col-design-dia-mode'); if (s) return s as DiaConstraintMode; } catch {}
    return 'factor';
  });
  const [diaFactor, setDiaFactor] = useState<number>(() => {
    try { const s = localStorage.getItem('col-design-dia-factor'); if (s) return parseFloat(s); } catch {}
    return 0.1;
  });
  const [diaManualMin, setDiaManualMin] = useState<number>(() => {
    try { const s = localStorage.getItem('col-design-dia-min'); if (s) return parseInt(s); } catch {}
    return 8;
  });
  const [diaManualMax, setDiaManualMax] = useState<number>(() => {
    try { const s = localStorage.getItem('col-design-dia-max'); if (s) return parseInt(s); } catch {}
    return 40;
  });

  const getDiaConstraint = (width: number, depth: number): { maxDia: number; minDia: number } => {
    if (diaConstraintMode === 'factor') {
      const raw = Math.min(width, depth) * diaFactor;
      const maxDia = [...SOLUTION_DIAMETERS].reverse().find(d => d <= raw) ?? SOLUTION_DIAMETERS[0];
      return { maxDia, minDia: 0 };
    }
    return { maxDia: diaManualMax, minDia: diaManualMin };
  };
  const [selectedGroupDetail, setSelectedGroupDetail] = useState<{ group: ColumnGroup; story: string } | null>(null);
  const [activeSubDetailId, setActiveSubDetailId] = useState<string | null>(null);
  const [groupSubDetails, setGroupSubDetails] = useState<Map<string, SubDetail[]>>(() => {
    try {
      const saved = localStorage.getItem('col-design-subdetails');
      if (saved) return new Map(Object.entries(JSON.parse(saved) as Record<string, SubDetail[]>));
    } catch {}
    return new Map();
  });
  const [columnDataStore, setColumnDataStore] = useState<Map<string, ColumnDetailData>>(() => {
    try {
      const saved = localStorage.getItem('col-design-column-store');
      if (saved) return new Map(Object.entries(JSON.parse(saved) as Record<string, ColumnDetailData>));
    } catch {}
    return new Map();
  });

  // Skipped columns (not in design summary / missing section data)
  const [skippedColumns, setSkippedColumns] = useState<SkippedColumnEntry[]>([]);
  const [showSkippedModal, setShowSkippedModal] = useState(false);

  // Apply Prop popup state
  const [showApplyPopup, setShowApplyPopup] = useState(false);
  const [applyNamePrefix, setApplyNamePrefix] = useState('Auto');
  const [applyConcreteMat, setApplyConcreteMat] = useState('');
  const [applyFlexureMat, setApplyFlexureMat] = useState('');
  const [applyShearMat, setApplyShearMat] = useState('');
  // Modifier overrides (blank = use from data)
  const [applyAMod, setApplyAMod] = useState('');
  const [applyA2Mod, setApplyA2Mod] = useState('');
  const [applyA3Mod, setApplyA3Mod] = useState('');
  const [applyJMod, setApplyJMod] = useState('');
  const [applyI2Mod, setApplyI2Mod] = useState('');
  const [applyI3Mod, setApplyI3Mod] = useState('');
  // Material dropdown options from ETABS
  const [concreteMaterialList, setConcreteMaterialList] = useState<string[]>([]);
  const [rebarMaterialList, setRebarMaterialList] = useState<string[]>([]);
  const [materialsLoading, setMaterialsLoading] = useState(false);
  const [applyLoading, setApplyLoading] = useState(false);
  const [applyResult, setApplyResult] = useState<{ success: boolean; message?: string; error?: string } | null>(null);
  // Scope: 'all' or 'selected'
  const [applyScope, setApplyScope] = useState<'all' | 'selected'>('all');
  const [selectedFrameNames, setSelectedFrameNames] = useState<string[]>([]);
  const [fetchingFrames, setFetchingFrames] = useState(false);

  // 4 separate state buckets — one per (mode × solution) combination
  const emptyOverrides = () => new Map<string, { flexProv: number; shearProv: number }>();
  const emptyStatuses = () => new Map<string, CellStatus>();
  const [allOverrides, setAllOverrides] = useState<Record<DesignStateKey, Map<string, { flexProv: number; shearProv: number }>>>({
    "story-s1": emptyOverrides(), "story-s2": emptyOverrides(),
    "column-s1": emptyOverrides(), "column-s2": emptyOverrides(),
  });
  const [allStatuses, setAllStatuses] = useState<Record<DesignStateKey, Map<string, CellStatus>>>({
    "story-s1": emptyStatuses(), "story-s2": emptyStatuses(),
    "column-s1": emptyStatuses(), "column-s2": emptyStatuses(),
  });

  const getActiveKey = (): DesignStateKey => `column-${appliedSolutionType}` as DesignStateKey;

  const openGroupDetail = (group: ColumnGroup, story: string) => {
    setSelectedGroupDetail({ group, story });
    setActiveSubDetailId(null);
  };

  const handleAddSubDetail = (groupId: string, labels: string[], id: string, storyArg: string) => {
    setGroupSubDetails(prev => {
      const next = new Map(prev);
      const existing = next.get(groupId) ?? [];
      const newSub: SubDetail = {
        id,
        name: `Sub ${existing.length + 1}`,
        columnLabels: labels,
        story: storyArg,
      };
      next.set(groupId, [...existing, newSub]);
      localStorage.setItem('col-design-subdetails', JSON.stringify(Object.fromEntries(next)));
      return next;
    });
  };

  const handleDeleteSubDetail = (groupId: string, subId: string) => {
    setGroupSubDetails(prev => {
      const next = new Map(prev);
      const filtered = (next.get(groupId) ?? []).filter(s => s.id !== subId);
      if (filtered.length === 0) next.delete(groupId);
      else next.set(groupId, filtered);
      localStorage.setItem('col-design-subdetails', JSON.stringify(Object.fromEntries(next)));
      return next;
    });
    if (activeSubDetailId === subId) setActiveSubDetailId(null);
  };

  const handleColumnDataUpdate = (
    affectedLabels: string[],
    affectedStories: string[],
    params: SubDetailParams,
  ) => {
    const numBars = Math.max(4, 2 * params.barsWidth + 2 * params.barsDepth - 4);
    const providedAs = 4 * barArea(params.cornerDia) + Math.max(0, numBars - 4) * barArea(params.mainDia);
    const legs = 2 * params.numRings;
    const providedV = params.stirrupSpacing > 0 ? (legs * barArea(params.stirrupDia) * 1000) / params.stirrupSpacing : 0;
    setColumnDataStore(prev => {
      const next = new Map(prev);
      for (const label of affectedLabels) {
        for (const story of affectedStories) {
          const storeKey = `${label}|${story}`;
          const existing = next.get(storeKey);
          const baseRow = columns.find(c => c.label === label && c.story === story);
          next.set(storeKey, {
            columnLabel: label,
            story,
            requiredAs: existing?.requiredAs ?? baseRow?.requiredAs ?? 0,
            requiredV: existing?.requiredV ?? (baseRow ? baseRow.requiredVMinRebar * 1000 : 0),
            numBars,
            providedAs,
            providedV,
            mainDia: params.mainDia,
            cornerDia: params.cornerDia,
            barsWidth: params.barsWidth,
            barsDepth: params.barsDepth,
            cover: params.cover,
            stirrupDia: params.stirrupDia,
            stirrupSpacing: params.stirrupSpacing,
            numRings: params.numRings,
            isModified: true,
          });
        }
      }
      localStorage.setItem('col-design-column-store', JSON.stringify(Object.fromEntries(next)));
      return next;
    });
  };

  const handleGroupUpdate = (groupId: string, story: string, data: { flexProv: number; shearProv: number }) => {
    const key = getActiveKey();
    const newMap = new Map(allOverrides[key]);
    newMap.set(`${groupId}|${story}`, data);
    setAllOverrides(prev => {
      const next = { ...prev, [key]: newMap };
      if (_getCache()) _getCache()!.allOverrides = { ...Object.fromEntries(ALL_STATE_KEYS.map(k => [k, [...next[k]]])) } as any;
      return next;
    });
  };

  const handleStatusChange = (groupId: string, story: string, status: CellStatus) => {
    const key = getActiveKey();
    const newMap = new Map(allStatuses[key]);
    newMap.set(`${groupId}|${story}`, status);
    setAllStatuses(prev => {
      const next = { ...prev, [key]: newMap };
      if (_getCache()) _getCache()!.allStatuses = { ...Object.fromEntries(ALL_STATE_KEYS.map(k => [k, [...next[k]]])) } as any;
      return next;
    });
  };

  const getOverride = (groupId: string, story: string) => allOverrides[getActiveKey()].get(`${groupId}|${story}`) ?? null;
  const getEffectiveProv = (groupId: string, story: string, fallback: number) =>
    getOverride(groupId, story)?.flexProv ?? fallback;
  const getCellStatus = (groupId: string, story: string): CellStatus =>
    allStatuses[getActiveKey()].get(`${groupId}|${story}`) ?? 'untouched';

  useEffect(() => { loadEtabsInstances(); restoreFromModuleCache(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Persist grouping settings to localStorage ─────────────────────────────
  useEffect(() => { localStorage.setItem('col-design-story-bands', JSON.stringify(storyBands)); }, [storyBands]);
  useEffect(() => { localStorage.setItem('col-design-group-ranges', JSON.stringify(groupRanges)); }, [groupRanges]);
  useEffect(() => { localStorage.setItem('col-design-grouping-criteria', JSON.stringify(groupingCriteria)); }, [groupingCriteria]);
  useEffect(() => { localStorage.setItem('col-design-solution-type', solutionType); }, [solutionType]);

  // ── ETABS helpers ─────────────────────────────────────────────────────────

  const loadEtabsInstances = async () => {
    if (!window.electronAPI) return;
    const result = await window.electronAPI.getEtabsInstances();
    if (result.success && result.instances) {
      setEtabsInstances(result.instances);
      // Only auto-select if no cache has already set an instance
      if (!_getCache() && result.instances.length > 0 && result.instances[0].PID !== -1)
        setSelectedInstance(result.instances[0]);
    }
  };

  const restoreFromModuleCache = () => {
    const cache = _getCache();
    if (!cache) return;
    const { selectedInstance: inst, columns: cols, pmmData: pmm } = cache;
    setSelectedInstance(inst);
    setIsConnected(true);
    setColumns(cols);
    setPmmData(pmm);
    setDataLoaded(true);
    // Recompute groups
    const freshPmmMap = new Map<string, number>();
    pmm.forEach(r => {
      const key = `${r.story}|${r.label}`;
      const ex = freshPmmMap.get(key);
      if (ex === undefined || r.pmmRatio > ex) freshPmmMap.set(key, r.pmmRatio);
    });
    const freshStories = Array.from(new Set(cols.map(r => r.story)));
    const freshLabels = Array.from(new Set(cols.map(r => r.label))).sort();
    // Restore saved grouping settings
    let savedBands: StoryBand[] = [];
    let savedRanges: GroupRange[] = DEFAULT_GROUP_RANGES;
    let savedCriteria: GroupingCriteria = DEFAULT_CRITERIA;
    let savedSolType: SolutionType = "s1";
    try {
      const b = localStorage.getItem('col-design-story-bands'); if (b) savedBands = JSON.parse(b);
      const r = localStorage.getItem('col-design-group-ranges'); if (r) savedRanges = JSON.parse(r);
      const c = localStorage.getItem('col-design-grouping-criteria'); if (c) savedCriteria = JSON.parse(c);
      const s = localStorage.getItem('col-design-solution-type'); if (s) savedSolType = s as SolutionType;
    } catch {}
    setStoryBands(savedBands);
    setGroupRanges(savedRanges);
    setGroupingCriteria(savedCriteria);
    setSolutionType(savedSolType);
    const autoGroups = computeColumnGroups(savedRanges, savedSolType, cols, freshPmmMap, freshStories, freshLabels, savedCriteria, savedBands, freshStories);
    setAppliedGroups(autoGroups);
    setAppliedSolutionType(savedSolType);
    // Restore overrides/statuses from cache (session-only, cleared on restart)
    if (cache.allOverrides) {
      setAllOverrides(Object.fromEntries(
        ALL_STATE_KEYS.map(k => [k, new Map(cache.allOverrides[k] ?? [])])
      ) as Record<DesignStateKey, Map<string, { flexProv: number; shearProv: number }>>);
    }
    if (cache.allStatuses) {
      setAllStatuses(Object.fromEntries(
        ALL_STATE_KEYS.map(k => [k, new Map(cache.allStatuses[k] ?? [])])
      ) as Record<DesignStateKey, Map<string, CellStatus>>);
    }
  };

  const handleConnectAndLoad = async () => {
    if (!selectedInstance || selectedInstance.PID === -1) {
      alert("Please select a valid ETABS instance.");
      return;
    }
    setIsLoading(true);
    setLoadingStage("Connecting to ETABS…");
    try {
      const r = await window.electronAPI.connectToEtabs(selectedInstance.PID);
      if (!r.success) {
        alert(`Failed to connect: ${r.error}`);
        setIsLoading(false); setLoadingStage("");
        return;
      }
      setIsConnected(true);
    } catch (e) {
      alert(`Error: ${e instanceof Error ? e.message : e}`);
      setIsLoading(false); setLoadingStage("");
      return;
    }
    setLoadingStage("Reading ETABS tables…");
    try {
      const result = await window.electronAPI.designColumns(selectedInstance.PID);
      if ((result as any).debug) {
        const debug = (result as any).debug as Record<string, any>;
        console.log("=== Column Design: Raw Table Debug ===");
        for (const [tableName, tableInfo] of Object.entries(debug)) {
          const headers = tableInfo.headers as string[];
          const rows = tableInfo.rows as string[][];
          console.log(`--- "${tableName}" (${tableInfo.totalRows} rows)`);
          console.log("Headers:", headers);
          const tableRows = rows.map(row => {
            const obj: Record<string, string> = {};
            headers.forEach((h, ci) => { obj[h] = row[ci] ?? ""; });
            return obj;
          });
          if (tableRows.length > 0) console.table(tableRows);
        }
      }
      if (result.success) {
        const cols: ColumnDesignRow[] = result.columns ?? [];
        const pmm: ColumnPmmRow[] = result.pmmData ?? [];
        setColumns(cols);
        setPmmData(pmm);

        // Build PMM map from fresh data to detect no-design columns
        const freshPmmMapForSkip = new Map<string, number>();
        pmm.forEach(r => {
          const key = `${r.story}|${r.label}`;
          const ex = freshPmmMapForSkip.get(key);
          if (ex === undefined || r.pmmRatio > ex) freshPmmMapForSkip.set(key, r.pmmRatio);
        });
        // Columns returned by backend with requiredAs=0 and no PMM data were never designed in ETABS
        const noDesignSkipped: SkippedColumnEntry[] = cols
          .filter(c => c.requiredAs === 0 && (freshPmmMapForSkip.get(`${c.story}|${c.label}`) ?? 0) === 0)
          .map(c => ({
            story: c.story,
            label: c.label,
            uniqueName: c.uniqueName,
            sectionName: c.sectionName,
            reason: 'Not designed in ETABS — no flexure or PMM data found',
          }));
        setSkippedColumns([...(result.skippedColumns ?? []), ...noDesignSkipped]);
        setDataLoaded(true);
        // Clear sub-detail state for fresh data
        setGroupSubDetails(new Map());
        setColumnDataStore(new Map());
        setStoryBands([]);
        setActiveSubDetailId(null);
        localStorage.removeItem('col-design-subdetails');
        localStorage.removeItem('col-design-column-store');
        localStorage.removeItem('col-design-story-bands');

        // Build pmmMap from fresh data for auto-apply
        const freshPmmMap = new Map<string, number>();
        pmm.forEach(r => {
          const key = `${r.story}|${r.label}`;
          const ex = freshPmmMap.get(key);
          if (ex === undefined || r.pmmRatio > ex) freshPmmMap.set(key, r.pmmRatio);
        });
        const freshStories = Array.from(new Set(cols.map(r => r.story)));
        const freshLabels = Array.from(new Set(cols.map(r => r.label))).sort();
        // Auto-apply column-based grouping with defaults
        const autoGroups = computeColumnGroups(DEFAULT_GROUP_RANGES, "s1", cols, freshPmmMap, freshStories, freshLabels, DEFAULT_CRITERIA, [], []);
        setAppliedGroups(autoGroups);
        setAppliedSolutionType("s1");

        // Fresh load — start with empty statuses (do NOT restore old ones from file)
        const emptyOvRecord: Record<DesignStateKey, Map<string, { flexProv: number; shearProv: number }>> = {
          "story-s1": emptyOverrides(), "story-s2": emptyOverrides(),
          "column-s1": emptyOverrides(), "column-s2": emptyOverrides(),
        };
        const emptyStRecord: Record<DesignStateKey, Map<string, CellStatus>> = {
          "story-s1": emptyStatuses(), "story-s2": emptyStatuses(),
          "column-s1": emptyStatuses(), "column-s2": emptyStatuses(),
        };
        setAllOverrides(emptyOvRecord);
        setAllStatuses(emptyStRecord);

        // Save to window-attached cache for navigation persistence (survives HMR + navigation)
        _setCache({
          selectedInstance: selectedInstance!,
          columns: cols,
          pmmData: pmm,
          allOverrides: Object.fromEntries(ALL_STATE_KEYS.map(k => [k, []])) as any,
          allStatuses: Object.fromEntries(ALL_STATE_KEYS.map(k => [k, []])) as any,
        });

        setLoadingStage("Done!");
        setTimeout(() => { setLoadingStage(""); setIsLoading(false); }, 600);
      } else {
        alert(`Error: ${result.error}`);
        setIsLoading(false); setLoadingStage("");
      }
    } catch (e) {
      alert(`Error: ${e instanceof Error ? e.message : e}`);
      setIsLoading(false); setLoadingStage("");
    }
  };

  // ── Export ─────────────────────────────────────────────────────────────────
  const exportToExcel = async () => {
    if (!dataLoaded || columns.length === 0) { alert("No data to export."); return; }
    try {
      const ExcelJS = await import("exceljs");
      const workbook = new ExcelJS.Workbook();
      const ws1 = workbook.addWorksheet("Section Details");
      const ws2 = workbook.addWorksheet("Reinforcement Ratio");
      ws1.addRow(["No.", "Story", "Label", "Width (mm)", "Depth (mm)", "Section",
        "Fc (MPa)", "Fy (MPa)", "Req As (mm²)", "S1", "S2", "S3a", "S3b", "S4"]);
      filtered.forEach(r => ws1.addRow([
        r.no, r.story, r.label, r.width, r.depth, r.sectionName,
        r.fc, r.fy, r.requiredAs, r.s1 ?? "—", r.s2 ?? "—", r.s3a ?? "—", r.s3b ?? "—", r.s4 ?? "—",
      ]));
      ws2.addRow(["Story", "Label", "UniqueName", "P (kN)", "M2 (kN·m)", "M3 (kN·m)", "PMM Ratio"]);
      filteredPmm.forEach(r => ws2.addRow([r.story, r.label, r.uniqueName, r.p, r.m2, r.m3, r.pmmRatio]));
      [ws1, ws2].forEach(ws => {
        const hr = ws.getRow(1);
        hr.font = { bold: true, size: 10, name: "Aptos" };
        hr.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE7E6E6" } };
        hr.alignment = { horizontal: "center", vertical: "middle" };
      });
      const saveResult = await window.electronAPI.showSaveDialog({
        title: "Export Column Design", defaultPath: "ColumnDesign.xlsx",
        filters: [{ name: "Excel", extensions: ["xlsx"] }],
      });
      if (saveResult.canceled || !saveResult.filePath) return;
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer]);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = saveResult.filePath.split(/[\\/]/).pop()!;
      a.click(); URL.revokeObjectURL(url);
    } catch (e) { alert(`Export error: ${e}`); }
  };

  // ── Computed data ─────────────────────────────────────────────────────────
  const filtered = columns;
  const filteredPmm = pmmData;
  const schedule = groupBySection(filtered);
  const matrixStories = Array.from(new Set(filtered.map(r => r.story)));
  const matrixLabels = Array.from(new Set(filtered.map(r => r.label))).sort();
  const colFilterLower = columnFilter.toLowerCase().trim();
  const filteredMatrixLabels = colFilterLower
    ? matrixLabels.filter(l => l.toLowerCase().includes(colFilterLower))
    : matrixLabels;
  const filteredAppliedGroups = colFilterLower
    ? appliedGroups
        .filter(g => g.displayId.toLowerCase().includes(colFilterLower) || g.groupKey.toLowerCase().includes(colFilterLower)
          || g.columns.some(c => c.label.toLowerCase().includes(colFilterLower)))
        .map(g => g.displayId.toLowerCase().includes(colFilterLower) || g.groupKey.toLowerCase().includes(colFilterLower)
          ? g
          : { ...g, columns: g.columns.filter(c => c.label.toLowerCase().includes(colFilterLower)) })
    : appliedGroups;

  const designOptCounts = { Design: 0, Check: 0 };
  filtered.forEach(r => { if (r.designOpt === 'Design') designOptCounts.Design++; else if (r.designOpt === 'Check') designOptCounts.Check++; });
  const hasDesignOptData = designOptCounts.Design + designOptCounts.Check > 0;
  const majorityMode = filtered.length === 0 || !hasDesignOptData ? null
    : designOptCounts.Check > designOptCounts.Design ? 'Check' : 'Design';
  const matrixMap = new Map<string, ColumnDesignRow>();
  filtered.forEach(r => matrixMap.set(`${r.story}|${r.label}`, r));

  const getCellValue = (story: string, label: string, prop: SectionProperty): string => {
    const r = matrixMap.get(`${story}|${label}`);
    if (!r) return '–';
    switch (prop) {
      case 'Section Name': return r.sectionName;
      case 'Grade': return r.concreteMaterial;
      case 'Rebar Material': return r.flexureRebarMaterial;
      case 'Shear Material': return r.flexureRebarMaterial;
    }
  };

  const getPmmCellColor = (ratio: number): string => {
    if (ratio < 0.8) return pmmColors.veryLow;
    if (ratio < 1.0) return pmmColors.low;
    if (ratio < 1.2) return pmmColors.mid1;
    if (ratio < 1.5) return pmmColors.mid2;
    if (ratio < 1.8) return pmmColors.mid3;
    if (ratio < 2.0) return pmmColors.high;
    return pmmColors.veryHigh;
  };

  const getPmmTextColor = (ratio: number): string => {
    if (ratio < 0.8) return pmmTextColors.veryLow;
    if (ratio < 1.0) return pmmTextColors.low;
    if (ratio < 1.2) return pmmTextColors.mid1;
    if (ratio < 1.5) return pmmTextColors.mid2;
    if (ratio < 1.8) return pmmTextColors.mid3;
    if (ratio < 2.0) return pmmTextColors.high;
    return pmmTextColors.veryHigh;
  };

  const pmmMatrix = new Map<string, number>();
  pmmData.forEach(r => {
    const key = `${r.story}|${r.label}`;
    const ex = pmmMatrix.get(key);
    if (ex === undefined || r.pmmRatio > ex) pmmMatrix.set(key, r.pmmRatio);
  });

  const GROUP_PALETTE = [
    'rgba(59,130,246,0.18)', 'rgba(16,185,129,0.18)', 'rgba(249,115,22,0.18)',
    'rgba(139,92,246,0.18)', 'rgba(236,72,153,0.18)', 'rgba(20,184,166,0.18)',
    'rgba(234,179,8,0.18)', 'rgba(239,68,68,0.18)',
  ];
  const sectionGroupMap = new Map<string, number>();
  matrixLabels.forEach(label => {
    let groupIdx = 0; let prevVal: string | null = null;
    matrixStories.forEach(story => {
      const val = getCellValue(story, label, sectionProperty);
      if (val !== '–') {
        if (prevVal !== null && val !== prevVal) groupIdx++;
        sectionGroupMap.set(`${story}|${label}`, groupIdx);
        prevVal = val;
      }
    });
  });

  // ── Grouping handlers ─────────────────────────────────────────────────────
  // Populate columnDataStore for all columns in all groups (auto-computed, non-modified only)
  const populateColumnDataStore = (groups: ColumnGroup[], solType: SolutionType, bands: StoryBand[], ordered: string[]) => {
    setColumnDataStore(prev => {
      const next = new Map(prev);
      for (const g of groups) {
        const labels = g.columns.map(gc => gc.label);
        for (const story of ordered) {
          const storyCols = columns.filter(c => c.story === story && labels.includes(c.label));
          if (storyCols.length === 0) continue;
          const bandKey = getStoryBandKey(story, bands, ordered);
          const bandStories = getStoriesInBand(bandKey, bands, ordered);
          const bandCols = columns.filter(c => bandStories.includes(c.story) && labels.includes(c.label));
          const govRow = (bandCols.length > 0 ? bandCols : storyCols)
            .reduce((a, b) => b.requiredAs > a.requiredAs ? b : a);
          const { maxDia: cMaxDia, minDia: cMinDia } = getDiaConstraint(govRow.width, govRow.depth);
          const computed = computeColumnDetailData(govRow, solType, cMaxDia, cMinDia);
          for (const col of storyCols) {
            const storeKey = `${col.label}|${story}`;
            const existing = next.get(storeKey);
            if (!existing?.isModified) {
              next.set(storeKey, {
                columnLabel: col.label,
                story,
                ...computed,
                requiredAs: col.requiredAs,
                requiredV: col.requiredVMinRebar * 1000,
                isModified: false,
              });
            }
          }
        }
      }
      localStorage.setItem('col-design-column-store', JSON.stringify(Object.fromEntries(next)));
      return next;
    });
  };

  const handleApplyGrouping = () => {
    // Persist diameter constraint settings
    localStorage.setItem('col-design-dia-mode', diaConstraintMode);
    localStorage.setItem('col-design-dia-factor', String(diaFactor));
    localStorage.setItem('col-design-dia-min', String(diaManualMin));
    localStorage.setItem('col-design-dia-max', String(diaManualMax));
    // Clear auto-solved (non-modified) entries so they re-solve with updated constraint
    setColumnDataStore(prev => {
      const next = new Map(prev);
      for (const [k, v] of next) { if (!v.isModified) next.delete(k); }
      localStorage.setItem('col-design-column-store', JSON.stringify(Object.fromEntries(next)));
      return next;
    });
    const groups = computeColumnGroups(groupRanges, solutionType, columns, pmmMatrix, matrixStories, matrixLabels, groupingCriteria, storyBands, matrixStories);
    setAppliedGroups(groups);
    setAppliedSolutionType(solutionType);
    setShowGroupingPopup(false);
    populateColumnDataStore(groups, solutionType, storyBands, matrixStories);
  };

  const handleCriteriaChange = (key: keyof GroupingCriteria, val: boolean) => {
    const newCriteria = { ...groupingCriteria, [key]: val };
    setGroupingCriteria(newCriteria);
    const groups = computeColumnGroups(groupRanges, appliedSolutionType, columns, pmmMatrix, matrixStories, matrixLabels, newCriteria, storyBands, matrixStories);
    setAppliedGroups(groups);
    populateColumnDataStore(groups, appliedSolutionType, storyBands, matrixStories);
  };

  const handleBandsChange = (newBands: StoryBand[]) => {
    setStoryBands(newBands);
    const groups = computeColumnGroups(groupRanges, appliedSolutionType, columns, pmmMatrix, matrixStories, matrixLabels, groupingCriteria, newBands, matrixStories);
    setAppliedGroups(groups);
    populateColumnDataStore(groups, appliedSolutionType, newBands, matrixStories);
  };

  const addGroupRange = () => {
    const last = groupRanges[groupRanges.length - 1];
    const newMin = last.max ?? last.min + 0.5;
    setGroupRanges(prev => [
      ...prev.slice(0, -1),
      { ...prev[prev.length - 1], max: newMin },
      { id: `g${Date.now()}`, min: newMin, max: null },
    ]);
  };

  const removeGroupRange = (id: string) => setGroupRanges(prev => prev.filter(r => r.id !== id));

  const updateGroupRange = (id: string, field: "min" | "max", value: string) => {
    const num = parseFloat(value);
    if (isNaN(num)) return;
    setGroupRanges(prev => prev.map(r => r.id === id ? { ...r, [field]: num } : r));
  };

  // ── Render: PMM color picker popup ────────────────────────────────────────
  const renderPmmColorPicker = () => (
    <div className="pb-2 relative flex items-center gap-2">
      <Button variant="outline" size="sm"
        className="h-8 text-xs gap-2 bg-surface/60 border-border/40"
        onClick={() => setShowPmmColorPicker(p => !p)}>
        <Settings className="h-3 w-3 opacity-70" /> Colors
      </Button>
      {showPmmColorPicker && (
        <div className="absolute right-0 top-10 z-50 p-4 rounded-xl bg-surface/95 backdrop-blur-md border border-border/40 shadow-xl flex flex-col gap-1.5 min-w-[240px]">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">Reinforcement Ratio Color Palette</p>
          {([
            ['veryLow', '< 0.8', 'Low utilization'],
            ['low', '0.8 – 1.0', 'Acceptable'],
            ['mid1', '1.0 – 1.2', 'Slight overstress'],
            ['mid2', '1.2 – 1.5', 'Moderate overstress'],
            ['mid3', '1.5 – 1.8', 'High overstress'],
            ['high', '1.8 – 2.0', 'Critical'],
            ['veryHigh', '> 2.0', 'Extreme'],
          ] as const).map(([key, range, desc]) => (
            <div key={key} className="flex items-center gap-2.5">
              <div className="relative w-8 h-6 rounded shrink-0 overflow-hidden border border-border/30"
                style={{ backgroundColor: pmmColors[key] }}>
                <input type="color" value={pmmColors[key]}
                  onChange={e => setPmmColors(prev => ({ ...prev, [key]: e.target.value }))}
                  className="absolute inset-0 opacity-0 w-full h-full cursor-pointer" />
              </div>
              <div className="flex flex-col leading-tight flex-1">
                <span className="text-[11px] font-mono text-foreground/80">{range}</span>
                <span className="text-[9px] text-muted-foreground">{desc}</span>
              </div>
              <div className="flex gap-1 shrink-0">
                <button
                  className={cn("w-5 h-5 rounded text-[9px] font-bold border transition-all", pmmTextColors[key] === '#ffffff' ? "border-white/60 ring-1 ring-white/60" : "border-border/30 opacity-40")}
                  style={{ backgroundColor: '#111827', color: '#ffffff' }}
                  onClick={() => setPmmTextColors(prev => ({ ...prev, [key]: '#ffffff' }))}>W</button>
                <button
                  className={cn("w-5 h-5 rounded text-[9px] font-bold border transition-all", pmmTextColors[key] === '#111827' ? "border-black/40 ring-1 ring-black/40" : "border-border/30 opacity-40")}
                  style={{ backgroundColor: '#ffffff', color: '#111827' }}
                  onClick={() => setPmmTextColors(prev => ({ ...prev, [key]: '#111827' }))}>B</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  // ── Render: group range editor popup ─────────────────────────────────────
  const renderGroupingPopup = () => (
    <div className="absolute right-0 top-10 z-50 p-4 rounded-xl bg-surface/95 backdrop-blur-md border border-border/40 shadow-xl flex flex-col gap-3 min-w-[340px]">
      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        PMM Groups — Set Limit
      </p>
      <div className="flex flex-col gap-1.5">
        {groupRanges.map((range, i) => (
          <div key={range.id} className="flex items-center gap-2">
            <span className="text-[10px] text-muted-foreground w-4 text-right">{i + 1}.</span>
            <input type="number" step="0.1" value={range.min}
              onChange={e => updateGroupRange(range.id, "min", e.target.value)}
              className="w-16 h-7 px-2 text-xs font-mono bg-surface/60 border border-border/40 rounded text-foreground text-center outline-none focus:border-border/80" />
            <span className="text-[10px] text-muted-foreground">→</span>
            {range.max !== null ? (
              <input type="number" step="0.1" value={range.max}
                onChange={e => updateGroupRange(range.id, "max", e.target.value)}
                className="w-16 h-7 px-2 text-xs font-mono bg-surface/60 border border-border/40 rounded text-foreground text-center outline-none focus:border-border/80" />
            ) : (
              <span className="w-16 h-7 flex items-center justify-center text-xs font-mono text-muted-foreground border border-border/20 rounded bg-surface/30">∞</span>
            )}
            <button onClick={() => removeGroupRange(range.id)}
              className="w-6 h-6 rounded flex items-center justify-center text-muted-foreground hover:text-red-400 hover:bg-red-400/10 transition-colors">
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
      <button onClick={addGroupRange}
        className="flex items-center gap-1.5 text-[11px] text-muted-foreground hover:text-foreground transition-colors self-start">
        <Plus className="w-3 h-3" /> Add range
      </button>
      {/* Story Bands */}
      <div className="border-t pt-2.5 flex flex-col gap-1.5" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Story Bands</p>
          <button
            onClick={() => {
              if (matrixStories.length === 0) return;
              const newBands = [...storyBands, { id: `sb${Date.now()}`, fromStory: matrixStories[0], toStory: matrixStories[0] }];
              handleBandsChange(newBands);
            }}
            className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground transition-colors">
            <Plus className="w-3 h-3" /> Add band
          </button>
        </div>
        {storyBands.length === 0 && (
          <p className="text-[10px] text-muted-foreground/60 italic">All stories separate (default)</p>
        )}
        {storyBands.map((band, i) => (
          <div key={band.id} className="flex items-center gap-1.5">
            <span className="text-[10px] text-muted-foreground w-4 text-right shrink-0">{i + 1}.</span>
            <select
              value={band.fromStory}
              onChange={e => {
                const newBands = storyBands.map(b => b.id === band.id ? { ...b, fromStory: e.target.value } : b);
                handleBandsChange(newBands);
              }}
              className="flex-1 h-7 px-1.5 text-[11px] font-mono bg-surface/60 border border-border/40 rounded text-foreground outline-none focus:border-border/80"
            >
              {matrixStories.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <span className="text-[10px] text-muted-foreground shrink-0">→</span>
            <select
              value={band.toStory}
              onChange={e => {
                const newBands = storyBands.map(b => b.id === band.id ? { ...b, toStory: e.target.value } : b);
                handleBandsChange(newBands);
              }}
              className="flex-1 h-7 px-1.5 text-[11px] font-mono bg-surface/60 border border-border/40 rounded text-foreground outline-none focus:border-border/80"
            >
              {matrixStories.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <button
              onClick={() => handleBandsChange(storyBands.filter(b => b.id !== band.id))}
              className="w-6 h-6 rounded flex items-center justify-center text-muted-foreground hover:text-red-400 hover:bg-red-400/10 transition-colors shrink-0">
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
      {/* Diameter Constraint */}
      <div className="border-t pt-2.5 flex flex-col gap-2" style={{ borderColor: 'rgba(0,0,0,0.08)' }}>
        <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: '#6b7280' }}>Max Bar Diameter</p>
        <div className="flex gap-4">
          {(['factor', 'manual'] as const).map(mode => (
            <button key={mode} onClick={() => setDiaConstraintMode(mode)}
              className="flex items-center gap-1.5 text-[11px] transition-colors"
              style={{ color: diaConstraintMode === mode ? '#111827' : '#9ca3af' }}>
              <span className="w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center shrink-0"
                style={{ borderColor: diaConstraintMode === mode ? categoryColor : '#d1d5db', background: 'transparent' }}>
                {diaConstraintMode === mode && <span className="w-1.5 h-1.5 rounded-full block" style={{ background: categoryColor }} />}
              </span>
              {mode === 'factor' ? 'Factor Rule' : 'Manual Range'}
            </button>
          ))}
        </div>
        {diaConstraintMode === 'factor' ? (
          <div className="flex items-center gap-2 flex-wrap text-[11px]" style={{ color: '#374151' }}>
            <span>max Ø = min(w, d) ×</span>
            <input type="text" value={diaFactor}
              onChange={e => { const v = parseFloat(e.target.value); if (!isNaN(v)) setDiaFactor(Math.max(0.01, Math.min(1, v))); }}
              className="w-14 h-7 px-2 text-xs font-mono rounded text-center outline-none"
              style={{ background: '#f3f4f6', border: '1px solid #d1d5db', color: '#111827' }} />
            <span style={{ color: '#9ca3af', fontSize: 10 }}>(default 0.1)</span>
          </div>
        ) : (
          <div className="flex items-center gap-2 flex-wrap text-[11px]" style={{ color: '#374151' }}>
            <span>min Ø</span>
            <select value={diaManualMin} onChange={e => setDiaManualMin(+e.target.value)}
              className="h-7 px-1.5 text-[11px] font-mono rounded outline-none"
              style={{ background: '#f3f4f6', border: '1px solid #d1d5db', color: '#111827' }}>
              {BAR_DIAMETERS.map(d => <option key={d} value={d}>{d} mm</option>)}
            </select>
            <span>max Ø</span>
            <select value={diaManualMax} onChange={e => setDiaManualMax(+e.target.value)}
              className="h-7 px-1.5 text-[11px] font-mono rounded outline-none"
              style={{ background: '#f3f4f6', border: '1px solid #d1d5db', color: '#111827' }}>
              {BAR_DIAMETERS.map(d => <option key={d} value={d}>{d} mm</option>)}
            </select>
          </div>
        )}
      </div>
      <Button size="sm" className="h-8 text-xs" style={{ backgroundColor: categoryColor, color: "white" }}
        onClick={handleApplyGrouping}>
        Apply
      </Button>
    </div>
  );

  // ── Render: shared PMM matrix ──────────────────────────────────────────────
  const renderPmmMatrix = () => (
    filteredPmm.length === 0 ? (
      <div className="flex flex-col items-center justify-center h-64 text-muted-foreground gap-2">
        <p className="text-sm">No PMM data</p>
        <p className="text-xs opacity-70">Run concrete column design in ETABS first</p>
      </div>
    ) : (
      <div className="flex-1 rounded-xl border border-slate-200 overflow-hidden bg-white min-h-0" style={{ boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
        <div className="h-full overflow-auto">
          <table className="border-collapse" style={{ minWidth: 'max-content', height: '100%' }}>
            <tbody>
              <tr style={{ height: '100%' }}><td colSpan={filteredMatrixLabels.length + 1} /></tr>
              {[...matrixStories].reverse().map((story, si) => {
                const rowBg = si % 2 === 0 ? '#f8fafc' : '#ffffff';
                return (
                <tr key={story}
                  style={{ borderBottom: '1px solid #e2e8f0', background: rowBg }}
                  onMouseEnter={e => (e.currentTarget.style.background = '#eff6ff')}
                  onMouseLeave={e => (e.currentTarget.style.background = rowBg)}>
                  <td className="sticky left-0 z-10 w-24 px-3 py-2 text-xs font-semibold bg-white"
                    style={{ color: '#1e293b', borderRight: '2px solid #e2e8f0' }}>{story}</td>
                  {filteredMatrixLabels.map(label => {
                    const ratio = pmmMatrix.get(`${story}|${label}`);
                    const isEmpty = ratio === undefined;
                    const bg = isEmpty ? undefined : getPmmCellColor(ratio);
                    const textColor = isEmpty ? undefined : getPmmTextColor(ratio);
                    return (
                      <td key={label} className="w-28 px-3 py-2 text-xs text-center font-mono tabular-nums transition-colors"
                          style={{ borderRight: '1px solid #e2e8f0', ...(bg ? { backgroundColor: bg + 'dd', color: textColor } : {}) }}>
                        {isEmpty ? <span style={{ color: '#cbd5e1' }}>–</span> : ratio.toFixed(3)}
                      </td>
                    );
                  })}
                </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr>
                <th className="sticky bottom-0 left-0 z-30 w-24 px-3 py-2.5 text-[10px] font-semibold uppercase tracking-wider text-left"
                  style={{ background: '#f1f5f9', color: '#475569', borderTop: '2px solid #e2e8f0', borderRight: '2px solid #e2e8f0' }}>Story</th>
                {filteredMatrixLabels.map(label => {
                  const colRows = filtered.filter(r => r.label === label);
                  const designCount = colRows.filter(r => r.designOpt === 'Design').length;
                  const checkCount = colRows.filter(r => r.designOpt === 'Check').length;
                  const mode = designCount === 0 && checkCount === 0 ? null
                    : checkCount > designCount ? 'Check' : 'Design';
                  return (
                    <th key={label} className="sticky bottom-0 z-20 w-28 px-3 py-2.5 text-[10px] font-semibold uppercase tracking-wider text-center"
                      style={{ background: '#f1f5f9', color: '#475569', borderTop: '2px solid #e2e8f0', borderRight: '1px solid #e2e8f0' }}>
                      <div className="flex flex-col items-center gap-0.5">
                        <span>{label}</span>
                        {mode && (
                          <span
                            className="text-[8px] font-medium px-1.5 py-px rounded-full leading-tight tracking-wide"
                            style={mode === 'Design'
                              ? { background: 'rgba(251,146,60,0.18)', color: '#f97316', border: '1px solid rgba(251,146,60,0.3)' }
                              : { background: 'rgba(20,184,166,0.15)', color: '#14b8a6', border: '1px solid rgba(20,184,166,0.3)' }
                            }>
                            {mode === 'Design' ? 'Design' : 'Check'}
                          </span>
                        )}
                      </div>
                    </th>
                  );
                })}
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    )
  );

  // ── Render: shared Section Details matrix ──────────────────────────────────
  const renderSectionMatrix = () => (
    matrixStories.length === 0 ? (
      <div className="flex-1 flex items-center justify-center text-muted-foreground text-xs">No data loaded</div>
    ) : (
      <div className="flex-1 rounded-xl border border-slate-200 overflow-hidden bg-white min-h-0" style={{ boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
        <div className="h-full overflow-auto">
          <table className="border-collapse" style={{ minWidth: 'max-content', width: '100%', height: '100%' }}>
            <tbody>
              <tr style={{ height: '100%' }}><td colSpan={matrixLabels.length + 1} /></tr>
              {[...matrixStories].reverse().map((story, si) => {
                const rowBg = si % 2 === 0 ? '#f8fafc' : '#ffffff';
                return (
                <tr key={story}
                  style={{ borderBottom: '1px solid #e2e8f0', background: rowBg }}
                  onMouseEnter={e => (e.currentTarget.style.background = '#eff6ff')}
                  onMouseLeave={e => (e.currentTarget.style.background = rowBg)}>
                  <td className="sticky left-0 z-10 w-24 px-3 py-2 text-xs font-semibold bg-white"
                    style={{ color: '#1e293b', borderRight: '2px solid #e2e8f0' }}>{story}</td>
                  {matrixLabels.map(label => {
                    const val = getCellValue(story, label, sectionProperty);
                    const isEmpty = val === '–';
                    const groupIdx = isEmpty ? -1 : (sectionGroupMap.get(`${story}|${label}`) ?? 0);
                    const groupBg = isEmpty ? undefined : GROUP_PALETTE[groupIdx % GROUP_PALETTE.length];
                    return (
                      <td key={label} className="w-28 px-3 py-2 text-xs text-center font-mono transition-colors"
                          style={{ borderRight: '1px solid #e2e8f0', ...(groupBg ? { backgroundColor: groupBg } : {}) }}>
                        {isEmpty ? <span style={{ color: '#cbd5e1' }}>–</span> : <span style={{ color: '#1e293b' }}>{val}</span>}
                      </td>
                    );
                  })}
                </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr>
                <th className="sticky bottom-0 left-0 z-30 w-24 px-3 py-2.5 text-[10px] font-semibold uppercase tracking-wider text-left"
                  style={{ background: '#f1f5f9', color: '#475569', borderTop: '2px solid #e2e8f0', borderRight: '2px solid #e2e8f0' }}>Story</th>
                {matrixLabels.map(label => (
                  <th key={label} className="sticky bottom-0 z-20 w-28 px-3 py-2.5 text-[10px] font-semibold uppercase tracking-wider text-center"
                    style={{ background: '#f1f5f9', color: '#475569', borderTop: '2px solid #e2e8f0', borderRight: '1px solid #e2e8f0' }}>{label}</th>
                ))}
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    )
  );

  // ── Render: "Based on Story" grouped table (kept but unused from Detailing tab) ──────────────────────────────
  // Two-level header: group headers row above, column names row at bottom
  // One data row for the applied story
  const renderStoryGroupedTable = () => {
    if (appliedGroups.length === 0) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground gap-2">
          <p className="text-sm">No groups applied</p>
          <p className="text-xs opacity-70">Select a story, configure ranges, then click Apply</p>
        </div>
      );
    }
    return (
      <div className="flex-1 rounded-xl border border-border/30 overflow-hidden bg-surface/20 min-h-0">
        <div className="h-full flex flex-col-reverse overflow-y-auto overflow-x-auto">

          {/* Level 1: Column names — sticky at visual bottom */}
          <div className="flex shrink-0 h-8 sticky bottom-0 z-10 bg-surface/90 backdrop-blur-md border-t border-border/40">
            <div className="w-24 shrink-0 px-3 flex items-center text-[10px] font-semibold uppercase text-foreground border-r border-border/20 sticky left-0 z-20 bg-surface/95">Story</div>
            {appliedGroups.map((g, gIdx) =>
              g.columns.map(c => (
                <div key={`${g.displayId}-${c.label}`}
                  style={{ background: GROUP_PALETTE[gIdx % GROUP_PALETTE.length] }}
                  className="w-24 shrink-0 px-2 flex items-center justify-center text-[10px] font-semibold text-center text-foreground border-r border-border/10 last:border-r-0">
                  {c.label}
                </div>
              ))
            )}
          </div>

          {/* Level 2: Group headers — sticky just above column names */}
          <div className="flex shrink-0 sticky bottom-8 z-10 bg-surface/80 backdrop-blur-md border-t border-border/30" style={{ minHeight: '72px' }}>
            <div className="w-24 shrink-0 border-r border-border/20 sticky left-0 z-20 bg-surface/80" />
            {appliedGroups.map((g, gIdx) => (
              <div key={g.displayId}
                style={{ width: `${g.columns.length * 6}rem`, background: GROUP_PALETTE[gIdx % GROUP_PALETTE.length] }}
                className="shrink-0 px-2.5 py-1.5 border-r border-border/30 flex flex-col justify-center gap-0.5 cursor-pointer hover:brightness-110 transition-all"
                onDoubleClick={() => openGroupDetail(g, '')}>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[10px] font-bold" style={{ color: '#111' }}>{g.displayId}</span>
                  <span className="text-[9px] font-mono" style={{ color: '#555' }}>PMM {g.rangeLabel}</span>
                </div>
                {(() => {
                  const ov = getOverride(g.displayId, '');
                  const effFlexProv = ov?.flexProv ?? g.provided;
                  const effFlexRatio = g.maxRequiredAs > 0 && effFlexProv > 0 ? effFlexProv / g.maxRequiredAs : g.ratio;
                  const shearReqDisp = g.maxRequiredShear * 1000;
                  const effShearProv = ov?.shearProv ?? null;
                  const effShearRatio = effShearProv && shearReqDisp > 0 ? effShearProv / shearReqDisp : null;
                  const [sizeStr, fcStr, fyStr] = g.groupKey.split('|');
                  return (
                    <div className="flex flex-col gap-px text-[9px] font-mono">
                      <span style={{ color: '#111' }}>F: {g.maxRequiredAs > 0 ? g.maxRequiredAs.toFixed(0) : '—'} / {effFlexProv > 0 ? effFlexProv.toFixed(0) : '—'} mm² <span className="font-bold" style={{ color: getRatioColor(effFlexRatio) }}>{effFlexRatio > 0 ? effFlexRatio.toFixed(2) : '—'}</span></span>
                      <span style={{ color: '#111' }}>S: {shearReqDisp > 0 ? shearReqDisp.toFixed(0) : '—'} / {effShearProv ? effShearProv.toFixed(0) : '—'} mm²/m <span className="font-bold" style={{ color: effShearRatio ? getRatioColor(effShearRatio) : '#555' }}>{effShearRatio ? effShearRatio.toFixed(2) : '—'}</span></span>
                      <span style={{ color: '#555' }}>{sizeStr}<span style={{ color: '#aaa' }}>|</span>{fcStr}<span style={{ color: '#aaa' }}>/</span>{fyStr}</span>
                    </div>
                  );
                })()}
              </div>
            ))}
          </div>

          {/* Single data row for the applied story */}
          <div className="flex shrink-0 border-b border-border/10">
            <div className="w-24 shrink-0 px-3 py-2 text-xs font-medium border-r border-border/20 sticky left-0 bg-surface/80 backdrop-blur-sm" style={{ color: '#111' }}>
              —
            </div>
            {appliedGroups.map(g =>
              g.columns.map(c => {
                const bg = getPmmCellColor(c.pmmRatio);
                const textColor = getPmmTextColor(c.pmmRatio);
                return (
                  <div key={`${g.displayId}-${c.label}`}
                    className="w-24 shrink-0 px-2 py-2 text-xs text-center font-mono border-r border-border/10 last:border-r-0"
                    style={{ backgroundColor: bg + 'dd', color: textColor }}>
                    {c.pmmRatio.toFixed(3)}
                  </div>
                );
              })
            )}
          </div>

        </div>
      </div>
    );
  };

  // ── Render: column grouped table ──────────────────────────────────────────
  // Two-level header: group headers + column names at bottom (sticky)
  // All stories as data rows; each cell = aggregate for that story × group
  const renderColumnGroupedTable = () => {
    if (appliedGroups.length === 0) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground gap-2">
          <p className="text-sm">No groups applied</p>
          <p className="text-xs opacity-70">Configure ranges and click Apply</p>
        </div>
      );
    }
    if (filteredAppliedGroups.length === 0) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground gap-2">
          <p className="text-sm">No columns match filter</p>
          <p className="text-xs opacity-70">Try a different search term</p>
        </div>
      );
    }
    const COL_W = 128; // px per individual column
    // Story band coloring — distinct tints per band index
    const BAND_TINTS = [
      'rgba(99,102,241,0.10)',  // indigo
      'rgba(16,185,129,0.10)',  // emerald
      'rgba(245,158,11,0.10)',  // amber
      'rgba(239,68,68,0.10)',   // red
      'rgba(59,130,246,0.10)',  // blue
      'rgba(168,85,247,0.10)',  // purple
      'rgba(20,184,166,0.10)',  // teal
    ];
    const BAND_BORDER_COLORS = [
      'rgba(99,102,241,0.7)',
      'rgba(16,185,129,0.7)',
      'rgba(245,158,11,0.7)',
      'rgba(239,68,68,0.7)',
      'rgba(59,130,246,0.7)',
      'rgba(168,85,247,0.7)',
      'rgba(20,184,166,0.7)',
    ];
    const getStoryBandIndex = (story: string): number => {
      for (let i = 0; i < storyBands.length; i++) {
        const band = storyBands[i];
        const fromIdx = matrixStories.indexOf(band.fromStory);
        const toIdx   = matrixStories.indexOf(band.toStory);
        const sIdx    = matrixStories.indexOf(story);
        if (sIdx >= Math.min(fromIdx, toIdx) && sIdx <= Math.max(fromIdx, toIdx)) return i;
      }
      return -1;
    };
    return (
      <div className="flex-1 rounded-xl border border-slate-200 overflow-hidden bg-white min-h-0" style={{ boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
        <div className="h-full overflow-auto">
          <table className="border-collapse" style={{ minWidth: 'max-content', height: '100%' }}>
            <tbody>
              {/* Spacer row — pushes data rows down to sit just above the footer */}
              <tr style={{ height: '100%' }}><td colSpan={filteredAppliedGroups.reduce((s, g) => s + g.columns.length, 0) + 1} /></tr>
              {/* Data rows: one per story — matrixStories order = visual top-to-bottom */}
              {matrixStories.map((story, si) => {
                const bandIdx = getStoryBandIndex(story);
                const bandTint = bandIdx >= 0 ? BAND_TINTS[bandIdx % BAND_TINTS.length] : undefined;
                const bandBorder = bandIdx >= 0 ? BAND_BORDER_COLORS[bandIdx % BAND_BORDER_COLORS.length] : 'transparent';
                const rowStripe = si % 2 === 0 ? '#f8fafc' : '#ffffff';
                const rowBg = bandTint ?? rowStripe;
                return (
                <tr key={story}
                  style={{ background: rowBg, borderBottom: '1px solid #e2e8f0' }}
                  onMouseEnter={e => (e.currentTarget.style.background = '#eff6ff')}
                  onMouseLeave={e => (e.currentTarget.style.background = rowBg)}>
                  <td className="sticky left-0 z-10 px-3 py-2 text-xs font-semibold bg-white"
                    style={{ color: '#1e293b', width: 96, minWidth: 96, borderRight: '2px solid #e2e8f0', borderLeft: `3px solid ${bandBorder}` }}>{story}</td>
                  {filteredAppliedGroups.map((g, gIdx) => {
                    const groupSubs = groupSubDetails.get(g.displayId) ?? [];
                    const sd = g.storyData?.find(d => d.story === story);
                    // Pre-compute main group design for non-sub columns
                    const mainOv = getOverride(g.displayId, story);
                    const mainFlexProv = mainOv?.flexProv ?? sd?.provided ?? 0;
                    const mainShearReqDisp = (sd?.maxRequiredShear ?? 0) * 1000;
                    const mainShearProv = (() => {
                      if (mainOv?.shearProv != null) return mainOv.shearProv;
                      const mainCols = g.columns.filter(gc => !groupSubs.some(s => s.columnLabels.includes(gc.label)));
                      const cols = mainCols.length > 0 ? mainCols : g.columns;
                      const govR = cols
                        .map(gc => matrixMap.get(`${story}|${gc.label}`))
                        .filter((r): r is ColumnDesignRow => r !== undefined)
                        .reduce<ColumnDesignRow | undefined>((a, b) => !a || b.requiredAs >= a.requiredAs ? b : a, undefined)
                        ?? g.columns[0].row;
                      const { barsWidth: bW, barsDepth: bD } = calcBarsPerFace(govR.width, govR.depth);
                      return solveShear(mainShearReqDisp, countMaxRings(bW, bD))?.provided ?? null;
                    })();
                    const cellSt = getCellStatus(g.displayId, story);
                    const statusBg = cellSt === 'done'
                      ? 'linear-gradient(135deg, rgba(228, 252, 237, 1) 50%, transparent 50%)'
                      : cellSt === 'hold'
                      ? 'linear-gradient(-45deg, rgba(253, 239, 193, 1) 50%, transparent 50%)'
                      : undefined;
                    return g.columns.map((c, ci) => {
                      const colRow = matrixMap.get(`${story}|${c.label}`);
                      const colSub = groupSubs.find(s => s.columnLabels.includes(c.label) && s.story === story);
                      const hasData = !!(colRow && colRow.requiredAs > 0) || !!(sd && sd.maxRequiredAs > 0);
                      // Per-column required values (from ETABS, not group max)
                      let flexReq: number;
                      let flexProvDisp: number;
                      let flexRatio: number;
                      let shearReqDisp: number;
                      let shearProvDisp: number | null;
                      let shearRatio: number | null;
                      if (colSub) {
                        const subOv = getOverride(`${g.displayId}::${colSub.id}`, story);
                        flexReq = colRow?.requiredAs ?? 0;
                        flexProvDisp = subOv?.flexProv ?? mainFlexProv;
                        flexRatio = flexReq > 0 && flexProvDisp > 0 ? flexProvDisp / flexReq : 0;
                        shearReqDisp = (colRow?.requiredVMinRebar ?? 0) * 1000;
                        shearProvDisp = subOv?.shearProv ?? mainShearProv;
                        shearRatio = shearProvDisp && shearReqDisp > 0 ? shearProvDisp / shearReqDisp : null;
                      } else {
                        const perColEntry = columnDataStore.get(`${c.label}|${story}`);
                        flexReq = colRow?.requiredAs ?? 0; // per-column from ETABS
                        flexProvDisp = perColEntry?.providedAs ?? mainFlexProv;
                        flexRatio = flexReq > 0 && flexProvDisp > 0 ? flexProvDisp / flexReq : 0;
                        shearReqDisp = (colRow?.requiredVMinRebar ?? 0) * 1000;
                        shearProvDisp = perColEntry?.providedV ?? mainShearProv;
                        shearRatio = shearProvDisp && shearReqDisp > 0 ? shearProvDisp / shearReqDisp : null;
                      }
                      return (
                        <td key={`${g.displayId}-${c.label}`}
                          className="px-2 py-1.5 cursor-pointer align-top"
                          style={{
                            width: COL_W,
                            minWidth: COL_W,
                            background: statusBg ?? (colSub ? 'rgba(241,245,249,0.8)' : undefined),
                            borderRight: '1px solid #e2e8f0',
                            borderLeft: ci === 0 && gIdx > 0 ? '2px solid #cbd5e1' : undefined,
                          }}
                          onMouseEnter={e => { if (!statusBg) e.currentTarget.style.background = '#dbeafe'; }}
                          onMouseLeave={e => { if (!statusBg) e.currentTarget.style.background = colSub ? 'rgba(241,245,249,0.8)' : ''; }}
                          onClick={() => {
                            setSelectedGroupDetail({ group: g, story });
                            setActiveSubDetailId(colSub?.id ?? null);
                          }}>
                          {hasData ? (
                            <div className="flex flex-col gap-[3px]">
                              <span className="text-[10px] font-mono leading-tight">
                                <span style={{ color: '#64748b', fontWeight: 500 }}>F </span>
                                <span style={{ color: '#94a3b8' }}>{flexReq > 0 ? Math.round(flexReq) : '—'}</span>
                                <span style={{ color: '#cbd5e1' }}>/</span>
                                <span style={{ color: '#64748b' }}>{flexProvDisp > 0 ? Math.round(flexProvDisp) : '—'}</span>
                                <span className="ml-1.5 font-bold tabular-nums" style={{ color: flexRatio > 0 ? getRatioColor(flexRatio) : '#94a3b8' }}>
                                  {flexRatio > 0 ? flexRatio.toFixed(2) : '—'}
                                </span>
                              </span>
                              <span className="text-[10px] font-mono leading-tight">
                                <span style={{ color: '#64748b', fontWeight: 500 }}>S </span>
                                <span style={{ color: '#94a3b8' }}>{shearReqDisp > 0 ? Math.round(shearReqDisp) : '—'}</span>
                                <span style={{ color: '#cbd5e1' }}>/</span>
                                <span style={{ color: '#64748b' }}>{shearProvDisp ? Math.round(shearProvDisp) : '—'}</span>
                                <span className="ml-1.5 font-bold tabular-nums" style={{ color: shearRatio ? getRatioColor(shearRatio) : '#94a3b8' }}>
                                  {shearRatio ? shearRatio.toFixed(2) : '—'}
                                </span>
                              </span>
                              <span className="text-[9px] font-mono leading-tight" style={{ color: '#94a3b8' }}>
                                {colRow ? `${colRow.width}×${colRow.depth}` : (c.row ? `${c.row.width}×${c.row.depth}` : '—')}
                                {colSub && <span className="ml-1" style={{ color: '#cbd5e1' }}>{colSub.name}</span>}
                              </span>
                            </div>
                          ) : (
                            <span style={{ color: '#cbd5e1', fontSize: 12 }}>–</span>
                          )}
                        </td>
                      );
                    });
                  })}
                </tr>
              );
            })}
            </tbody>
            <tfoot>
              {/* Row 1: Group headers — sticky just above column names */}
              <tr>
                <th rowSpan={2} className="sticky bottom-0 left-0 z-30 px-3 text-[10px] font-semibold uppercase tracking-wider text-left align-middle"
                  style={{ width: 96, minWidth: 96, background: '#f1f5f9', color: '#475569', borderTop: '2px solid #e2e8f0', borderRight: '2px solid #e2e8f0' }}>Story</th>
                {filteredAppliedGroups.map((g, gIdx) => (
                  <th key={g.displayId}
                    colSpan={g.columns.length}
                    className="z-20 px-2.5 py-1.5 cursor-pointer transition-all text-left align-middle"
                    style={{ bottom: 44, position: 'sticky', background: GROUP_PALETTE[gIdx % GROUP_PALETTE.length], borderTop: '2px solid #e2e8f0', borderRight: '1px solid rgba(255,255,255,0.4)' }}
                    onClick={() => openGroupDetail(g, '')}>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] font-bold" style={{ color: '#1e293b' }}>{g.displayId}</span>
                      <span className="text-[9px] font-mono" style={{ color: '#475569' }}>PMM {g.rangeLabel}</span>
                    </div>
                    <div className="text-[9px] truncate" style={{ color: '#64748b' }}>{g.groupKey}</div>
                  </th>
                ))}
              </tr>
              {/* Row 2: Column names — very bottom */}
              <tr>
                {filteredAppliedGroups.map((g, gIdx) =>
                  g.columns.map(c => {
                    const colSub = (groupSubDetails.get(g.displayId) ?? []).find(s => s.columnLabels.includes(c.label));
                    return (
                      <th key={`${g.displayId}-${c.label}`}
                        className="z-20 px-1 text-center align-middle"
                        style={{ bottom: 0, position: 'sticky', width: COL_W, minWidth: COL_W, height: 44, background: GROUP_PALETTE[gIdx % GROUP_PALETTE.length], borderTop: '1px solid rgba(255,255,255,0.35)', borderRight: '1px solid rgba(255,255,255,0.3)' }}>
                        <span className="text-[10px] font-semibold leading-tight" style={{ color: '#1e293b' }}>{c.label}</span>
                        {colSub && <span className="block text-[7px] font-medium leading-none mt-0.5" style={{ color: '#64748b' }}>{colSub.name}</span>}
                      </th>
                    );
                  })
                )}
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    );
  };

  // ── Apply Prop popup ──────────────────────────────────────────────────────

  // Parse main (majority) bar diameter from solution label e.g. "4×Ø25 + 24×Ø20" → 20
  const parseMainDia = (sol: string): number => {
    const pairs = [...sol.matchAll(/(\d+)×Ø(\d+)/g)].map(m => ({ count: parseInt(m[1]), dia: parseInt(m[2]) }));
    if (pairs.length === 0) return 16;
    return pairs.reduce((a, b) => b.count > a.count ? b : a).dia;
  };


  const getApplyGroups = (): ColumnGroup[] => {
    return computeColumnGroups(groupRanges, solutionType, columns, pmmMatrix, matrixStories, matrixLabels, groupingCriteria, storyBands, matrixStories);
  };

  const parseMod = (val: string, fallback: number) =>
    val.trim() !== '' ? (parseFloat(val) || fallback) : fallback;

  const buildApplyPayload = () => {
    const groups = getApplyGroups();
    const sections: import('@/types/electron').ApplySectionOptions[] = [];
    for (const g of groups) {
      const labels = g.columns.map(gc => gc.label);
      const allGroupRows = columns.filter(c => labels.includes(c.label));
      if (allGroupRows.length === 0) continue;
      const govRow = allGroupRows.reduce((a, b) => b.requiredAs > a.requiredAs ? b : a);
      // Use per-column store (modified or auto-computed); fallback to fresh solve
      const storeKey = `${govRow.label}|${govRow.story}`;
      const stored = columnDataStore.get(storeKey);
      let mainDia: number, nw: number, nd: number, confDia: number, confSpacing: number;
      if (stored) {
        mainDia = stored.mainDia; nw = stored.barsWidth; nd = stored.barsDepth;
        confDia = stored.stirrupDia; confSpacing = stored.stirrupSpacing;
      } else {
        const bars = calcBarsPerFace(govRow.width, govRow.depth);
        nw = bars.barsWidth; nd = bars.barsDepth;
        const derivedTotalBars = Math.max(4, 2 * nw + 2 * nd - 4);
        const { maxDia: _mxd, minDia: _mnd } = getDiaConstraint(govRow.width, govRow.depth);
        const solved = solutionType === 's1'
          ? solveS1(derivedTotalBars, govRow.requiredAs, _mxd, _mnd)
          : solveS2(derivedTotalBars, govRow.requiredAs, _mxd, _mnd);
        mainDia = solved.mainDia;
        const shearSol = solveShear(govRow.requiredVMinRebar, countMaxRings(nw, nd));
        confDia = shearSol?.dia ?? 10; confSpacing = shearSol?.spacing ?? 100;
      }
      if (mainDia === 0) continue;
      let uniqueNames = [...new Set(allGroupRows.map(c => c.uniqueName))];
      if (applyScope === 'selected') {
        uniqueNames = uniqueNames.filter(n => selectedFrameNames.includes(n));
        if (uniqueNames.length === 0) continue;
      }
      sections.push({
        sectionName: `${applyNamePrefix}_${g.displayId}_${govRow.width}x${govRow.depth}`,
        material: applyConcreteMat || govRow.concreteMaterial,
        width: govRow.width,
        depth: govRow.depth,
        rebarMaterial: applyFlexureMat || govRow.flexureRebarMaterial,
        confMaterial: applyShearMat || govRow.flexureRebarMaterial,
        clearCover: stored?.cover ?? 40,
        nw,
        nd,
        rebarSize: String(mainDia),
        rebarDiameter: mainDia,
        confBarSize: String(confDia),
        confBarDiameter: confDia,
        confSpacing,
        aMod: parseMod(applyAMod, 1),
        a2Mod: parseMod(applyA2Mod, 1),
        a3Mod: parseMod(applyA3Mod, 1),
        jMod: parseMod(applyJMod, 1),
        i2Mod: parseMod(applyI2Mod, 1),
        i3Mod: parseMod(applyI3Mod, 1),
        mMod: 1,
        wMod: 1,
        uniqueNames,
      });
    }
    return { sections };
  };

  const handleFetchSelectedFrames = async () => {
    if (!selectedInstance || selectedInstance.PID === -1) return;
    setFetchingFrames(true);
    try {
      const result = await window.electronAPI.getSelectedFrames(selectedInstance.PID);
      if (result.success) {
        setSelectedFrameNames(result.frameNames);
        console.log('[Apply Scope] Selected frames from ETABS:', result.frameNames);
      } else {
        console.error('[Apply Scope] Failed to get selected frames:', result.error);
        setSelectedFrameNames([]);
      }
    } catch (e) {
      console.error('[Apply Scope] Error:', e);
      setSelectedFrameNames([]);
    } finally {
      setFetchingFrames(false);
    }
  };

  const handleApply = async () => {
    if (!selectedInstance || selectedInstance.PID === -1) return;
    setApplyLoading(true);
    setApplyResult(null);
    try {
      const payload = buildApplyPayload();
      const result = await window.electronAPI.applyColumnProperties(selectedInstance.PID, payload);
      setApplyResult(result);
    } catch (e: unknown) {
      setApplyResult({ success: false, error: String(e) });
    } finally {
      setApplyLoading(false);
    }
  };

  const renderApplyPopup = () => {
    if (!showApplyPopup) return null;
    const previewGroups = getApplyGroups();
    const previewRows = previewGroups.map(g => {
      const labels = g.columns.map(gc => gc.label);
      const allGroupRows = columns.filter(c => labels.includes(c.label));
      if (allGroupRows.length === 0) return null;
      const govRow = allGroupRows.reduce((a, b) => b.requiredAs > a.requiredAs ? b : a);
      const storeKey = `${govRow.label}|${govRow.story}`;
      const stored = columnDataStore.get(storeKey);
      let solLabel: string;
      if (stored) {
        const tag = stored.isModified ? ' (modified)' : '';
        solLabel = stored.cornerDia !== stored.mainDia
          ? `${stored.barsWidth * 2 + stored.barsDepth * 2 - 4}×Ø${stored.mainDia}+4×Ø${stored.cornerDia}${tag}`
          : `${stored.numBars}×Ø${stored.mainDia}${tag}`;
      } else {
        const { maxDia: _mxd2, minDia: _mnd2 } = getDiaConstraint(govRow.width, govRow.depth);
        const solved = solutionType === 's1'
          ? solveS1(govRow.totalBars, govRow.requiredAs, _mxd2, _mnd2)
          : solveS2(govRow.totalBars, govRow.requiredAs, _mxd2, _mnd2);
        solLabel = solved.cornerDia !== solved.mainDia
          ? `${govRow.totalBars - 4}×Ø${solved.mainDia}+4×Ø${solved.cornerDia}`
          : `${govRow.totalBars}×Ø${solved.mainDia}`;
      }
      const groupUniqueNames = [...new Set(allGroupRows.map(c => c.uniqueName))];
      return { g, govRow, solLabel, frameCount: groupUniqueNames.length, groupUniqueNames };
    }).filter(Boolean) as { g: ColumnGroup; govRow: import('@/types/electron').ColumnDesignRow; solLabel: string; frameCount: number; groupUniqueNames: string[] }[];
    const filteredPreviewRows = applyScope === 'selected'
      ? previewRows.filter(row => row.groupUniqueNames.some(n => selectedFrameNames.includes(n)))
      : previewRows;

    const inputCls = "w-full h-8 px-3 rounded-lg bg-white border border-gray-300 text-xs text-gray-900 outline-none focus:border-red-400 focus:ring-1 focus:ring-red-100";
    const labelCls = "text-[10px] font-semibold uppercase text-gray-400 mb-1.5";

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
        <div className="w-[680px] max-h-[88vh] flex flex-col rounded-2xl bg-white border border-gray-200 shadow-2xl overflow-hidden">

          {/* Header */}
          <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between shrink-0" style={{ borderLeftWidth: 3, borderLeftColor: categoryColor }}>
            <div>
              <div className="text-sm font-semibold text-gray-900">Apply Properties to ETABS</div>
              <div className="text-xs text-gray-400 mt-0.5">Creates frame sections and assigns them to column objects</div>
            </div>
            <button onClick={() => { setShowApplyPopup(false); setApplyResult(null); }}
              className="text-gray-400 hover:text-gray-700 transition-colors text-xl leading-none w-7 h-7 flex items-center justify-center rounded-lg hover:bg-gray-100">×</button>
          </div>

          <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-5 min-h-0">

            {/* Scope: All vs Selected */}
            <div>
              <div className={labelCls}>Apply To</div>
              <div className="flex gap-2">
                <button
                  onClick={() => { setApplyScope('all'); setSelectedFrameNames([]); }}
                  className={`flex-1 h-8 rounded-lg border text-xs font-medium transition-colors ${applyScope === 'all' ? 'bg-red-500 border-red-500 text-white' : 'bg-white border-gray-300 text-gray-600 hover:border-gray-400'}`}
                >
                  All Columns
                </button>
                <button
                  onClick={() => setApplyScope('selected')}
                  className={`flex-1 h-8 rounded-lg border text-xs font-medium transition-colors ${applyScope === 'selected' ? 'bg-red-500 border-red-500 text-white' : 'bg-white border-gray-300 text-gray-600 hover:border-gray-400'}`}
                >
                  Selected Columns
                </button>
              </div>
              {applyScope === 'selected' && (
                <div className="mt-2 flex items-center gap-2">
                  <button
                    onClick={handleFetchSelectedFrames}
                    disabled={fetchingFrames}
                    className="h-7 px-3 rounded-lg bg-gray-100 border border-gray-300 text-xs text-gray-700 hover:bg-gray-200 disabled:opacity-50 transition-colors"
                  >
                    {fetchingFrames ? 'Fetching…' : 'Fetch from ETABS'}
                  </button>
                  <span className="text-xs text-gray-500">
                    {selectedFrameNames.length > 0
                      ? `${selectedFrameNames.length} frame${selectedFrameNames.length > 1 ? 's' : ''} selected`
                      : 'Select columns in ETABS then click Fetch'}
                  </span>
                </div>
              )}
            </div>

            {/* Row 1: Section Prefix */}
            <div>
              <div className={labelCls}>Section Prefix</div>
              <input value={applyNamePrefix} onChange={e => setApplyNamePrefix(e.target.value)} className={inputCls} />
            </div>

            {/* Row 2: Material dropdowns */}
            {materialsLoading ? (
              <div className="text-xs text-gray-400 py-1">Loading materials from ETABS…</div>
            ) : (
              <div className="flex gap-3">
                {/* Concrete Grade */}
                <div className="flex-1">
                  <div className={labelCls}>Concrete Grade</div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="w-full h-8 px-3 rounded-lg bg-white border border-gray-300 text-xs text-gray-900 flex items-center justify-between outline-none hover:border-gray-400">
                        <span className={applyConcreteMat ? 'text-gray-900' : 'text-gray-400'}>
                          {applyConcreteMat || (previewRows[0]?.govRow.concreteMaterial ?? '— from data —')}
                        </span>
                        <ChevronDown className="h-3 w-3 opacity-40 ml-1 shrink-0" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" className="max-h-48 overflow-y-auto">
                      <DropdownMenuItem onClick={() => setApplyConcreteMat('')} className="text-xs text-gray-400 italic">— use from data —</DropdownMenuItem>
                      {concreteMaterialList.map(m => (
                        <DropdownMenuItem key={m} onClick={() => setApplyConcreteMat(m)} className="text-xs">
                          {applyConcreteMat === m && <Check className="h-3 w-3 mr-1.5" style={{ color: categoryColor }} />}
                          {applyConcreteMat !== m && <span className="w-4 mr-0.5" />}
                          {m}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                {/* Flexure Grade */}
                <div className="flex-1">
                  <div className={labelCls}>Flexure Grade</div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="w-full h-8 px-3 rounded-lg bg-white border border-gray-300 text-xs text-gray-900 flex items-center justify-between outline-none hover:border-gray-400">
                        <span className={applyFlexureMat ? 'text-gray-900' : 'text-gray-400'}>
                          {applyFlexureMat || (previewRows[0]?.govRow.flexureRebarMaterial ?? '— from data —')}
                        </span>
                        <ChevronDown className="h-3 w-3 opacity-40 ml-1 shrink-0" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" className="max-h-48 overflow-y-auto">
                      <DropdownMenuItem onClick={() => setApplyFlexureMat('')} className="text-xs text-gray-400 italic">— use from data —</DropdownMenuItem>
                      {rebarMaterialList.map(m => (
                        <DropdownMenuItem key={m} onClick={() => setApplyFlexureMat(m)} className="text-xs">
                          {applyFlexureMat === m && <Check className="h-3 w-3 mr-1.5" style={{ color: categoryColor }} />}
                          {applyFlexureMat !== m && <span className="w-4 mr-0.5" />}
                          {m}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                {/* Shear Grade */}
                <div className="flex-1">
                  <div className={labelCls}>Shear Grade</div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="w-full h-8 px-3 rounded-lg bg-white border border-gray-300 text-xs text-gray-900 flex items-center justify-between outline-none hover:border-gray-400">
                        <span className={applyShearMat ? 'text-gray-900' : 'text-gray-400'}>
                          {applyShearMat || (previewRows[0]?.govRow.flexureRebarMaterial ?? '— from data —')}
                        </span>
                        <ChevronDown className="h-3 w-3 opacity-40 ml-1 shrink-0" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" className="max-h-48 overflow-y-auto">
                      <DropdownMenuItem onClick={() => setApplyShearMat('')} className="text-xs text-gray-400 italic">— use from data —</DropdownMenuItem>
                      {rebarMaterialList.map(m => (
                        <DropdownMenuItem key={m} onClick={() => setApplyShearMat(m)} className="text-xs">
                          {applyShearMat === m && <Check className="h-3 w-3 mr-1.5" style={{ color: categoryColor }} />}
                          {applyShearMat !== m && <span className="w-4 mr-0.5" />}
                          {m}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            )}

            {/* Row 3: Stiffness modifiers (6) — blank = use from data */}
            <div>
              <div className={labelCls}>Stiffness Modifiers <span className="normal-case font-normal text-gray-300">(blank = from design data)</span></div>
              <div className="grid grid-cols-6 gap-2">
                {([
                  ['A', applyAMod, setApplyAMod],
                  ['As2', applyA2Mod, setApplyA2Mod],
                  ['As3', applyA3Mod, setApplyA3Mod],
                  ['J', applyJMod, setApplyJMod],
                  ['I22', applyI2Mod, setApplyI2Mod],
                  ['I33', applyI3Mod, setApplyI3Mod],
                ] as [string, string, (v: string) => void][]).map(([name, val, setter]) => (
                  <div key={name}>
                    <div className="text-[9px] text-gray-400 mb-1 font-medium">{name}</div>
                    <input
                      type="number" step="0.05" min="0" max="1"
                      value={val}
                      onChange={e => setter(e.target.value)}
                      placeholder={name.startsWith('I') || name === 'J' ? '0.70' : '1.00'}
                      className="w-full h-7 px-2 rounded-md bg-white border border-gray-300 text-xs text-gray-900 text-center outline-none focus:border-red-400 focus:ring-1 focus:ring-red-100"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Preview table */}
            {filteredPreviewRows.length > 0 && (
              <div>
                <div className={labelCls}>Preview ({filteredPreviewRows.length} sections)</div>
                <div className="rounded-xl border border-gray-200 overflow-hidden">
                  <div className="flex bg-gray-50 border-b border-gray-200 text-[9px] font-semibold uppercase text-gray-400">
                    <div className="w-14 shrink-0 px-3 py-2">Group</div>
                    <div className="flex-1 px-3 py-2">Section Name</div>
                    <div className="w-24 shrink-0 px-3 py-2">Size</div>
                    <div className="flex-1 px-3 py-2">Rebar</div>
                    <div className="w-16 shrink-0 px-3 py-2 text-right">Frames</div>
                  </div>
                  {filteredPreviewRows.map(({ g, govRow, solLabel, frameCount }) => (
                    <div key={g.displayId} className="flex border-b border-gray-100 last:border-b-0 text-xs hover:bg-gray-50">
                      <div className="w-14 shrink-0 px-3 py-2 font-semibold" style={{ color: categoryColor }}>{g.displayId}</div>
                      <div className="flex-1 px-3 py-2 font-mono text-[10px] text-gray-500">
                        {applyNamePrefix}_{g.displayId}_{govRow.width}x{govRow.depth}
                      </div>
                      <div className="w-24 shrink-0 px-3 py-2 font-mono text-[10px] text-gray-700">{govRow.width}×{govRow.depth}</div>
                      <div className="flex-1 px-3 py-2 font-mono text-[10px]">
                        <span className={solLabel.includes('modified') ? '' : 'text-gray-800'}
                          style={solLabel.includes('modified') ? { color: categoryColor } : {}}>
                          {solLabel}
                        </span>
                      </div>
                      <div className="w-16 shrink-0 px-3 py-2 text-right font-mono text-[10px] text-gray-500">{frameCount}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {filteredPreviewRows.length === 0 && columns.length > 0 && (
              <div className="text-xs text-gray-400 text-center py-4 border border-dashed border-gray-200 rounded-xl">
                {applyScope === 'selected' && selectedFrameNames.length === 0
                  ? 'No frames fetched yet. Select columns in ETABS then click Fetch.'
                  : 'No groups found. Configure grouping in the Detailing tab first.'}
              </div>
            )}

            {/* Result feedback */}
            {applyResult && (
              <div className={cn(
                "text-xs px-4 py-3 rounded-xl border",
                applyResult.success
                  ? "bg-green-50 border-green-200 text-green-700"
                  : "bg-red-50 border-red-200 text-red-600"
              )}>
                {applyResult.success ? applyResult.message : applyResult.error}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-5 py-4 border-t border-gray-100 flex justify-between items-center shrink-0 bg-gray-50/50">
            <button onClick={() => { setShowApplyPopup(false); setApplyResult(null); }}
              className="text-xs text-gray-500 hover:text-gray-700 transition-colors px-4 py-2 rounded-lg border border-gray-200 hover:border-gray-300 bg-white">
              Cancel
            </button>
            <Button size="sm"
              onClick={handleApply}
              disabled={applyLoading || filteredPreviewRows.length === 0 || !selectedInstance || selectedInstance.PID === -1}
              style={{ backgroundColor: categoryColor }}
              className="text-xs text-white gap-2">
              {applyLoading ? 'Applying…' : 'Apply to ETABS'}
            </Button>
          </div>
        </div>
      </div>
    );
  };

  // ── Check Design matrix (story rows × column label columns, same style as Detailing) ──
  const renderCheckSchedule = () => {
    // Only rows that have an explicit check designation (non-empty designOpt that is not "Design")
    const checkRows = filtered.filter(r => r.designOpt && r.designOpt !== 'Design');
    if (checkRows.length === 0) {
      return <div className="flex-1 flex items-center justify-center text-muted-foreground text-xs">No check-design columns found</div>;
    }
    // Column labels that appear in check rows, preserving matrixLabels order, with optional filter
    const checkFilterLower = checkFilter.toLowerCase().trim();
    const checkLabels = matrixLabels.filter(lbl =>
      checkRows.some(r => r.label === lbl) &&
      (!checkFilterLower || lbl.toLowerCase().includes(checkFilterLower))
    );
    // Build lookup: story|label → row
    const checkMap = new Map<string, ColumnDesignRow>();
    checkRows.forEach(r => checkMap.set(`${r.story}|${r.label}`, r));
    const COL_W = 128;
    return (
      <div className="flex-1 rounded-xl border border-slate-200 overflow-hidden bg-white min-h-0" style={{ boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
        <div className="h-full overflow-auto">
          <table className="border-collapse" style={{ minWidth: 'max-content', height: '100%' }}>
            <tbody>
              {/* spacer pushes data rows down */}
              <tr style={{ height: '100%' }}><td colSpan={checkLabels.length + 1} /></tr>
              {[...matrixStories].map((story, si) => {
                const rowBg = si % 2 === 0 ? '#f8fafc' : '#ffffff';
                return (
                <tr key={story}
                  style={{ borderBottom: '1px solid #e2e8f0', background: rowBg }}
                  onMouseEnter={e => (e.currentTarget.style.background = '#eff6ff')}
                  onMouseLeave={e => (e.currentTarget.style.background = rowBg)}>
                  <td className="sticky left-0 z-10 px-3 py-2 text-xs font-semibold bg-white"
                    style={{ color: '#1e293b', width: 96, minWidth: 96, borderRight: '2px solid #e2e8f0' }}>{story}</td>
                  {checkLabels.map((label) => {
                    const r = checkMap.get(`${story}|${label}`);
                    if (!r) return (
                      <td key={label} className="px-2 py-1.5 align-top"
                        style={{ width: COL_W, minWidth: COL_W, borderRight: '1px solid #e2e8f0' }}>
                        <span style={{ color: '#cbd5e1', fontSize: 12 }}>–</span>
                      </td>
                    );
                    {
                      const cellKey = `${r.story}|${r.label}`;
                      const cellSt  = checkCellStatuses.get(cellKey) ?? 'untouched';
                      const ov      = checkCellOverrides.get(cellKey);
                      const flexProv = ov ? ov.flexProv : computeCheckProvidedAs(r);
                      const dcRatio  = r.requiredAs > 0 && flexProv > 0 ? flexProv / r.requiredAs : 0;
                      const pmm      = pmmMatrix.get(cellKey) ?? 0;
                      const statusBg = cellSt === 'done'
                        ? 'linear-gradient(135deg, rgba(228,252,237,1) 50%, transparent 50%)'
                        : cellSt === 'hold'
                        ? 'linear-gradient(-45deg, rgba(253,239,193,1) 50%, transparent 50%)'
                        : undefined;
                      return (
                        <td key={label}
                          className="px-2 py-1.5 cursor-pointer align-top"
                          style={{ width: COL_W, minWidth: COL_W, borderRight: '1px solid #e2e8f0', background: statusBg }}
                          onMouseEnter={e => { if (!statusBg) e.currentTarget.style.background = '#dbeafe'; }}
                          onMouseLeave={e => { if (!statusBg) e.currentTarget.style.background = ''; }}
                          onClick={() => setSelectedCheckRow(r)}>
                          <div className="flex gap-0 h-full">
                            {/* Left: bar info */}
                            <div className="flex flex-col gap-[3px] flex-1 min-w-0 pr-1">
                              <span className="text-[10px] font-mono leading-tight truncate" style={{ color: '#94a3b8' }} title={r.sectionName}>
                                {r.sectionName}
                              </span>
                              <span className="text-[11px] font-mono leading-tight">
                                <span style={{ color: '#64748b', fontWeight: 500 }}>L </span>
                                <span style={{ color: '#1e293b', fontWeight: 700 }}>{ov ? `T${ov.params.mainDia}` : formatBarWithT(r.checkLongBarSize)}</span>
                                {(ov ? ov.params.cornerDia !== ov.params.mainDia : r.checkCornerBarSize && r.checkCornerBarSize !== r.checkLongBarSize) &&
                                  <><span style={{ color: '#94a3b8' }}>/</span><span style={{ color: '#64748b', fontWeight: 500 }}>C </span><span style={{ color: '#1e293b', fontWeight: 700 }}>{ov ? `T${ov.params.cornerDia}` : formatBarWithT(r.checkCornerBarSize)}</span></>}
                              </span>
                              <span className="text-[11px] font-mono leading-tight">
                                <span style={{ color: '#64748b', fontWeight: 500 }}>T </span>
                                <span style={{ color: '#1e293b', fontWeight: 700 }}>{ov ? `T${ov.params.stirrupDia}` : formatBarWithT(r.checkTieBarSize)}</span>
                                {(ov ? ov.params.stirrupSpacing : r.checkTieSpacing) ? <span style={{ color: '#94a3b8' }}> @{ov ? ov.params.stirrupSpacing : r.checkTieSpacing}</span> : ''}
                              </span>
                              <span className="text-[10px] font-mono leading-tight" style={{ color: '#94a3b8' }}>
                                {ov ? `${ov.params.numRings * 2}×3 / ${ov.params.numRings * 2}×2` : `${r.checkNumTies3Dir || '—'}×3 / ${r.checkNumTies2Dir || '—'}×2`}
                              </span>
                            </div>
                            {/* Divider */}
                            <div style={{ width: 1, background: '#e2e8f0', flexShrink: 0, margin: '1px 4px' }} />
                            {/* Right: ratios */}
                            <div className="flex flex-col gap-[5px] justify-center shrink-0" style={{ minWidth: 38 }}>
                              <div className="text-[10px] font-mono leading-tight">
                                <span style={{ color: '#94a3b8' }}>P </span>
                                <span className="font-bold" style={{ color: pmmRatioTextColor(pmm) }}>
                                  {pmm > 0 ? pmm.toFixed(2) : '—'}
                                </span>
                              </div>
                              <div className="text-[10px] font-mono leading-tight">
                                <span style={{ color: '#94a3b8' }}>D/C </span>
                                <span className="font-bold" style={{ color: getRatioColor(dcRatio) }}>
                                  {dcRatio > 0 ? dcRatio.toFixed(2) : '—'}
                                </span>
                              </div>
                            </div>
                          </div>
                        </td>
                      );
                    }
                  })}
                </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr>
                <th className="sticky bottom-0 left-0 z-30 px-3 py-2.5 text-[10px] font-semibold uppercase tracking-wider text-left"
                  style={{ width: 96, background: '#f1f5f9', color: '#475569', borderTop: '2px solid #e2e8f0', borderRight: '2px solid #e2e8f0' }}>Story</th>
                {checkLabels.map(label => (
                  <th key={label} className="sticky bottom-0 z-20 px-3 py-2.5 text-[10px] font-semibold uppercase tracking-wider text-center"
                    style={{ width: COL_W, background: '#f1f5f9', color: '#475569', borderTop: '2px solid #e2e8f0', borderRight: '1px solid #e2e8f0' }}>
                    {label}
                  </th>
                ))}
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    );
  };

  // ── Detailing / Design tab content ────────────────────────────────────────
  const renderDetailingContent = () => majorityMode === 'Check' ? renderCheckSchedule() : renderColumnGroupedTable();

  // Controls shown in the tab header for Detailing tab
  const CRITERIA_LABELS: [keyof GroupingCriteria, string][] = [
    ['size', 'Column Size'],
    ['concreteGrade', 'Concrete Grade'],
    ['flexureGrade', 'Flexure Grade'],
    ['shearGrade', 'Shear Grade'],
    ['story', 'Story'],
  ];

  const renderDetailingControls = () => (
    <div className="pb-2 flex flex-col gap-1.5 relative">
      {/* Top row: Filter + Solution dropdown + Set Limit button */}
      <div className="flex items-center gap-2 justify-end">
        {skippedColumns.length > 0 && (
          <Button
            variant="outline" size="sm"
            className="h-8 text-xs gap-1.5 border-amber-400/60 text-amber-300 bg-amber-400/10 hover:bg-amber-400/20"
            onClick={() => setShowSkippedModal(true)}
          >
            <AlertTriangle className="h-3 w-3" />
            {skippedColumns.length} skipped
          </Button>
        )}
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground pointer-events-none" />
          <input
            type="text"
            placeholder="Filter columns…"
            value={columnFilter}
            onChange={e => setColumnFilter(e.target.value)}
            className="h-8 w-44 text-xs pl-7 pr-3 rounded-lg bg-background border border-border/50 text-foreground placeholder:text-muted-foreground/60 outline-none focus:border-border focus:ring-1 focus:ring-border/40 transition-colors"
          />
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="h-8 text-xs gap-2 bg-surface/60 border-border/40">
              {solutionType === 's1' ? 'S1 — Uniform bars' : 'S2 — Corner bars differ'}
              <ChevronDown className="h-3 w-3 opacity-50" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {(['s1', 's2'] as SolutionType[]).map(type => (
              <DropdownMenuItem key={type} onClick={() => setSolutionType(type)} className="flex items-center gap-2 text-xs">
                {solutionType === type && <Check className="h-3 w-3" style={{ color: categoryColor }} />}
                {solutionType !== type && <span className="w-3" />}
                {type === 's1' ? 'S1 — Uniform bars' : 'S2 — Corner bars differ'}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
        <div className="relative">
          <Button variant="outline" size="sm" className="h-8 text-xs gap-1.5 bg-surface/60 border-border/40"
            onClick={() => setShowGroupingPopup(p => !p)}>
            <Settings className="h-3 w-3 opacity-70" />
            Set Limit
          </Button>
          {showGroupingPopup && renderGroupingPopup()}
        </div>
      </div>
      {/* Grouping criteria checkboxes */}
      <div className="flex items-center gap-3 flex-wrap">
        <span className="text-[9px] font-semibold uppercase tracking-wider" style={{ color: 'rgba(255,255,255,0.35)' }}>Group by:</span>
        {CRITERIA_LABELS.map(([key, label]) => (
          <label key={key} className="flex items-center gap-1 cursor-pointer">
            <input
              type="checkbox"
              checked={groupingCriteria[key]}
              onChange={e => handleCriteriaChange(key, e.target.checked)}
              className="w-3 h-3 rounded"
              style={{ accentColor: categoryColor }}
            />
            <span className="text-[10px] text-muted-foreground select-none">{label}</span>
          </label>
        ))}
      </div>
    </div>
  );

  // ── Render ────────────────────────────────────────────────────────────────
  const TABS: Tab[] = ["Section Details", "Reinforcement Ratio", "Detailing"];
  const BOTTOM_HEIGHT = 44;
  const BOTTOM_OFFSET = 24;
  const MARGIN_ABOVE = 5;

  return (
    <TooltipProvider>
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className={cn("fixed inset-0 z-30 flex flex-col overflow-hidden", className)}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="absolute inset-x-0 top-0 pl-6 pr-12 pb-6 pt-20 overflow-hidden"
          style={{ bottom: `${BOTTOM_HEIGHT + BOTTOM_OFFSET + MARGIN_ABOVE}px` }}
        >
          <div className="h-full flex flex-col gap-4">
            {/* ── Top control bar ─────────────────────────────────────────── */}
            <div className="flex items-center gap-3 p-3 rounded-2xl bg-surface/60 backdrop-blur-md border border-border/30 shrink-0">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="h-9 text-xs w-[300px] justify-between bg-surface/60 border-border/40">
                    <span className="truncate">
                      {selectedInstance && selectedInstance.PID !== -1 ? selectedInstance.DisplayText : "Select ETABS Instance"}
                    </span>
                    <ChevronDown className="ml-2 h-4 w-4 opacity-50 shrink-0" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-[300px]">
                  {etabsInstances.map(inst => (
                    <DropdownMenuItem key={inst.PID}
                      onClick={() => { setSelectedInstance(inst); setIsConnected(false); setDataLoaded(false); }}
                      className="flex items-center gap-2">
                      {selectedInstance?.PID === inst.PID && <Check className="h-4 w-4" style={{ color: categoryColor }} />}
                      {selectedInstance?.PID !== inst.PID && <span className="w-4" />}
                      <span className="truncate flex-1 text-xs">{inst.DisplayText}</span>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="icon" onClick={handleConnectAndLoad} disabled={isLoading}
                    className="h-9 w-9 shrink-0 outline-none hover:opacity-80 transition-opacity"
                    style={{ backgroundColor: dataLoaded ? "#22c55e" : categoryColor, color: "white" }}>
                    <Play className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent><p>{dataLoaded ? "Reload Data" : "Connect & Load Data"}</p></TooltipContent>
              </Tooltip>

              <div className="flex-1" />
              {dataLoaded && (
                <span className="text-xs px-3 py-1 rounded-lg bg-surface/40 border border-border/30 text-muted-foreground mr-2">
                  {columns.length} columns loaded
                </span>
              )}
              {dataLoaded && (
                <Button size="sm" variant="outline" onClick={exportToExcel}
                  className="h-9 text-xs px-3 gap-1.5 bg-surface/60 border-border/40 hover:bg-surface/80">
                  <Download size={12} /> Export Excel
                </Button>
              )}
            </div>

            {/* ── Content area ───────────────────────────────────────────── */}
            <div className="flex-1 flex gap-4 min-h-0">
              {isLoading ? (
                <div className="flex-1 flex flex-col items-center justify-center p-6 rounded-2xl bg-surface/60 backdrop-blur-md border border-border/30 space-y-4">
                  <IcosahedronLoader />
                  <p className="text-sm text-muted-foreground">{loadingStage}</p>
                </div>
              ) : !dataLoaded ? (
                <div className="flex-1 flex flex-col items-center justify-center p-6 rounded-2xl bg-surface/60 backdrop-blur-md border border-border/30 gap-3 text-muted-foreground">
                  <div className="w-12 h-12 rounded-2xl border border-border/40 flex items-center justify-center mb-2 bg-surface/40">
                    <Play size={20} style={{ color: categoryColor, opacity: 0.8 }} />
                  </div>
                  <p className="text-sm">Connect to ETABS and click <span style={{ color: categoryColor }} className="font-medium">Load</span></p>
                  <p className="text-xs opacity-70">Reads column sections, materials, and ACI 318-19 design results</p>
                </div>
              ) : (
                <div className="flex-1 flex flex-col min-h-0 rounded-2xl bg-surface/60 backdrop-blur-md border border-border/30 overflow-hidden">
                  {/* Main tab bar */}
                  <div className="flex items-center justify-between gap-6 px-6 pt-4 pb-0 border-b border-border/20 bg-surface/20 shrink-0">
                    <div className="flex gap-5">
                      {TABS.map(tab => (
                        <button key={tab} onClick={() => { setActiveTab(tab); setShowGroupingPopup(false); setShowPmmColorPicker(false); }}
                          className={cn(
                            "text-xs font-medium pb-3 transition-colors border-b-2 relative top-[1px] outline-none whitespace-nowrap",
                            activeTab === tab ? "text-foreground border-current" : "text-muted-foreground border-transparent hover:text-foreground/80"
                          )}
                          style={activeTab === tab ? { color: categoryColor, borderColor: categoryColor } : {}}>
                          {tab === "Reinforcement Ratio" && majorityMode === 'Check' ? 'D/C Ratio' : tab}
                        </button>
                      ))}
                      {/* Apply Prop button — opens popup */}
                      <button onClick={async () => {
                        setShowApplyPopup(true); setApplyResult(null); setApplyScope('all'); setSelectedFrameNames([]);
                        if (selectedInstance && selectedInstance.PID !== -1 && concreteMaterialList.length === 0) {
                          setMaterialsLoading(true);
                          try {
                            const [cRes, rRes] = await Promise.all([
                              window.electronAPI.getConcreteMaterials(selectedInstance.PID),
                              window.electronAPI.getRebarMaterials(selectedInstance.PID),
                            ]);
                            if (cRes.success && cRes.materials) setConcreteMaterialList(cRes.materials.map(m => m.name));
                            if (rRes.success && rRes.materials) setRebarMaterialList(rRes.materials.map(m => m.name));
                          } finally { setMaterialsLoading(false); }
                        }
                      }}
                        className="text-xs font-medium pb-3 transition-colors border-b-2 border-transparent relative top-[1px] outline-none whitespace-nowrap text-muted-foreground hover:text-foreground/80">
                        Apply Prop
                      </button>
                    </div>

                    {/* ── Mode indicator (center) ─────────────────── */}
                    <div className="flex-1 flex justify-center pb-2">
                      {majorityMode && (
                        <span
                          className="text-[10px] font-semibold px-3 py-1 rounded-full border tracking-wide"
                          style={majorityMode === 'Design'
                            ? { background: 'rgba(251,146,60,0.12)', color: '#f97316', border: '1px solid rgba(251,146,60,0.35)' }
                            : { background: 'rgba(20,184,166,0.12)', color: '#14b8a6', border: '1px solid rgba(20,184,166,0.35)' }
                          }>
                          {majorityMode === 'Design' ? '⬤ To Be Designed' : '⬤ To Be Checked'}
                        </span>
                      )}
                    </div>

                    {/* Tab-specific controls */}
                    {activeTab === "Section Details" && (
                      <div className="pb-2">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="outline" size="sm" className="h-8 text-xs gap-2 bg-surface/60 border-border/40">
                              {sectionProperty} <ChevronDown className="h-3 w-3 opacity-50" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {SECTION_PROPERTIES.map(p => (
                              <DropdownMenuItem key={p} onClick={() => setSectionProperty(p)} className="flex items-center gap-2 text-xs">
                                {sectionProperty === p && <Check className="h-3 w-3" style={{ color: categoryColor }} />}
                                {sectionProperty !== p && <span className="w-3" />}
                                {p}
                              </DropdownMenuItem>
                            ))}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    )}
                    {activeTab === "Reinforcement Ratio" && (
                      <div className="flex items-center gap-2 pb-2">
                        <div className="relative">
                          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground pointer-events-none" />
                          <input
                            type="text"
                            placeholder="Filter columns…"
                            value={columnFilter}
                            onChange={e => setColumnFilter(e.target.value)}
                            className="h-8 w-44 text-xs pl-7 pr-3 rounded-lg bg-background border border-border/50 text-foreground placeholder:text-muted-foreground/60 outline-none focus:border-border focus:ring-1 focus:ring-border/40 transition-colors"
                          />
                        </div>
                        {renderPmmColorPicker()}
                      </div>
                    )}
                    {activeTab === "Detailing" && majorityMode === 'Check' && (
                      <div className="pb-2 flex items-center gap-2 justify-end">
                        <div className="relative">
                          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground pointer-events-none" />
                          <input
                            type="text"
                            placeholder="Filter columns…"
                            value={checkFilter}
                            onChange={e => setCheckFilter(e.target.value)}
                            className="h-8 w-44 text-xs pl-7 pr-3 rounded-lg bg-background border border-border/50 text-foreground placeholder:text-muted-foreground/60 outline-none focus:border-border focus:ring-1 focus:ring-border/40 transition-colors"
                          />
                        </div>
                      </div>
                    )}
                    {activeTab === "Detailing" && majorityMode !== 'Check' && renderDetailingControls()}
                  </div>

                  <div className="flex-1 overflow-hidden p-4 flex flex-col min-h-0">
                    <AnimatePresence mode="wait">

                      {activeTab === "Section Details" && (
                        <motion.div key="tab-section"
                          initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                          className="flex-1 flex flex-col min-h-0">
                          {renderSectionMatrix()}
                        </motion.div>
                      )}

                      {activeTab === "Reinforcement Ratio" && (
                        <motion.div key="tab-pmm"
                          initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                          className="flex-1 flex flex-col min-h-0">
                          {renderPmmMatrix()}
                        </motion.div>
                      )}

                      {activeTab === "Detailing" && (
                        <motion.div key="tab-detailing"
                          initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                          className="flex-1 flex flex-col min-h-0">
                          {renderDetailingContent()}
                        </motion.div>
                      )}

                    </AnimatePresence>
                  </div>
                </div>
              )}
            </div>
          </div>
        </motion.div>

        {/* Apply Prop popup */}
        {renderApplyPopup()}

        {/* Breadcrumb */}
        <motion.div
          initial={{ x: -200, opacity: 0 }} animate={{ x: 0, opacity: 1 }}
          transition={{ type: "spring", damping: 20, stiffness: 120, delay: 0.2 }}
          className="fixed bottom-6 left-[105px] z-40 h-11 flex items-center gap-[5px]"
        >
          <div className="flex items-center gap-2 px-3 h-full rounded-xl bg-surface/60 backdrop-blur-md border" style={{ borderColor: categoryColor }}>
            <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: categoryColor }} />
            <span className="text-sm font-medium" style={{ color: categoryColor }}>Column Design</span>
          </div>
        </motion.div>

        {/* Back button */}
        <Tooltip>
          <TooltipTrigger asChild>
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.3 }}
              onClick={onBack}
              className="fixed bottom-6 right-6 z-40 w-11 h-11 rounded-xl bg-surface/60 backdrop-blur-md border flex items-center justify-center hover:bg-surface/80 transition-colors"
              style={{ borderColor: categoryColor }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={categoryColor} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m12 19-7-7 7-7" /><path d="M19 12H5" />
              </svg>
            </motion.button>
          </TooltipTrigger>
          <TooltipContent>Back</TooltipContent>
        </Tooltip>
      </motion.div>

      {/* Column detail popup */}
      {selectedGroupDetail && (() => {
        const subs = groupSubDetails.get(selectedGroupDetail.group.displayId) ?? [];
        const activeSub = subs.find(s => s.id === activeSubDetailId);
        const effectiveGroup = activeSub
          ? {
              ...selectedGroupDetail.group,
              displayId: `${selectedGroupDetail.group.displayId}::${activeSubDetailId}`,
              columns: selectedGroupDetail.group.columns.filter(c => activeSub.columnLabels.includes(c.label)),
            }
          : selectedGroupDetail.group;
        const affectedLabels = effectiveGroup.columns.map(c => c.label);
        // Find entry for this group+story to pre-populate popup.
        // Prefer modified entries (user data) over auto-computed ones.
        const popupInitialParams = (() => {
          const story = selectedGroupDetail.story;
          let modifiedEntry: ColumnDetailData | undefined;
          let govEntry: ColumnDetailData | undefined;
          for (const label of affectedLabels) {
            const entry = columnDataStore.get(`${label}|${story}`);
            if (!entry) continue;
            if (entry.isModified) {
              if (!modifiedEntry || entry.requiredAs > modifiedEntry.requiredAs) modifiedEntry = entry;
            }
            if (!govEntry || entry.requiredAs > govEntry.requiredAs) govEntry = entry;
          }
          const source = modifiedEntry ?? govEntry;
          if (!source) return undefined;
          return {
            barsWidth: source.barsWidth, barsDepth: source.barsDepth,
            mainDia: source.mainDia, cornerDia: source.cornerDia,
            cover: source.cover, stirrupDia: source.stirrupDia,
            stirrupSpacing: source.stirrupSpacing, numRings: source.numRings,
          } satisfies SubDetailParams;
        })();
        const { maxDia: popupMaxDia, minDia: popupMinDia } = (() => {
          const govRow = effectiveGroup.columns
            .map(gc => gc.row)
            .reduce((a, b) => b.requiredAs > a.requiredAs ? b : a);
          return getDiaConstraint(govRow.width, govRow.depth);
        })();
        return (
          <ColumnDetailPopup
            key={`${selectedGroupDetail.group.displayId}|${selectedGroupDetail.story}|${activeSubDetailId ?? 'main'}`}
            group={effectiveGroup}
            fullGroup={selectedGroupDetail.group}
            story={selectedGroupDetail.story}
            allColumns={columns}
            solutionType={solutionType}
            onUpdate={handleGroupUpdate}
            onStatusChange={handleStatusChange}
            onClose={() => { setSelectedGroupDetail(null); setActiveSubDetailId(null); }}
            subDetails={subs}
            activeSubDetailId={activeSubDetailId}
            onSelectSubDetail={setActiveSubDetailId}
            onAddSubDetail={(labels, id, storyArg) => handleAddSubDetail(selectedGroupDetail.group.displayId, labels, id, storyArg)}
            onDeleteSubDetail={(id) => handleDeleteSubDetail(selectedGroupDetail.group.displayId, id)}
            initialParams={popupInitialParams}
            onParamsChange={(params) => {
              const story = selectedGroupDetail.story;
              const bandKey = getStoryBandKey(story, storyBands, matrixStories);
              const affectedStories = getStoriesInBand(bandKey, storyBands, matrixStories);
              handleColumnDataUpdate(affectedLabels, affectedStories, params);
            }}
            maxDia={popupMaxDia}
            minDia={popupMinDia}
          />
        );
      })()}

      {/* Check Design detail popup */}
      {selectedCheckRow && (
        <CheckDesignPopup
          row={selectedCheckRow}
          pmmRatio={pmmMatrix.get(`${selectedCheckRow.story}|${selectedCheckRow.label}`) ?? 0}
          initialParams={checkCellOverrides.get(`${selectedCheckRow.story}|${selectedCheckRow.label}`)?.params}
          initialStatus={checkCellStatuses.get(`${selectedCheckRow.story}|${selectedCheckRow.label}`) ?? 'untouched'}
          onSave={handleCheckSave}
          onStatusChange={handleCheckStatusChange}
          onClose={() => setSelectedCheckRow(null)}
        />
      )}
      {/* Skipped Columns Modal */}
      <Dialog open={showSkippedModal} onOpenChange={setShowSkippedModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-400">
              <AlertTriangle className="h-4 w-4" />
              Skipped Columns ({skippedColumns.length})
            </DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground -mt-1">
            These columns were excluded from the schedule because required design data could not be found.
          </p>
          <div className="overflow-auto max-h-80 rounded-lg border border-border/40">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="bg-muted/40 text-muted-foreground sticky top-0">
                  <th className="text-left px-3 py-2 font-medium border-b border-border/40">Story</th>
                  <th className="text-left px-3 py-2 font-medium border-b border-border/40">Label</th>
                  <th className="text-left px-3 py-2 font-medium border-b border-border/40">Section</th>
                  <th className="text-left px-3 py-2 font-medium border-b border-border/40">Reason</th>
                </tr>
              </thead>
              <tbody>
                {skippedColumns.map((col, i) => (
                  <tr key={i} className="border-b border-border/20 hover:bg-muted/20">
                    <td className="px-3 py-2 font-mono">{col.story || '—'}</td>
                    <td className="px-3 py-2 font-mono">{col.label || '—'}</td>
                    <td className="px-3 py-2 text-muted-foreground">{col.sectionName || '—'}</td>
                    <td className="px-3 py-2 text-amber-400/80">{col.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </DialogContent>
      </Dialog>
    </TooltipProvider>
  );
};

export default ColumnDesignPage;
