export interface EtabsInstance {
  PID: number;
  DisplayText: string;
  Title: string;
}

export interface LoadCaseInfo {
  Name: string;
  Type: string; // "Load Case" or "Load Combo"
  DisplayText: string;
  ModeNumber: number;
  ScaleFactor: number;
  IsSelected: boolean;
}

export interface LoadingProgress {
  stage: string;
  tableName?: string;
}

export interface TableData {
  FieldNames: string[];
  DataArray: string[];
  NumberOfRecords: number;
}

export interface BaseShearAnalysisResult {
  loadCase: string;
  baseShearX: number;
  baseShearY: number;
  baseShearZ: number;
  baseMomentX: number;
  baseMomentY: number;
  baseMomentZ: number;
}

export interface BaseShearScaleFactorResult {
  loadCaseResults: BaseShearAnalysisResult[];
  scaleFactorX: number;
  scaleFactorY: number;
  requiredLoadCase: string;
  providedLoadCase: string;
}

// Wind Drift Analysis Result Row
export interface WindDriftResultRow {
  Story: string;
  Height: number;
  CumulativeHeight: number;
  LoadCombinationX: string;
  DriftX: number;
  DriftRatioX: number;
  X: number;
  Y: number;
  Z: number;
  DirX: string;
  CheckX: string;
  LoadCombinationY: string;
  DriftY: number;
  DriftRatioY: number;
  DirY: string;
  CheckY: string;
  LowerLimit: number;
  UpperLimit: number;
}

// Wind Displacement Analysis Result Row
export interface WindDisplacementResultRow {
  Story: string;
  Height: number;
  CumulativeHeight: number;
  LoadCombinationX: string;
  MaximumDisplacementX: number;
  AllowableDisplacementX: number;
  CheckX: string;
  LoadCombinationY: string;
  MaximumDisplacementY: number;
  AllowableDisplacementY: number;
  CheckY: string;
}

// Seismic Drift Analysis Result Row
export interface SeismicDriftResultRow {
  Story: string;
  Height: number;
  CumulativeHeight: number;
  LoadCombinationX: string;
  DriftX: number;
  MaximumDriftX: number;
  InelasticDispX: number;
  X: number;
  Y: number;
  Z: number;
  DirX: string;
  CheckX: string;
  PointLabelsX: string;
  LoadCombinationY: string;
  DriftY: number;
  MaximumDriftY: number;
  InelasticDispY: number;
  DirY: string;
  CheckY: string;
  PointLabelsY: string;
  CdValue: number;
  IValue: number;
  AllowableMultiplier: number;
  AllowableDrift: number;
}

// Seismic Deflection Analysis Result Row
export interface SeismicDeflectionResultRow {
  Story: string;
  Height: number;
  CumulativeHeight: number;
  LoadCombinationX: string;
  DriftX: number;
  DriftRatioX: number;
  X: number;
  Y: number;
  Z: number;
  DirX: string;
  CheckX: string;
  LoadCombinationY: string;
  DriftY: number;
  DriftRatioY: number;
  DirY: string;
  CheckY: string;
  LowerLimit: number;
  UpperLimit: number;
}

// Torsional Irregularity Analysis Result Row
export interface TorsionalIrregularityResultRow {
  Story: string;
  Height: number;
  CumulativeHeight: number;
  DirectionX: string;
  LoadCaseX: string;
  MaximumX: number;
  AverageX: number;
  RatioX: number;
  Aex: number;
  CheckX: string;
  WidthY: number;
  EccentricityX: number;
  EccRatioX: number;
  DirectionY: string;
  LoadCaseY: string;
  MaximumY: number;
  AverageY: number;
  RatioY: number;
  Aey: number;
  CheckY: string;
  WidthX: number;
  EccentricityY: number;
  EccRatioY: number;
}

// Diaphragm Checks Analysis Result Row
export interface DiaphragmChecksResultRow {
  Story: string;
  CumulativeHeight: number;
  RatioX: number;
  RatioY: number;
  StatusX: string;
  StatusY: string;
  CornerAvgX: number;
  CenterX: number;
  CornerAvgY: number;
  CenterY: number;
}

// Mass Irregularity Analysis Result Row
export interface MassIrregularityResultRow {
  Story: string;
  CumulativeHeight: number;
  Mass: number;
  Ratio: number;
  Status: string; // "SAFE" or "MASS_IRREGULAR"
}

// Stiffness Irregularity Analysis Result Row
export interface StiffnessIrregularityResultRow {
  Story: string;
  CumulativeHeight: number;
  StiffX: number;
  StiffY: number;
  RatioX: number;
  RatioY: number;
  StatusX: string; // "SAFE" or "SOFT_STORY"
  StatusY: string;
}

// Shear Wall Design Result Row
export interface ShearWallResultRow {
  Story: string;
  Pier: string;
  Length: number;
  Thickness: number;
  ReinfPercent: number;
  FlexureArea: number;
  FlexureSpacing: number;
  FlexureLayer1Dia: number;
  FlexureLayer1Count: number;
  FlexureLayer2Dia: number;
  FlexureLayer2Count: number;
  FlexureProvided: number;
  FlexureConfiguration: string;
  ShearArea: number;
  ShearSpacing: number;
  ShearLayer1Dia: number;
  ShearLayer1Count: number;
  ShearLayer2Dia: number;
  ShearLayer2Count: number;
  ShearProvided: number;
  ShearConfiguration: string;
  Controlling: string;
}

export interface ColumnDefinitionOptions {
  // ── cPropFrame.SetRectangle ──
  name: string;
  width: number;          // T2 (mm)
  depth: number;          // T3 (mm)
  material: string;       // MatProp
  rotation: number;

  // ── cPropFrame.SetRebarColumn ──
  rebarMaterial: string;  // MatPropLong
  confMaterial: string;   // MatPropConfine
  pattern: number;        // 1 = Rectangular (hardcoded)
  confineType: number;    // 1 = Ties (hardcoded)
  clearCover: number;     // Cover
  nW: number;             // NumberR3Bars
  nD: number;             // NumberR2Bars
  rebarSize: string;      // RebarSize label
  rebarDiameter: number;
  confBarSize: string;    // TieSize label
  confBarDiameter: number;
  confSpacing: number;    // TieSpacingLongit
  number2DirTieBars: number;
  number3DirTieBars: number;
  toBeDesigned: boolean;

  // ── cFrameObj.SetModifiers Value[0..7] ──
  aMod: number;
  a2Mod: number;
  a3Mod: number;
  jMod: number;
  i2Mod: number;
  i3Mod: number;
  mMod: number;
  wMod: number;
}

export interface ColumnDefinitionResult {
  success: boolean;
  message?: string;
  error?: string;
}

// ─── Get Selected Frames ───────────────────────────────────────────────────────

export interface GetSelectedFramesResult {
  success: boolean;
  frameNames: string[];
  error?: string;
}

// ─── Apply Column Properties ───────────────────────────────────────────────────

export interface ApplySectionOptions {
  sectionName: string;
  material: string;
  width: number;
  depth: number;
  rebarMaterial: string;
  confMaterial: string;
  clearCover: number;
  nw: number;
  nd: number;
  rebarSize: string;
  rebarDiameter: number;
  confBarSize: string;
  confBarDiameter: number;
  confSpacing: number;
  aMod: number; a2Mod: number; a3Mod: number; jMod: number;
  i2Mod: number; i3Mod: number; mMod: number; wMod: number;
  uniqueNames: string[];
}

export interface ApplyColumnPropertiesOptions {
  sections: ApplySectionOptions[];
}

export interface ApplyColumnPropertiesResult {
  success: boolean;
  message?: string;
  error?: string;
  sectionsApplied?: number;
  framesAssigned?: number;
}

export interface BeamDefinitionOptions {
  // ── cPropFrame.SetRectangle ──
  name: string;
  width: number;    // T2 (mm)
  depth: number;    // T3 (mm)
  material: string;

  // ── cPropFrame.SetRebarBeam ──
  rebarMaterial: string;  // MatPropLong
  confMaterial: string;   // MatPropConfine
  coverTop: number;       // mm — distance from top face to top rebar centroid
  coverBot: number;       // mm — distance from bot face to bot rebar centroid
  // TopLeftArea/TopRightArea/BotLeftArea/BotRightArea hardcoded 0 in backend

  // ── cFrameObj.SetModifiers Value[0..7] ──
  aMod: number;
  a2Mod: number;
  a3Mod: number;
  jMod: number;
  i2Mod: number;
  i3Mod: number;
  mMod: number;
  wMod: number;
}

export interface BeamDefinitionResult {
  success: boolean;
  message?: string;
  error?: string;
}

// ─── Column Design ────────────────────────────────────────────────────────────

export interface ColumnDesignRow {
  no: number;
  story: string;
  label: string;
  uniqueName: string;
  width: number;
  depth: number;
  sectionName: string;
  concreteMaterial: string;
  fc: number;
  flexureRebarMaterial: string;
  shearRebarMaterial: string;
  fy: number;
  totalBars: number;
  requiredAs: number;
  requiredVMinRebar: number;
  designOpt?: string;
  s1?: string;
  s2?: string;
  s3a?: string;
  s3b?: string;
  s4?: string;
  s1Area?: number;
  s2Area?: number;
  s3aArea?: number;
  s3bArea?: number;
  s4Area?: number;
  // Check mode: assigned bar data from ETABS section definition
  checkLongBarSize?: string;
  checkCornerBarSize?: string;
  checkTieBarSize?: string;
  checkTieSpacing?: number;
  checkNumTies2Dir?: number;
  checkNumTies3Dir?: number;
}

export interface ColumnPmmRow {
  story: string;
  label: string;
  uniqueName: string;
  p: number;
  m2: number;
  m3: number;
  pmmRatio: number;
}

export interface SkippedColumnEntry {
  story: string;
  label: string;
  uniqueName: string;
  sectionName: string;
  reason: string;
}

export interface ColumnDesignResult {
  success: boolean;
  columns?: ColumnDesignRow[];
  pmmData?: ColumnPmmRow[];
  skippedColumns?: SkippedColumnEntry[];
  error?: string;
}

// ─── Wall Design ──────────────────────────────────────────────────────────────

export interface WallTableDebugEntry {
  headers?: string[];
  rows?: string[][];
  totalRows?: number;
  error?: string;
}

export interface WallTablesResult {
  success: boolean;
  tables?: Record<string, WallTableDebugEntry>;
  error?: string;
}

export interface WallDesignRow {
  no: number;
  story: string;
  pier: string;
  pierLeg: string;
  legX1: number;
  legY1: number;
  legX2: number;
  legY2: number;
  length: number;
  thickness: number;
  height: number;
  concreteMaterial: string;
  fc: number;
  rebarMaterial: string;
  fy: number;
  maxReinfPcent: number;   // required reinforcement percentage (e.g. 0.25 = 0.25%)
  maxShearAv: number;      // required shear Av (mm²/mm)
  groupId: string;         // e.g. "300 / f'c=40MPa"
}

export interface WallGroupSolution {
  groupId: string;
  thickness: number;
  concreteMaterial: string;
  fc: number;
  rebarMaterial: string;
  fy: number;
  story: string;
  pierCount: number;
  maxReinfPcent: number;     // governing required flex % in group+story
  maxShearAv: number;        // governing required shear Av in group+story
  flexDia: number;
  flexSpacing: number;
  flexCurtains: number;
  flexSolution: string;      // e.g. "2×Ø12@150"
  flexProvidedPcent: number; // provided reinforcement %
  shearCurtains: number;
  shearDia: number;
  shearSpacing: number;
  shearSolution: string;     // e.g. "2×Ø10@200"
  shearProvidedAv: number;   // provided Av (mm²/mm)
}

export interface WallDesignResult {
  success: boolean;
  walls?: WallDesignRow[];
  groups?: WallGroupSolution[];
  error?: string;
}

export interface ElectronAPI {
  // ETABS Connection Operations
  getEtabsInstances: () => Promise<{
    success: boolean;
    instances?: EtabsInstance[];
    error?: string
  }>;
  connectToEtabs: (pid: number) => Promise<{
    success: boolean;
    connectedPID?: number;
    error?: string
  }>;
  getConnectionStatus: () => Promise<{
    success: boolean;
    status?: string;
    connectedPID?: number;
    error?: string
  }>;
  startEtabs: (savePath?: string) => Promise<{
    success: boolean;
    pid?: number;
    displayText?: string;
    error?: string
  }>;
  showSaveDialog: (options: {
    title?: string;
    defaultPath?: string;
    filters?: { name: string; extensions: string[] }[];
  }) => Promise<{
    canceled: boolean;
    filePath?: string;
  }>;
  showOpenDialog: (options: {
    title?: string;
    defaultPath?: string;
    properties?: string[];
  }) => Promise<{
    canceled: boolean;
    filePaths?: string[];
  }>;
  // Load ETABS Data Operations
  loadEtabsData: (
    pid: number,
    onProgress?: (progress: LoadingProgress) => void,
    tableNames?: string[] | null
  ) => Promise<{
    success: boolean;
    loadCases?: LoadCaseInfo[];
    tableData?: Record<string, TableData>;
    error?: string;
  }>;

  // Get Selected Points (for Point mode in Seismic Drift)
  getSelectedPoints: (pid: number) => Promise<{
    success: boolean;
    pointLabels?: string[];
    error?: string;
  }>;

  // Base Shear Analysis
  analyzeBaseShear: (pid: number, options: {
    selectedLoadCases: string[];
    requiredLoadCase: string;
    providedLoadCase: string;
  }) => Promise<{
    success: boolean;
    results?: BaseShearScaleFactorResult;
    error?: string;
  }>;

  // Wind Drift Analysis
  analyzeWindDrift: (pid: number, options: {
    selectedLoadCases: string[];
    lowerLimitRatio: number;
    upperLimitRatio: number;
  }) => Promise<{
    success: boolean;
    results?: WindDriftResultRow[];
    error?: string;
  }>;

  // Wind Displacement Analysis
  analyzeWindDisplacement: (pid: number, options: {
    selectedLoadCases: string[];
    allowableRatio: number;
  }) => Promise<{
    success: boolean;
    results?: WindDisplacementResultRow[];
    error?: string;
  }>;

  // Seismic Drift Analysis
  analyzeSeismicDrift: (pid: number, options: {
    selectedLoadCases: string[];
    cdValue: number;
    iValue: number;
    allowableMultiplier: number;
    selectedPointLabels?: string[];
  }) => Promise<{
    success: boolean;
    results?: SeismicDriftResultRow[];
    error?: string;
  }>;

  // Seismic Deflection Analysis
  analyzeSeismicDeflection: (pid: number, options: {
    selectedLoadCases: string[];
    lowerLimitRatio: number;
    upperLimitRatio: number;
  }) => Promise<{
    success: boolean;
    results?: SeismicDeflectionResultRow[];
    error?: string;
  }>;

  // Torsional Irregularity Analysis
  analyzeTorsionalIrregularity: (pid: number, options: {
    selectedLoadCases: string[];
    storyWidths: Record<string, { WidthX: number; WidthY: number }>;
    selectedPointLabels?: string[];
  }) => Promise<{
    success: boolean;
    results?: TorsionalIrregularityResultRow[];
    error?: string;
  }>;

  // Capture ETABS Window
  captureEtabsWindow: (pid: number) => Promise<{
    success: boolean;
    imageBase64?: string;
    error?: string;
  }>;

  // Snip Capture (user draws selection region)
  snipCapture: () => Promise<{
    success: boolean;
    imageBase64?: string;
    cancelled?: boolean;
    error?: string;
  }>;

  // Diaphragm Checks Analysis
  analyzeDiaphragmChecks: (pid: number, options: {
    selectedLoadCases: string[];
  }) => Promise<{
    success: boolean;
    results?: DiaphragmChecksResultRow[];
    error?: string;
  }>;

  // Mass Irregularity Analysis
  analyzeMassIrregularity: (pid: number) => Promise<{
    success: boolean;
    results?: MassIrregularityResultRow[];
    error?: string;
  }>;

  // Stiffness Irregularity Analysis
  analyzeStiffnessIrregularity: (pid: number, options: {
    selectedLoadCases: string[];
  }) => Promise<{
    success: boolean;
    results?: StiffnessIrregularityResultRow[];
    error?: string;
  }>;

  // Wind Drift — Export to Excel
  exportWindDriftExcel: (data: WindDriftResultRow[]) => Promise<{
    success: boolean;
    canceled?: boolean;
    error?: string;
  }>;

  // Wind Drift — Export to Word
  exportWindDriftWord: (data: WindDriftResultRow[]) => Promise<{
    success: boolean;
    canceled?: boolean;
    error?: string;
  }>;

  // Material Definition
  addMaterial: (pid: number, options: {
    matType: string;
    region: string;
    standard: string;
    grade: string;
    userName?: string;
  }) => Promise<{
    success: boolean;
    assignedName?: string;
    error?: string;
  }>;

  getMaterialTable: (pid: number) => Promise<{
    success: boolean;
    fieldNames?: string[];
    totalRows?: number;
    materials?: Array<{
      Name: string;
      Type: string;
      SymType: string;
      Grade: string;
      Color: string;
    }>;
    error?: string;
  }>;

  // Shear Wall Design Analysis
  analyzeShearWall: (pid: number, options: {
    minFlexureDia: number;
    maxFlexureDia: number;
    minShearDia: number;
    maxShearDia: number;
    spacingMultiplier: number;
    selectedCase: number;
  }) => Promise<{
    success: boolean;
    results?: ShearWallResultRow[];
    error?: string;
  }>;

  // Rebar Bar Sizes — ensure required sizes exist in ETABS model
  ensureRebarBarSizes: (pid: number) => Promise<{
    success: boolean;
    barsAdded?: boolean;
    addedCount?: number;
    addedBars?: string[];
    error?: string;
  }>;

  // Rebar Materials — read from ETABS for dropdowns
  getRebarMaterials: (pid: number) => Promise<{
    success: boolean;
    materials?: Array<{ name: string; fy: number }>;
    error?: string;
  }>;

  // Concrete Materials — read from ETABS for dropdowns
  getConcreteMaterials: (pid: number) => Promise<{
    success: boolean;
    materials?: Array<{ name: string; fc: number }>;
    error?: string;
  }>;

  // Wall Design — reads ETABS tables and computes distributed bar solutions
  designWalls: (pid: number) => Promise<WallDesignResult>;
  loadWallTables: (pid: number) => Promise<WallTablesResult>;

  // Column Design — reads ETABS design results and computes bar arrangements
  designColumns: (pid: number) => Promise<ColumnDesignResult>;
  // Column Design State Persistence (4 files: story-s1, story-s2, column-s1, column-s2)
  saveColumnDesignState: (stateKey: string, data: { overrides: Record<string, { flexProv: number; shearProv: number }>; statuses: Record<string, string> }) => Promise<{ success: boolean; error?: string }>;
  loadColumnDesignState: (stateKey: string) => Promise<{ success: boolean; data: { overrides: Record<string, { flexProv: number; shearProv: number }>; statuses: Record<string, string> } | null; error?: string }>;

  // Column Definition — direct ETABS API (SetRectangle + SetRebarColumn + SetModifiers)
  addColumnDefinition: (pid: number, options: ColumnDefinitionOptions) => Promise<ColumnDefinitionResult>;

  // Get Selected Frames — returns ETABS internal names of currently selected frame objects
  getSelectedFrames: (pid: number) => Promise<GetSelectedFramesResult>;

  // Apply Column Properties — create section + assign to frames + set modifiers
  applyColumnProperties: (pid: number, options: ApplyColumnPropertiesOptions) => Promise<ApplyColumnPropertiesResult>;

  // Beam Definition — direct ETABS API (SetRectangle + SetRebarBeam + SetModifiers)
  addBeamDefinition: (pid: number, options: BeamDefinitionOptions) => Promise<BeamDefinitionResult>;

  // Module Cache Operations
  cacheWrite: (moduleId: string, cacheData: ModuleCacheData) => Promise<{ success: boolean; error?: string }>;
  cacheRead: (moduleId: string) => Promise<{ success: boolean; data?: string; parsedData?: ModuleCacheData; error?: string }>;
  cacheList: () => Promise<{ success: boolean; modules?: string[]; error?: string }>;
  cacheClear: (moduleId?: string) => Promise<{ success: boolean; error?: string }>;
  getSessionId: () => Promise<{ success: boolean; sessionId?: string }>;

  // Multi-module Export
  exportMultiExcel: (moduleIds: string[]) => Promise<{ success: boolean; canceled?: boolean; error?: string }>;

  // Independent Windows
  openIndependentWindow: (options: {
    route: string;
    windowParams?: Record<string, any>;
    width?: number;
    height?: number;
    minWidth?: number;
    minHeight?: number;
    title?: string;
  }) => Promise<{ success: boolean; webContentsId?: number; error?: string }>;
  getWindowData: () => Promise<{ success: boolean; data?: any; error?: string }>;
  // Cleanup
  cleanupScanFolder: (options: {
    folderPath: string;
    includeSubfolders: boolean;
    excludedExtensions: string[];
  }) => Promise<{
    success: boolean;
    files: Array<{ name: string; path: string; size: number }>;
    error?: string;
  }>;
  cleanupDeleteFiles: (options: { filePaths: string[] }) => Promise<{
    success: boolean;
    deletedCount: number;
    errors?: string[];
    error?: string;
  }>;
}

// Module Cache Data Structure
export interface ModuleCacheData {
  selectedInstance: EtabsInstance | null;
  loadCases: LoadCaseInfo[];
  uniqueLoadCases?: string[];
  selectedLoadCases: string[];
  parameters: Record<string, any>; // Module-specific (lowerLimit, upperLimit, etc.)
  results: any; // Module-specific (tableData, chartData)
  cachedAt: number;
}

declare global {
  interface Window {
    electronAPI: ElectronAPI;
  }
}
