using System.Collections.Generic;

namespace Backend.PostProceesing.ApplyColumnProperties
{
    public class ApplySectionOptions
    {
        public string       SectionName     { get; set; }
        public string       Material        { get; set; }
        public double       Width           { get; set; }   // mm (T2)
        public double       Depth           { get; set; }   // mm (T3)
        public string       RebarMaterial   { get; set; }   // MatPropLong
        public string       ConfMaterial    { get; set; }   // MatPropConfine
        public double       ClearCover      { get; set; }   // mm
        public int          NW              { get; set; }   // NumberR3Bars (bars along width face)
        public int          ND              { get; set; }   // NumberR2Bars (bars along depth face)
        public string       RebarSize       { get; set; }   // bar size label e.g. "20"
        public double       RebarDiameter   { get; set; }   // mm
        public string       ConfBarSize     { get; set; }   // tie size label e.g. "10"
        public double       ConfBarDiameter { get; set; }   // mm
        public double       ConfSpacing     { get; set; }   // mm
        public double       AMod            { get; set; } = 1.0;
        public double       A2Mod           { get; set; } = 1.0;
        public double       A3Mod           { get; set; } = 1.0;
        public double       JMod            { get; set; } = 0.7;
        public double       I2Mod           { get; set; } = 0.7;
        public double       I3Mod           { get; set; } = 0.7;
        public double       MMod            { get; set; } = 1.0;
        public double       WMod            { get; set; } = 1.0;
        public List<string> UniqueNames     { get; set; }   // frame unique names to assign
    }

    public class ApplyColumnPropertiesOptions
    {
        public List<ApplySectionOptions> Sections { get; set; }
    }
}
