using Backend.Services;
using System;
using System.Collections.Generic;

namespace Backend.PostProceesing.ApplyColumnProperties
{
    public class ApplyColumnPropertiesResult
    {
        public bool   Success         { get; set; }
        public string Message         { get; set; }
        public string Error           { get; set; }
        public int    SectionsApplied { get; set; }
        public int    FramesAssigned  { get; set; }
    }

    public class ApplyColumnPropertiesService
    {
        /// <summary>
        /// For each section in options:
        ///   1. PropFrame.SetRectangle   — create/update section geometry
        ///   2. PropFrame.SetRebarColumn — set rebar configuration (user-chosen solution)
        ///   3. FrameObj.SetSection      — assign section to each frame by uniqueName
        ///   4. FrameObj.SetModifiers    — apply stiffness modifiers to each frame
        ///   5. File.Save
        /// </summary>
        public ApplyColumnPropertiesResult Apply(
            EtabsTableReader reader,
            ApplyColumnPropertiesOptions options)
        {
            try
            {
                var sapModel = reader.SapModel;

                var barSizesTable = reader.ReadTable("Reinforcing Bar Sizes");
                var barSizeLookup = BuildBarSizeLookup(barSizesTable);

                int sectionsApplied = 0;
                int framesAssigned  = 0;

                // Build set of existing section names for quick lookup
                int existingCount = 0;
                string[] existingNames = null;
                sapModel.PropFrame.GetNameList(ref existingCount, ref existingNames);
                var existingSections = new HashSet<string>(
                    existingNames ?? Array.Empty<string>(),
                    StringComparer.OrdinalIgnoreCase);

                foreach (var sec in options.Sections)
                {
                    string rebarName = LookupBarName(barSizeLookup,
                        (int)Math.Round(sec.RebarDiameter), sec.RebarSize);
                    string tieName = LookupBarName(barSizeLookup,
                        (int)Math.Round(sec.ConfBarDiameter), sec.ConfBarSize);

                    bool sectionAlreadyExists = existingSections.Contains(sec.SectionName);

                    if (!sectionAlreadyExists)
                    {
                        // Step 1: Create section geometry
                        int ret = sapModel.PropFrame.SetRectangle(
                            sec.SectionName,
                            sec.Material,
                            sec.Depth,    // T3
                            sec.Width,    // T2
                            -1, "", "Default");
                        if (ret != 0)
                            throw new Exception(
                                $"SetRectangle failed for '{sec.SectionName}' (ret={ret})");

                        // Step 2: Set rebar configuration (ToBeDesigned=false — user chose this solution)
                        ret = sapModel.PropFrame.SetRebarColumn(
                            sec.SectionName,
                            sec.RebarMaterial,
                            sec.ConfMaterial,
                            1,               // Pattern = Rectangular
                            1,               // ConfineType = Ties
                            sec.ClearCover,
                            0,               // NumberCBars (N/A for Rectangular)
                            sec.NW,          // NumberR3Bars
                            sec.ND,          // NumberR2Bars
                            rebarName,
                            tieName,
                            sec.ConfSpacing,
                            3, 3,            // Number2DirTieBars, Number3DirTieBars
                            false);          // ToBeDesigned
                        if (ret != 0)
                            throw new Exception(
                                $"SetRebarColumn failed for '{sec.SectionName}' (ret={ret})");
                    }

                    sectionsApplied++;

                    // Steps 3 & 4: Assign section + modifiers to each frame
                    double[] modValues = {
                        sec.AMod, sec.A2Mod, sec.A3Mod, sec.JMod,
                        sec.I2Mod, sec.I3Mod, sec.MMod, sec.WMod
                    };

                    foreach (var uniqueName in sec.UniqueNames)
                    {
                        int assignRet = sapModel.FrameObj.SetSection(uniqueName, sec.SectionName, 0);
                        if (assignRet != 0)
                            throw new Exception(
                                $"SetSection failed for frame '{uniqueName}' → '{sec.SectionName}' (ret={assignRet})");

                        double[] modCopy = (double[])modValues.Clone();
                        sapModel.FrameObj.SetModifiers(uniqueName, ref modCopy);
                        framesAssigned++;
                    }
                }

                sapModel.File.Save("");

                return new ApplyColumnPropertiesResult
                {
                    Success         = true,
                    SectionsApplied = sectionsApplied,
                    FramesAssigned  = framesAssigned,
                    Message         = $"Applied {sectionsApplied} section(s) to {framesAssigned} frame(s)"
                };
            }
            catch (Exception ex)
            {
                return new ApplyColumnPropertiesResult
                {
                    Success = false,
                    Error   = ex.Message
                };
            }
        }

        private Dictionary<int, string> BuildBarSizeLookup(Models.TableData table)
        {
            var lookup = new Dictionary<int, string>();
            var dict   = table.ToDictionary();
            if (!dict.ContainsKey("Name") || !dict.ContainsKey("Diameter"))
                return lookup;
            var names     = dict["Name"];
            var diameters = dict["Diameter"];
            for (int i = 0; i < names.Count; i++)
            {
                if (double.TryParse(diameters[i], out double d))
                {
                    int di = (int)Math.Round(d);
                    if (!lookup.ContainsKey(di))
                        lookup[di] = names[i];
                }
            }
            return lookup;
        }

        private string LookupBarName(
            Dictionary<int, string> lookup, int diameterMm, string fallbackLabel)
        {
            if (lookup.TryGetValue(diameterMm, out string name)) return name;
            return $"#{fallbackLabel}";
        }
    }
}
