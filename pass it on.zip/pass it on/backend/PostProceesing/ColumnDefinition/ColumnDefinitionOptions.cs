using System;

namespace Backend.PostProceesing.ColumnDefinition
{
    /// <summary>
    /// All inputs needed to call:
    ///   1. cPropFrame.SetRectangle    — section geometry
    ///   2. cPropFrame.SetRebarColumn  — longitudinal + confinement rebar
    ///   3. cFrameObj.SetModifiers     — stiffness modifiers on all objects using this section
    /// Units assumed: mm (model units are forced to N/mm/C before any call).
    /// </summary>
    public class ColumnDefinitionOptions
    {
        // ── cPropFrame.SetRectangle ──────────────────────────────────────────
        public string Name     { get; set; }   // Section name
        public string Material { get; set; }   // Concrete material (MatProp)
        public double Depth    { get; set; }   // T3 — depth in mm
        public double Width    { get; set; }   // T2 — width in mm
        public double Rotation { get; set; } = 0.0;

        // ── cPropFrame.SetRebarColumn ────────────────────────────────────────
        public string RebarMaterial    { get; set; }  // MatPropLong
        public string ConfMaterial     { get; set; }  // MatPropConfine
        public int    Pattern          { get; set; } = 1;   // 1 = Rectangular
        public int    ConfineType      { get; set; } = 1;   // 1 = Ties
        public double ClearCover       { get; set; }  // Cover in mm
        public int    NW               { get; set; }  // NumberR3Bars (includes corners)
        public int    ND               { get; set; }  // NumberR2Bars (includes corners)
        public string RebarSize        { get; set; }  // RebarSize label e.g. "16"
        public double RebarDiameter    { get; set; }  // used for bar size lookup
        public string ConfBarSize      { get; set; }  // TieSize label
        public double ConfBarDiameter  { get; set; }  // used for bar size lookup
        public double ConfSpacing      { get; set; }  // TieSpacingLongit in mm
        public int    Number2DirTieBars{ get; set; } = 3;
        public int    Number3DirTieBars{ get; set; } = 3;
        public bool   ToBeDesigned     { get; set; } = true;

        // ── cFrameObj.SetModifiers — Value[0..7] ─────────────────────────────
        public double AMod  { get; set; } = 1.0;  // [0] cross-section area
        public double A2Mod { get; set; } = 1.0;  // [1] shear area 2
        public double A3Mod { get; set; } = 1.0;  // [2] shear area 3
        public double JMod  { get; set; } = 0.7;  // [3] torsional constant
        public double I2Mod { get; set; } = 0.7;  // [4] moment of inertia 2
        public double I3Mod { get; set; } = 0.7;  // [5] moment of inertia 3
        public double MMod  { get; set; } = 1.0;  // [6] mass
        public double WMod  { get; set; } = 1.0;  // [7] weight
    }
}
