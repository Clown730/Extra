using Backend.Services;
using System;
using System.Collections.Generic;

namespace Backend.PostProceesing.ColumnDefinition
{
    public class ColumnDefinitionResult
    {
        public bool   Success { get; set; }
        public string Message { get; set; }
        public string Error   { get; set; }
    }

    public class ColumnDefinitionService
    {
        /// <summary>
        /// Adds a rectangular column section to ETABS using three direct API calls:
        ///   1. PropFrame.SetRectangle   — creates the section geometry
        ///   2. PropFrame.SetRebarColumn — assigns longitudinal + confinement rebar
        ///   3. FrameObj.SetModifiers    — applies stiffness modifiers to all existing
        ///                                frame objects that use this section name
        /// Units: all lengths in mm (model units are already forced to N/mm/C by EtabsTableReader).
        /// </summary>
        public ColumnDefinitionResult AddColumnDefinition(
            EtabsTableReader reader,
            ColumnDefinitionOptions options)
        {
            try
            {
                ValidateOptions(options);

                var sapModel = reader.SapModel;

                // Look up the exact bar-size names that ETABS expects (e.g. "#16", "@10")
                var barSizesTable  = reader.ReadTable("Reinforcing Bar Sizes");
                var barSizeLookup  = BuildBarSizeLookup(barSizesTable);

                string rebarName = LookupBarName(barSizeLookup, (int)Math.Round(options.RebarDiameter),
                                                 options.RebarSize);
                string tieName   = LookupBarName(barSizeLookup, (int)Math.Round(options.ConfBarDiameter),
                                                 options.ConfBarSize);

                // ── Step 1: SetRectangle ─────────────────────────────────────────────
                // T3 = depth (local 3-dir), T2 = width (local 2-dir), dimensions in mm.
                int ret = sapModel.PropFrame.SetRectangle(
                    options.Name,
                    options.Material,
                    options.Depth,    // T3
                    options.Width,    // T2
                    -1,               // Color: -1 = auto-assign
                    "",               // Notes
                    "Default"         // GUID: "Default" = auto-assign
                );
                if (ret != 0)
                    throw new Exception($"PropFrame.SetRectangle failed (ret={ret}). " +
                                        $"Section='{options.Name}', Mat='{options.Material}', " +
                                        $"Depth={options.Depth}, Width={options.Width}");

                // ── Step 2: SetRebarColumn ───────────────────────────────────────────
                // Pattern=1 (Rectangular), ConfineType=1 (Ties) — both hardcoded.
                // NumberCBars=0 for Pattern=1 (circular count, N/A).
                // NumberR3Bars = nW = bars on each face parallel to local 2-axis (includes corners).
                // NumberR2Bars = nD = bars on each face parallel to local 3-axis (includes corners).
                ret = sapModel.PropFrame.SetRebarColumn(
                    options.Name,
                    options.RebarMaterial,         // MatPropLong
                    options.ConfMaterial,           // MatPropConfine
                    options.Pattern,               // 1 = Rectangular
                    options.ConfineType,           // 1 = Ties
                    options.ClearCover,            // Cover (mm)
                    0,                             // NumberCBars (Pattern=1 → N/A)
                    options.NW,                    // NumberR3Bars
                    options.ND,                    // NumberR2Bars
                    rebarName,                     // RebarSize
                    tieName,                       // TieSize
                    options.ConfSpacing,           // TieSpacingLongit (mm)
                    options.Number2DirTieBars,     // hardcoded 3
                    options.Number3DirTieBars,     // hardcoded 3
                    options.ToBeDesigned           // true = Design, false = Check
                );
                if (ret != 0)
                    throw new Exception($"PropFrame.SetRebarColumn failed (ret={ret}). " +
                                        $"Section='{options.Name}', Long='{options.RebarMaterial}', " +
                                        $"Conf='{options.ConfMaterial}', RebarSize='{rebarName}', " +
                                        $"TieSize='{tieName}'");

                // ── Step 3: SetModifiers ─────────────────────────────────────────────
                // Applies modifier array to all existing frame objects using this section.
                // If no objects exist yet (new project / section not yet assigned), this is a no-op.
                double[] modValues = new double[]
                {
                    options.AMod,   // [0] cross-section area
                    options.A2Mod,  // [1] shear area in local 2-dir
                    options.A3Mod,  // [2] shear area in local 3-dir
                    options.JMod,   // [3] torsional constant
                    options.I2Mod,  // [4] moment of inertia about local 2-axis
                    options.I3Mod,  // [5] moment of inertia about local 3-axis
                    options.MMod,   // [6] mass
                    options.WMod,   // [7] weight
                };
                ApplyModifiersToSection(sapModel, options.Name, modValues);

                // Save model
                sapModel.File.Save("");

                return new ColumnDefinitionResult
                {
                    Success = true,
                    Message = $"Column '{options.Name}' defined: {options.Width}×{options.Depth} mm, " +
                              $"⌀{options.RebarDiameter} {(options.ToBeDesigned ? "design" : "check")}"
                };
            }
            catch (Exception ex)
            {
                return new ColumnDefinitionResult
                {
                    Success = false,
                    Error   = ex.Message
                };
            }
        }

        // ── Helpers ──────────────────────────────────────────────────────────────

        private void ValidateOptions(ColumnDefinitionOptions options)
        {
            if (string.IsNullOrWhiteSpace(options.Name))
                throw new ArgumentException("Column name is required.");
            if (options.Width <= 0 || options.Depth <= 0)
                throw new ArgumentException("Width and Depth must be positive.");
            if (string.IsNullOrWhiteSpace(options.Material))
                throw new ArgumentException("Concrete material is required.");
            if (string.IsNullOrWhiteSpace(options.RebarMaterial))
                throw new ArgumentException("Longitudinal rebar material is required.");
            if (string.IsNullOrWhiteSpace(options.ConfMaterial))
                throw new ArgumentException("Confinement rebar material is required.");
            if (options.NW < 2 || options.ND < 2)
                throw new ArgumentException("NW and ND must each be at least 2.");
            if (options.ClearCover <= 0)
                throw new ArgumentException("Clear cover must be positive.");
        }

        /// <summary>
        /// Builds diameter (int mm) → ETABS bar name (e.g. "#16") lookup from
        /// the "Reinforcing Bar Sizes" table.
        /// </summary>
        private Dictionary<int, string> BuildBarSizeLookup(Models.TableData table)
        {
            var lookup = new Dictionary<int, string>();
            var dict   = table.ToDictionary();

            if (!dict.ContainsKey("Name") || !dict.ContainsKey("Diameter"))
                return lookup;

            var names     = dict["Name"];
            var diameters = dict["Diameter"];

            for (int i = 0; i < names.Count; i++)
            {
                if (double.TryParse(diameters[i], out double d))
                {
                    int di = (int)Math.Round(d);
                    if (!lookup.ContainsKey(di))
                        lookup[di] = names[i];
                }
            }
            return lookup;
        }

        /// <summary>
        /// Returns the ETABS-formatted bar name, falling back to "#&lt;dia&gt;" if not found.
        /// </summary>
        private string LookupBarName(Dictionary<int, string> lookup, int diameterMm, string fallbackLabel)
        {
            if (lookup.TryGetValue(diameterMm, out string name))
                return name;
            // Fallback: prefix with "#" (common ETABS convention)
            return $"#{fallbackLabel}";
        }

        /// <summary>
        /// Finds all FrameObj elements that use <paramref name="sectionName"/> and applies modifiers.
        /// Silently skips if no elements exist yet or if GetNameList fails.
        /// </summary>
        private void ApplyModifiersToSection(CSiAPIv1.cSapModel sapModel, string sectionName, double[] modValues)
        {
            int      numObj = 0;
            string[] frames = null;

            int ret = sapModel.FrameObj.GetNameList(ref numObj, ref frames);
            if (ret != 0 || frames == null || frames.Length == 0)
                return; // no frame objects in model yet — skip silently

            foreach (var frameName in frames)
            {
                try
                {
                    string propName       = "";
                    string saAutoSelected = "";   // ETABS: ref string, not ref bool

                    ret = sapModel.FrameObj.GetSection(frameName, ref propName, ref saAutoSelected);
                    if (ret == 0 && string.Equals(propName, sectionName,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        double[] copy = (double[])modValues.Clone();
                        sapModel.FrameObj.SetModifiers(frameName, ref copy);
                    }
                }
                catch
                {
                    // Skip individual frame failures — don't abort the whole operation
                }
            }
        }
    }
}
