using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using Backend.Services;
using Backend.Models;
using Backend.PostProcessing.BaseShear;
using Backend.PostProcessing.DiaphragmChecks;
using Backend.PostProcessing.WindDrift;
using Backend.PostProcessing.WindDisplacement;
using Backend.PostProcessing.SeismicDrift;
using Backend.PostProcessing.SeismicDeflection;
using Backend.PostProcessing.TorsionalIrregularity;
using Backend.PostProcessing.MassIrregularity;
using Backend.PostProcessing.StiffnessIrregularity;
using Backend.PostProceesing.ColumnDefinition;
using Backend.PostProceesing.BeamDefinition;
using Backend.PostProceesing.ApplyColumnProperties;
using Backend.Design.Detailing.ShearWall;
using Backend.Design.Column;
using Backend.Design.Wall;
using Backend.Export;

namespace Backend
{
    class Program
    {
        private static EtabsInstanceLoader _instanceLoader = new EtabsInstanceLoader();
        private static EtabsConnectionService _connectionService = new EtabsConnectionService();
        private static DataCacheService _cacheService = DataCacheService.Instance;
        private static ModuleCacheService _moduleCacheService = ModuleCacheService.Instance;

        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("Hello from C#! Current time: " + DateTime.Now.ToString());
                return;
            }

            string command = args[0];

            try
            {
                switch (command)
                {
                    case "get-instances":
                        GetEtabsInstances();
                        break;

                    case "connect":
                        if (args.Length > 1 && int.TryParse(args[1], out int pid))
                        {
                            ConnectToEtabs(pid);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "status":
                        GetConnectionStatus();
                        break;

                    case "load-data":
                        if (args.Length > 1 && int.TryParse(args[1], out int loadPid))
                        {
                            // Check if table names are provided (args[2] onwards)
                            string[] tableNames = args.Length > 2 ? args.Skip(2).ToArray() : null;
                            LoadEtabsData(loadPid, tableNames);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "get-selected-points":
                        if (args.Length > 1 && int.TryParse(args[1], out int pointsPid))
                        {
                            GetSelectedPoints(pointsPid);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID", pointLabels = Array.Empty<string>() }));
                        }
                        break;

                    case "analyze-base-shear":
                        if (args.Length > 1 && int.TryParse(args[1], out int analyzePid))
                        {
                            // Parse the JSON payload from args[2]
                            if (args.Length > 2)
                            {
                                AnalyzeBaseShear(analyzePid, args[2]);
                            }
                            else
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing analysis parameters" }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "analyze-diaphragm-checks":
                        if (args.Length > 1 && int.TryParse(args[1], out int diaphragmPid))
                        {
                            // Parse the JSON payload from args[2]
                            if (args.Length > 2)
                            {
                                AnalyzeDiaphragmChecks(diaphragmPid, args[2]);
                            }
                            else
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing analysis parameters" }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "analyze-wind-drift":
                        if (args.Length > 1 && int.TryParse(args[1], out int windDriftPid))
                        {
                            if (args.Length > 2)
                            {
                                AnalyzeWindDrift(windDriftPid, args[2]);
                            }
                            else
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing analysis parameters" }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "analyze-wind-displacement":
                        if (args.Length > 1 && int.TryParse(args[1], out int windDispPid))
                        {
                            if (args.Length > 2)
                            {
                                AnalyzeWindDisplacement(windDispPid, args[2]);
                            }
                            else
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing analysis parameters" }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "analyze-seismic-drift":
                        if (args.Length > 1 && int.TryParse(args[1], out int seismicDriftPid))
                        {
                            if (args.Length > 2)
                            {
                                AnalyzeSeismicDrift(seismicDriftPid, args[2]);
                            }
                            else
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing analysis parameters" }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "analyze-seismic-deflection":
                        if (args.Length > 1 && int.TryParse(args[1], out int seismicDeflPid))
                        {
                            if (args.Length > 2)
                            {
                                AnalyzeSeismicDeflection(seismicDeflPid, args[2]);
                            }
                            else
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing analysis parameters" }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "analyze-torsional-irregularity":
                        if (args.Length > 1 && int.TryParse(args[1], out int torsionalPid))
                        {
                            if (args.Length > 2)
                            {
                                AnalyzeTorsionalIrregularity(torsionalPid, args[2]);
                            }
                            else
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing analysis parameters" }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "analyze-mass-irregularity":
                        if (args.Length > 1 && int.TryParse(args[1], out int massPid))
                        {
                            AnalyzeMassIrregularity(massPid);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "analyze-stiffness-irregularity":
                        if (args.Length > 1 && int.TryParse(args[1], out int stiffnessPid))
                        {
                            if (args.Length > 2)
                            {
                                AnalyzeStiffnessIrregularity(stiffnessPid, args[2]);
                            }
                            else
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing analysis parameters" }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "analyze-shear-wall":
                        if (args.Length > 1 && int.TryParse(args[1], out int shearWallPid))
                        {
                            if (args.Length > 2)
                            {
                                AnalyzeShearWall(shearWallPid, args[2]);
                            }
                            else
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing analysis parameters" }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "design-columns":
                        if (args.Length > 1 && int.TryParse(args[1], out int colDesignPid))
                        {
                            DesignColumns(colDesignPid);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "load-wall-tables":
                        if (args.Length > 1 && int.TryParse(args[1], out int wallTablesPid))
                        {
                            LoadWallTables(wallTablesPid);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "design-walls":
                        if (args.Length > 1 && int.TryParse(args[1], out int wallDesignPid))
                        {
                            DesignWalls(wallDesignPid);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "export-wind-drift-excel":
                        if (args.Length > 2)
                            ExportWindDriftToExcel(args[1], args[2]);
                        else
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing data or file path" }));
                        break;

                    case "export-wind-drift-word":
                        if (args.Length > 2)
                            ExportWindDriftToWord(args[1], args[2]);
                        else
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing data or file path" }));
                        break;

                    case "export-multi-excel":
                        // args: [sessionId, moduleIds (comma-sep), filePath]
                        if (args.Length > 3)
                            ExportMultiToExcel(args[1], args[2].Split(','), args[3]);
                        else
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing sessionId, moduleIds, or file path" }));
                        break;

                    case "start-etabs":
                        string savePath = args.Length > 1 ? args[1] : null;
                        StartNewEtabs(savePath);
                        break;

                    case "capture-screen":
                        var screenCapturer = new EtabsCaptureService();
                        try
                        {
                            string screenBase64 = screenCapturer.CaptureFullScreenAsync().Result;
                            Console.WriteLine(JsonSerializer.Serialize(new { success = true, imageBase64 = screenBase64 }));
                        }
                        catch (AggregateException ae)
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = ae.InnerException?.Message ?? ae.Message }));
                        }
                        break;

                    case "capture-etabs-window":
                        if (args.Length > 1 && int.TryParse(args[1], out int capturePid))
                        {
                            var captureService = new EtabsCaptureService();
                            // Run the async method synchronously using .Result since Main is synchronous here
                            try 
                            {
                                string base64Image = captureService.CaptureActiveViewportAsync(capturePid).Result;
                                Console.WriteLine(JsonSerializer.Serialize(new { success = true, imageBase64 = base64Image }));
                            }
                            catch (AggregateException ae)
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = ae.InnerException?.Message ?? ae.Message }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "add-material":
                        if (args.Length > 1 && int.TryParse(args[1], out int addMatPid))
                        {
                            if (args.Length > 2)
                            {
                                AddMaterial(addMatPid, args[2]);
                            }
                            else
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing material parameters" }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "get-material-table":
                        if (args.Length > 1 && int.TryParse(args[1], out int matTablePid))
                        {
                            GetMaterialTable(matTablePid);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "ensure-rebar-bar-sizes":
                        if (args.Length > 1 && int.TryParse(args[1], out int rebarBarPid))
                        {
                            EnsureRebarBarSizes(rebarBarPid);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "get-rebar-materials":
                        if (args.Length > 1 && int.TryParse(args[1], out int rebarMatPid))
                        {
                            GetRebarMaterials(rebarMatPid);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "get-concrete-materials":
                        if (args.Length > 1 && int.TryParse(args[1], out int concreteMatPid))
                        {
                            GetConcreteMaterials(concreteMatPid);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "get-selected-frames":
                        if (args.Length > 1 && int.TryParse(args[1], out int selFramesPid))
                        {
                            GetSelectedFrames(selFramesPid);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID", frameNames = Array.Empty<string>() }));
                        }
                        break;

                    case "apply-column-props":
                        if (args.Length > 1 && int.TryParse(args[1], out int applyColPid))
                        {
                            var applyPayload = args.Length > 2 ? args[2] : Console.In.ReadToEnd();
                            ApplyColumnProps(applyColPid, applyPayload);
                        }
                        else
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        break;

                    case "add-column-definition":
                        if (args.Length > 1 && int.TryParse(args[1], out int colDefPid))
                        {
                            var colDefPayload = args.Length > 2 ? args[2] : Console.In.ReadToEnd();
                            AddColumnDefinition(colDefPid, colDefPayload);
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "add-beam-definition":
                        if (args.Length > 1 && int.TryParse(args[1], out int beamDefPid))
                        {
                            if (args.Length > 2)
                            {
                                AddBeamDefinition(beamDefPid, args[2]);
                            }
                            else
                            {
                                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing beam definition parameters" }));
                            }
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid PID" }));
                        }
                        break;

                    case "cache-init":
                        InitializeCache();
                        break;

                    case "cache-write":
                        if (args.Length > 3)
                        {
                            WriteCacheData(args[1], args[2], args[3]); // sessionId, moduleId, jsonData
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing cache write parameters" }));
                        }
                        break;

                    case "cache-read":
                        if (args.Length > 2)
                        {
                            ReadCacheData(args[1], args[2]); // sessionId, moduleId
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing parameters" }));
                        }
                        break;

                    case "cache-list":
                        if (args.Length > 1)
                        {
                            ListCachedModules(args[1]); // sessionId
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing session ID" }));
                        }
                        break;

                    case "cache-clear":
                        if (args.Length > 2)
                        {
                            ClearModuleCache(args[1], args[2]); // sessionId, moduleId
                        }
                        else if (args.Length > 1)
                        {
                            ClearAllCache(args[1]); // sessionId - clear entire session
                        }
                        else
                        {
                            Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Missing session ID" }));
                        }
                        break;

                    default:
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Unknown command" }));
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = ex.Message }));
            }
        }

        static void GetEtabsInstances()
        {
            var instances = _instanceLoader.GetEtabsInstances();
            var result = new { success = true, instances = instances };
            Console.WriteLine(JsonSerializer.Serialize(result));
        }

        static void ConnectToEtabs(int pid)
        {
            bool success = _connectionService.ConnectToEtabs(pid, out string errorMessage);

            var result = new
            {
                success = success,
                connectedPID = success ? pid : -1,
                error = success ? null : errorMessage
            };

            Console.WriteLine(JsonSerializer.Serialize(result));
        }

        static void GetConnectionStatus()
        {
            var status = _connectionService.GetConnectionStatus();
            var result = new { success = true, status = status, connectedPID = _connectionService.ConnectedPID };
            Console.WriteLine(JsonSerializer.Serialize(result));
        }

        static void LoadEtabsData(int pid, string[]? requestedTables = null)
        {
            try
            {
                // Progress: Connecting to ETABS
                Console.Error.WriteLine(JsonSerializer.Serialize(new
                {
                    stage = "Connecting to ETABS...",
                    tableName = (string?)null
                }));

                // Connect to ETABS in this process
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"Failed to connect to ETABS: {errorMessage}"
                    }));
                    return;
                }

                // Progress: Reading Load Cases
                Console.Error.WriteLine(JsonSerializer.Serialize(new
                {
                    stage = "Reading Load Cases...",
                    tableName = (string?)null
                }));

                // Read load cases and combinations
                var loadCaseReader = new LoadCaseReader(_connectionService.SapModel);
                var loadCases = loadCaseReader.GetAllLoadCasesAndCombos();

                // Progress: Reading Tables
                Console.Error.WriteLine(JsonSerializer.Serialize(new
                {
                    stage = "Reading ETABS tables...",
                    tableName = (string?)null
                }));

                // Read required tables
                var tableReader = new EtabsTableReader(_connectionService.SapModel);

                // Use requested tables if provided, otherwise use default set
                var tableNames = requestedTables ?? new[] { "Story Definitions", "Story Drifts", "Story Max Over Avg Displacements", "Base Reactions" };

                var tableData = new Dictionary<string, TableData>();

                // Need to ensure "Modal" case is selected for output if querying Modal related tables
                if (tableNames.Contains("Modal Participating Mass Ratios") || tableNames.Contains("Modal Periods And Frequencies"))
                {
                    _connectionService.SapModel.Results.Setup.SetCaseSelectedForOutput("Modal", true);
                }

                foreach (var tableName in tableNames)
                {
                    // Progress: Reading specific table
                    Console.Error.WriteLine(JsonSerializer.Serialize(new
                    {
                        stage = "Reading table...",
                        tableName = tableName
                    }));

                    try
                    {
                        tableData[tableName] = tableReader.ReadTable(tableName);
                    }
                    catch (Exception ex)
                    {
                        Console.Error.WriteLine(JsonSerializer.Serialize(new
                        {
                            warning = $"Failed to read table '{tableName}': {ex.Message}"
                        }));

                        // Add empty table data so the key exists
                        tableData[tableName] = new TableData
                        {
                            FieldNames = Array.Empty<string>(),
                            DataArray = Array.Empty<string>(),
                            NumberOfRecords = 0
                        };
                    }
                }

                // Cache the table data
                _cacheService.StoreData(pid, tableData);

                // Return success with load cases and table data
                var result = new
                {
                    success = true,
                    loadCases = loadCases,
                    tableData = tableData,
                    connectedPID = pid
                };

                Console.WriteLine(JsonSerializer.Serialize(result));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Failed to load ETABS data: {ex.Message}"
                }));
            }
        }

        static void GetSelectedPoints(int pid)
        {
            try
            {
                // Connect to ETABS for this operation
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"Failed to connect to ETABS: {errorMessage}",
                        pointLabels = Array.Empty<string>()
                    }));
                    return;
                }

                var sapModel = _connectionService.SapModel;

                // Get all point names
                int numberNames = 0;
                string[]? pointNames = null;
                int ret = sapModel.PointObj.GetNameList(ref numberNames, ref pointNames);

                if (ret != 0 || pointNames == null || numberNames == 0)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = "Failed to get point names from ETABS",
                        pointLabels = Array.Empty<string>()
                    }));
                    return;
                }

                // Filter to only selected points and get their labels
                var selectedLabels = new List<string>();

                for (int i = 0; i < numberNames; i++)
                {
                    string pointName = pointNames[i];
                    bool isSelected = false;

                    // Check if this point is selected
                    ret = sapModel.PointObj.GetSelected(pointName, ref isSelected);

                    if (ret == 0 && isSelected)
                    {
                        // Get the point label (not the internal name)
                        string label = "";
                        string story = "";
                        ret = sapModel.PointObj.GetLabelFromName(pointName, ref label, ref story);

                        if (ret == 0 && !string.IsNullOrEmpty(label))
                        {
                            selectedLabels.Add(label);
                        }
                    }
                }

                // Remove duplicates and return unique labels
                var uniqueLabels = selectedLabels.Distinct().ToArray();

                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    pointLabels = uniqueLabels
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Error getting selected points: {ex.Message}",
                    pointLabels = Array.Empty<string>()
                }));
            }
        }

        static void GetSelectedFrames(int pid)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"Failed to connect to ETABS: {errorMessage}",
                        frameNames = Array.Empty<string>()
                    }));
                    return;
                }

                var sapModel = _connectionService.SapModel;

                int numberNames = 0;
                string[]? frameNames = null;
                int ret = sapModel.FrameObj.GetNameList(ref numberNames, ref frameNames);

                if (ret != 0 || frameNames == null || numberNames == 0)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = true,
                        frameNames = Array.Empty<string>()
                    }));
                    return;
                }

                var selectedNames = new List<string>();
                for (int i = 0; i < numberNames; i++)
                {
                    string frameName = frameNames[i];
                    bool isSelected = false;
                    ret = sapModel.FrameObj.GetSelected(frameName, ref isSelected);
                    if (ret == 0 && isSelected)
                        selectedNames.Add(frameName);
                }

                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    frameNames = selectedNames.ToArray()
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Error getting selected frames: {ex.Message}",
                    frameNames = Array.Empty<string>()
                }));
            }
        }

        static void AnalyzeBaseShear(int pid, string jsonPayload)
        {
            try
            {
                // Parse the JSON payload
                var options = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(jsonPayload);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                // Extract parameters
                var selectedLoadCases = options.ContainsKey("selectedLoadCases")
                    ? JsonSerializer.Deserialize<List<string>>(options["selectedLoadCases"].GetRawText()) ?? new List<string>()
                    : new List<string>();

                var requiredLoadCase = options.ContainsKey("requiredLoadCase")
                    ? options["requiredLoadCase"].GetString() ?? ""
                    : "";

                var providedLoadCase = options.ContainsKey("providedLoadCase")
                    ? options["providedLoadCase"].GetString() ?? ""
                    : "";

                // Connect to ETABS and read the Base Reactions table
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"Failed to connect to ETABS: {errorMessage}"
                    }));
                    return;
                }

                // Read Base Reactions table
                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData = new Dictionary<string, TableData>();

                try
                {
                    tableData["Base Reactions"] = tableReader.ReadTable("Base Reactions");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"Failed to read Base Reactions table: {ex.Message}"
                    }));
                    return;
                }

                // Create analysis service
                var analysisService = new BaseShearAnalysisService();

                // Calculate results
                var result = analysisService.CalculateScaleFactors(
                    tableData,
                    selectedLoadCases,
                    requiredLoadCase,
                    providedLoadCase
                );

                // Return success with results
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    results = result
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Error analyzing base shear: {ex.Message}"
                }));
            }
        }

        static void AnalyzeDiaphragmChecks(int pid, string jsonPayload)
        {
            try
            {
                // Parse the JSON payload
                var options = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(jsonPayload);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                // Extract parameters
                var selectedLoadCases = options.ContainsKey("selectedLoadCases")
                    ? JsonSerializer.Deserialize<List<string>>(options["selectedLoadCases"].GetRawText()) ?? new List<string>()
                    : new List<string>();

                // Connect to ETABS and read required tables
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"Failed to connect to ETABS: {errorMessage}"
                    }));
                    return;
                }

                // Diaphragm Checks requires Joint Displacements (analysis results).
                // Check that the model has been analyzed (locked) before reading tables.
                // GetTableForDisplayArray returns error code 1 on any table when the model
                // is unlocked — this produces the confusing "Story Definitions" error.
                bool isLocked = _connectionService.SapModel.GetModelIsLocked();
                if (!isLocked)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = "ETABS model has not been analyzed. Please run analysis in ETABS (Analyze > Run Analysis) before using Diaphragm Checks. Joint Displacements data requires a completed analysis."
                    }));
                    return;
                }

                // Read required tables
                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData = new Dictionary<string, TableData>();

                // Read mandatory tables — abort if either fails
                foreach (var tableName in new[] { "Story Definitions", "Joint Displacements" })
                {
                    try
                    {
                        tableData[tableName] = tableReader.ReadTable(tableName);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new
                        {
                            success = false,
                            error = $"Failed to read {tableName} table: {ex.Message}"
                        }));
                        return;
                    }
                }

                // Read joint coordinate table — try "Joint Coordinates" first, then "Point Object Connectivity"
                bool coordTableLoaded = false;
                foreach (var coordTable in new[] { "Joint Coordinates", "Point Object Connectivity" })
                {
                    try
                    {
                        tableData[coordTable] = tableReader.ReadTable(coordTable);
                        coordTableLoaded = true;
                        break;
                    }
                    catch { /* try next name */ }
                }

                if (!coordTableLoaded)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = "Could not read joint coordinate table. Tried 'Joint Coordinates' and 'Point Object Connectivity'. Ensure the ETABS model has point objects defined."
                    }));
                    return;
                }

                // Create analysis service
                var analysisService = new DiaphragmChecksTableService();

                // Calculate results
                var results = analysisService.GenerateDiaphragmChecksTable(
                    tableData,
                    selectedLoadCases
                );

                // Return success with results
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    results = results
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Error analyzing diaphragm checks: {ex.Message}"
                }));
            }
        }

        static void AnalyzeWindDrift(int pid, string jsonPayload)
        {
            try
            {
                var options = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(jsonPayload);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                var selectedLoadCases = options.ContainsKey("selectedLoadCases")
                    ? JsonSerializer.Deserialize<List<string>>(options["selectedLoadCases"].GetRawText()) ?? new List<string>()
                    : new List<string>();

                var lowerLimitRatio = options.ContainsKey("lowerLimitRatio")
                    ? options["lowerLimitRatio"].GetDouble()
                    : 0.001;

                var upperLimitRatio = options.ContainsKey("upperLimitRatio")
                    ? options["upperLimitRatio"].GetDouble()
                    : 0.0025;

                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData = new Dictionary<string, TableData>();

                string[] requiredTables = { "Story Definitions", "Story Drifts" };
                foreach (var tableName in requiredTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read {tableName}: {ex.Message}" }));
                        return;
                    }
                }

                var service = new WindDriftTableService();
                var results = service.GenerateWindDriftTable(tableData, selectedLoadCases, lowerLimitRatio, upperLimitRatio);

                Console.WriteLine(JsonSerializer.Serialize(new { success = true, results = results }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error analyzing wind drift: {ex.Message}" }));
            }
        }

        static void AnalyzeWindDisplacement(int pid, string jsonPayload)
        {
            try
            {
                var options = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(jsonPayload);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                var selectedLoadCases = options.ContainsKey("selectedLoadCases")
                    ? JsonSerializer.Deserialize<List<string>>(options["selectedLoadCases"].GetRawText()) ?? new List<string>()
                    : new List<string>();

                var allowableRatio = options.ContainsKey("allowableRatio")
                    ? options["allowableRatio"].GetDouble()
                    : 600.0;

                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData = new Dictionary<string, TableData>();

                string[] requiredTables = { "Story Definitions", "Story Max Over Avg Displacements" };
                foreach (var tableName in requiredTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read {tableName}: {ex.Message}" }));
                        return;
                    }
                }

                var service = new WindDisplacementTableService();
                var results = service.GenerateWindDisplacementTable(tableData, selectedLoadCases, allowableRatio);

                Console.WriteLine(JsonSerializer.Serialize(new { success = true, results = results }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error analyzing wind displacement: {ex.Message}" }));
            }
        }

        static void AnalyzeSeismicDrift(int pid, string jsonPayload)
        {
            try
            {
                var options = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(jsonPayload);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                var selectedLoadCases = options.ContainsKey("selectedLoadCases")
                    ? JsonSerializer.Deserialize<List<string>>(options["selectedLoadCases"].GetRawText()) ?? new List<string>()
                    : new List<string>();

                var cdValue = options.ContainsKey("cdValue") ? options["cdValue"].GetDouble() : 5.0;
                var iValue = options.ContainsKey("iValue") ? options["iValue"].GetDouble() : 1.0;
                var allowableMultiplier = options.ContainsKey("allowableMultiplier") ? options["allowableMultiplier"].GetDouble() : 0.02;

                var selectedPointLabels = options.ContainsKey("selectedPointLabels")
                    ? JsonSerializer.Deserialize<List<string>>(options["selectedPointLabels"].GetRawText()) ?? new List<string>()
                    : new List<string>();

                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData = new Dictionary<string, TableData>();

                // Always need Story Definitions and Story Drifts
                string[] requiredTables = selectedPointLabels.Count > 0
                    ? new[] { "Story Definitions", "Story Drifts", "Joint Displacements" }
                    : new[] { "Story Definitions", "Story Drifts" };

                foreach (var tableName in requiredTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read {tableName}: {ex.Message}" }));
                        return;
                    }
                }

                var service = new SeismicDriftTableService();
                var results = service.GenerateSeismicDriftTable(
                    tableData, selectedLoadCases, cdValue, iValue, allowableMultiplier,
                    selectedPointLabels.Count > 0 ? selectedPointLabels : null);

                Console.WriteLine(JsonSerializer.Serialize(new { success = true, results = results }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error analyzing seismic drift: {ex.Message}" }));
            }
        }

        static void AnalyzeSeismicDeflection(int pid, string jsonPayload)
        {
            try
            {
                var options = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(jsonPayload);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                var selectedLoadCases = options.ContainsKey("selectedLoadCases")
                    ? JsonSerializer.Deserialize<List<string>>(options["selectedLoadCases"].GetRawText()) ?? new List<string>()
                    : new List<string>();

                var lowerLimitRatio = options.ContainsKey("lowerLimitRatio") ? options["lowerLimitRatio"].GetDouble() : 0.001;
                var upperLimitRatio = options.ContainsKey("upperLimitRatio") ? options["upperLimitRatio"].GetDouble() : 0.0025;

                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData = new Dictionary<string, TableData>();

                string[] requiredTables = { "Story Definitions", "Story Drifts" };
                foreach (var tableName in requiredTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read {tableName}: {ex.Message}" }));
                        return;
                    }
                }

                var service = new SeismicDeflectionTableService();
                var results = service.GenerateSeismicDeflectionTable(tableData, selectedLoadCases, lowerLimitRatio, upperLimitRatio);

                Console.WriteLine(JsonSerializer.Serialize(new { success = true, results = results }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error analyzing seismic deflection: {ex.Message}" }));
            }
        }

        static void AnalyzeTorsionalIrregularity(int pid, string jsonPayload)
        {
            try
            {
                var options = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(jsonPayload);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                var selectedLoadCases = options.ContainsKey("selectedLoadCases")
                    ? JsonSerializer.Deserialize<List<string>>(options["selectedLoadCases"].GetRawText()) ?? new List<string>()
                    : new List<string>();

                var storyWidths = options.ContainsKey("storyWidths")
                    ? JsonSerializer.Deserialize<Dictionary<string, StoryWidthData>>(options["storyWidths"].GetRawText()) ?? new Dictionary<string, StoryWidthData>()
                    : new Dictionary<string, StoryWidthData>();

                var selectedPointLabels = options.ContainsKey("selectedPointLabels")
                    ? JsonSerializer.Deserialize<List<string>>(options["selectedPointLabels"].GetRawText()) ?? new List<string>()
                    : new List<string>();

                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData = new Dictionary<string, TableData>();

                string[] requiredTables = selectedPointLabels.Count > 0
                    ? new[] { "Story Definitions", "Story Max Over Avg Displacements", "Joint Displacements" }
                    : new[] { "Story Definitions", "Story Max Over Avg Displacements" };

                foreach (var tableName in requiredTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read {tableName}: {ex.Message}" }));
                        return;
                    }
                }

                var service = new TorsionalIrregularityTableService();
                var results = service.GenerateTorsionalIrregularityTable(
                    tableData, selectedLoadCases, storyWidths,
                    selectedPointLabels.Count > 0 ? selectedPointLabels : null);

                Console.WriteLine(JsonSerializer.Serialize(new { success = true, results = results }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error analyzing torsional irregularity: {ex.Message}" }));
            }
        }

        static void AnalyzeMassIrregularity(int pid)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData = new Dictionary<string, TableData>();

                string[] requiredTables = { "Story Definitions", "Mass Summary by Story" };
                foreach (var tableName in requiredTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read {tableName}: {ex.Message}" }));
                        return;
                    }
                }

                var service = new MassIrregularityTableService();
                var results = service.GenerateMassIrregularityTable(tableData);

                Console.WriteLine(JsonSerializer.Serialize(new { success = true, results = results }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error analyzing mass irregularity: {ex.Message}" }));
            }
        }

        static void AnalyzeStiffnessIrregularity(int pid, string jsonPayload)
        {
            try
            {
                var options = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(jsonPayload);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                var selectedLoadCases = options.ContainsKey("selectedLoadCases")
                    ? JsonSerializer.Deserialize<List<string>>(options["selectedLoadCases"].GetRawText()) ?? new List<string>()
                    : new List<string>();

                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData = new Dictionary<string, TableData>();

                string[] requiredTables = { "Story Definitions", "Story Stiffness" };
                foreach (var tableName in requiredTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read {tableName}: {ex.Message}" }));
                        return;
                    }
                }

                var service = new StiffnessIrregularityTableService();
                var results = service.GenerateStiffnessIrregularityTable(tableData, selectedLoadCases);

                Console.WriteLine(JsonSerializer.Serialize(new { success = true, results = results }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error analyzing stiffness irregularity: {ex.Message}" }));
            }
        }
        static void DesignWalls(int pid)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData   = new Dictionary<string, TableData>();

                string[] requiredTables = {
                    "Pier Section Properties",
                    "Material Properties - Concrete Data",
                    "Material Properties - Rebar Data",
                };
                string[] optionalTables = {
                    "Shear Wall Pier Design Summary - ACI 318-19",
                };

                foreach (var tableName in requiredTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read {tableName}: {ex.Message}" }));
                        return;
                    }
                }
                foreach (var tableName in optionalTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch { /* optional — skip silently if design not run */ }
                }

                var service  = new WallDesignService();
                var result   = service.ProcessWalls(tableData);
                var camelCase = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
                Console.WriteLine(JsonSerializer.Serialize(result, camelCase));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error designing walls: {ex.Message}" }));
            }
        }

        static void LoadWallTables(int pid)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);

                string[] tableNames = {
                    "Area Assignments - Pier Labels",
                    "Area Assignments - Section Properties",
                    "Area Section Property Definitions - Summary",
                    "Pier Section Properties",
                    "Point Object Connectivity",
                    "Reinforcing Bar Sizes",
                    "Shear Wall Pier Design Summary - ACI 318-19",
                    "Wall Object Connectivity",
                    "Wall Property Definitions - Specified",
                    "Material Properties - Rebar Data",
                    "Material Properties - Concrete Data",
                };

                var tables = new Dictionary<string, object>();
                foreach (var tableName in tableNames)
                {
                    try
                    {
                        var td = tableReader.ReadTable(tableName);
                        var headers = td.FieldNames ?? Array.Empty<string>();
                        var colCount = headers.Length;
                        var rowCount = Math.Min(5, td.NumberOfRecords);
                        var rows = new List<string[]>();
                        for (int ri = 0; ri < rowCount; ri++)
                        {
                            var row = new string[colCount];
                            for (int ci = 0; ci < colCount; ci++)
                                row[ci] = td.DataArray != null && ri * colCount + ci < td.DataArray.Length
                                    ? td.DataArray[ri * colCount + ci]
                                    : "";
                            rows.Add(row);
                        }
                        tables[tableName] = new { headers, rows, totalRows = td.NumberOfRecords };
                    }
                    catch (Exception ex)
                    {
                        tables[tableName] = new { error = ex.Message };
                    }
                }

                Console.WriteLine(JsonSerializer.Serialize(new { success = true, tables }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error loading wall tables: {ex.Message}" }));
            }
        }

        static void ExportWindDriftToExcel(string jsonData, string filePath)
        {
            try
            {
                WindDriftExcelExport.Export(jsonData, filePath);
                Console.WriteLine(JsonSerializer.Serialize(new { success = true }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Excel export failed: {ex.Message}" }));
            }
        }

        static void ExportWindDriftToWord(string jsonData, string filePath)
        {
            try
            {
                WindDriftWordExport.Export(jsonData, filePath);
                Console.WriteLine(JsonSerializer.Serialize(new { success = true }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Word export failed: {ex.Message}" }));
            }
        }

        static void ExportMultiToExcel(string sessionId, string[] moduleIds, string filePath)
        {
            try
            {
                MultiModuleExcelExport.Export(sessionId, moduleIds, filePath);
                Console.WriteLine(JsonSerializer.Serialize(new { success = true }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Excel export failed: {ex.Message}" }));
            }
        }

        static void DesignColumns(int pid)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData   = new Dictionary<string, TableData>();

                string[] requiredTables = {
                    "Frame Section Property Definitions - Concrete Rectangular",
                    "Frame Section Property Definitions - Concrete Column Reinforcing",
                    "Frame Assignments - Section Properties",
                    "Material Properties - Concrete Data",
                    "Material Properties - Rebar Data",
                    "Reinforcing Bar Sizes",
                };
                string[] optionalTables = {
                    "Concrete Column Design Summary - ACI 318-19",
                    "Concrete Column PMM Envelope - ACI 318-19",
                    "Concrete Column Shear Envelope - ACI 318-19",
                };

                foreach (var tableName in requiredTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read {tableName}: {ex.Message}" }));
                        return;
                    }
                }
                foreach (var tableName in optionalTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch { /* optional — skip silently if design not run */ }
                }

                // Build debug snapshot: headers + first 10 rows per table
                var debugTables = new Dictionary<string, object>();
                foreach (var kvp in tableData)
                {
                    var td = kvp.Value;
                    var headers = td.FieldNames ?? Array.Empty<string>();
                    var colCount = headers.Length;
                    var rowCount = Math.Min(10, td.NumberOfRecords);
                    var rows = new List<string[]>();
                    for (int ri = 0; ri < rowCount; ri++)
                    {
                        var row = new string[colCount];
                        for (int ci = 0; ci < colCount; ci++)
                            row[ci] = td.DataArray != null && ri * colCount + ci < td.DataArray.Length
                                ? td.DataArray[ri * colCount + ci]
                                : "";
                        rows.Add(row);
                    }
                    debugTables[kvp.Key] = new { headers, rows, totalRows = td.NumberOfRecords };
                }

                var service = new ColumnDesignService();
                var result  = service.ProcessColumns(tableData);

                // Serialize with camelCase so frontend (result.success, result.columns) works
                var camelCase = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };

                // Attach debug: re-serialize result to camelCase dict, then add debug key
                var resultDict = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(JsonSerializer.Serialize(result, camelCase));
                if (resultDict != null)
                {
                    var withDebug = new Dictionary<string, object>();
                    foreach (var kv in resultDict) withDebug[kv.Key] = kv.Value;
                    withDebug["debug"] = debugTables;
                    Console.WriteLine(JsonSerializer.Serialize(withDebug));
                }
                else
                {
                    Console.WriteLine(JsonSerializer.Serialize(result, camelCase));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error designing columns: {ex.Message}" }));
            }
        }

        static void AnalyzeShearWall(int pid, string jsonPayload)
        {
            try
            {
                var options = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(jsonPayload);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                var parameters = new ShearWallParameters
                {
                    MinFlexureDia = options.ContainsKey("minFlexureDia") ? options["minFlexureDia"].GetInt32() : 12,
                    MaxFlexureDia = options.ContainsKey("maxFlexureDia") ? options["maxFlexureDia"].GetInt32() : 25,
                    MinShearDia = options.ContainsKey("minShearDia") ? options["minShearDia"].GetInt32() : 8,
                    MaxShearDia = options.ContainsKey("maxShearDia") ? options["maxShearDia"].GetInt32() : 12,
                    SpacingMultiplier = options.ContainsKey("spacingMultiplier") ? options["spacingMultiplier"].GetInt32() : 25,
                    SelectedCase = options.ContainsKey("selectedCase") ? options["selectedCase"].GetInt32() : 1
                };

                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var tableData = new Dictionary<string, TableData>();

                string[] requiredTables = { "Shear Wall Pier Design Summary - ACI 318-19" };
                foreach (var tableName in requiredTables)
                {
                    try { tableData[tableName] = tableReader.ReadTable(tableName); }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read {tableName}: {ex.Message}" }));
                        return;
                    }
                }

                var service = new ShearWallReinforcementService();
                var results = service.ProcessShearWalls(tableData, parameters);

                Console.WriteLine(JsonSerializer.Serialize(new { success = true, results = results }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error analyzing shear wall: {ex.Message}" }));
            }
        }
        static void StartNewEtabs(string savePath)
        {
            try
            {
                // Find ETABS installation dynamically — scan for any "ETABS *" folder
                string csiBasePath = @"C:\Program Files\Computers and Structures";
                string etabsExePath = null;

                if (System.IO.Directory.Exists(csiBasePath))
                {
                    var etabsDirs = System.IO.Directory.GetDirectories(csiBasePath, "ETABS *");
                    foreach (var dir in etabsDirs)
                    {
                        string candidate = System.IO.Path.Combine(dir, "ETABS.exe");
                        if (System.IO.File.Exists(candidate))
                        {
                            etabsExePath = candidate;
                            break;
                        }
                    }
                }

                if (etabsExePath == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = "Could not find ETABS installation in C:\\Program Files\\Computers and Structures\\ETABS *"
                    }));
                    return;
                }

                // Snapshot existing ETABS PIDs before creating a new one
                var existingPids = new HashSet<int>();
                foreach (var p in System.Diagnostics.Process.GetProcessesByName("ETABS"))
                {
                    try { existingPids.Add(p.Id); } catch { }
                }

                // Use ETABS COM API to create and start the application
                ETABSv1.cHelper myHelper = new ETABSv1.Helper();
                ETABSv1.cOAPI myETABSObject = myHelper.CreateObject(etabsExePath);

                if (myETABSObject == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = "Failed to create ETABS COM object"
                    }));
                    return;
                }

                int ret = myETABSObject.ApplicationStart();
                if (ret != 0)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"ETABS ApplicationStart failed with code {ret}"
                    }));
                    return;
                }

                // Get SapModel and initialize a new blank model
                ETABSv1.cSapModel mySapModel = myETABSObject.SapModel;

                ret = mySapModel.InitializeNewModel();
                if (ret != 0)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"InitializeNewModel failed with code {ret}"
                    }));
                    return;
                }

                ret = mySapModel.File.NewBlank();
                if (ret != 0)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"NewBlank failed with code {ret}"
                    }));
                    return;
                }

                // Save the model if a path was provided
                if (!string.IsNullOrWhiteSpace(savePath))
                {
                    // Ensure the directory exists
                    string dir = System.IO.Path.GetDirectoryName(savePath);
                    if (!string.IsNullOrEmpty(dir) && !System.IO.Directory.Exists(dir))
                    {
                        System.IO.Directory.CreateDirectory(dir);
                    }

                    ret = mySapModel.File.Save(savePath);
                    if (ret != 0)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new
                        {
                            success = false,
                            error = $"Failed to save model to {savePath} (code {ret})"
                        }));
                        return;
                    }
                }

                // Release COM references
                try
                {
                    Marshal.ReleaseComObject(mySapModel);
                    Marshal.ReleaseComObject(myETABSObject);
                    Marshal.ReleaseComObject(myHelper);
                }
                catch { }
                mySapModel = null;
                myETABSObject = null;
                myHelper = null;

                // Find the COM-created ETABS process (the one NOT in our original snapshot)
                var afterProcesses = System.Diagnostics.Process.GetProcessesByName("ETABS");
                int comPid = -1;
                foreach (var proc in afterProcesses)
                {
                    try
                    {
                        if (!existingPids.Contains(proc.Id))
                        {
                            comPid = proc.Id;
                            break;
                        }
                    }
                    catch { }
                }

                // Kill the COM-created ETABS using taskkill /F for reliability
                if (comPid > 0)
                {
                    var killProcess = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = "taskkill",
                        Arguments = $"/F /PID {comPid}",
                        UseShellExecute = false,
                        CreateNoWindow = true
                    });
                    killProcess?.WaitForExit(10000);

                    // Wait until the process is actually gone
                    for (int i = 0; i < 20; i++)
                    {
                        try
                        {
                            System.Diagnostics.Process.GetProcessById(comPid);
                            System.Threading.Thread.Sleep(500);
                        }
                        catch
                        {
                            break; // Process is gone
                        }
                    }
                }

                // Re-launch ETABS with the saved file (like double-clicking the .edb)
                var etabsProcess = System.Diagnostics.Process.Start(etabsExePath, $"\"{savePath}\"");
                int newPid = etabsProcess?.Id ?? -1;

                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    pid = newPid,
                    displayText = $"New Model (PID: {newPid})"
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Error starting ETABS: {ex.Message}"
                }));
            }
        }

        static void AddMaterial(int pid, string jsonPayload)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"Failed to connect to ETABS: {errorMessage}"
                    }));
                    return;
                }

                var sapModel = _connectionService.SapModel;

                var options = JsonSerializer.Deserialize<JsonElement>(jsonPayload);
                string matTypeStr = options.GetProperty("matType").GetString() ?? "Concrete";
                string region = options.GetProperty("region").GetString() ?? "India";
                string standard = options.GetProperty("standard").GetString() ?? "Indian";
                string grade = options.GetProperty("grade").GetString() ?? "M30";
                string userName = options.TryGetProperty("userName", out var un) ? un.GetString() ?? "" : "";

                // Map matType string to eMatType enum (CSiAPIv1 namespace)
                CSiAPIv1.eMatType matType;
                switch (matTypeStr.ToLower())
                {
                    case "steel": matType = CSiAPIv1.eMatType.Steel; break;
                    case "concrete": matType = CSiAPIv1.eMatType.Concrete; break;
                    case "rebar": matType = CSiAPIv1.eMatType.Rebar; break;
                    case "tendon": matType = CSiAPIv1.eMatType.Tendon; break;
                    case "aluminum": matType = CSiAPIv1.eMatType.Aluminum; break;
                    case "coldformed": matType = CSiAPIv1.eMatType.ColdFormed; break;
                    case "masonry": matType = CSiAPIv1.eMatType.Masonry; break;
                    case "nodesign": matType = CSiAPIv1.eMatType.NoDesign; break;
                    default: matType = CSiAPIv1.eMatType.Concrete; break;
                }

                string assignedName = "";
                int ret = sapModel.PropMaterial.AddMaterial(ref assignedName, matType, region, standard, grade, userName);

                if (ret == 0)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = true,
                        assignedName = assignedName
                    }));
                }
                else
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"AddMaterial failed with code {ret}. Check that Region='{region}', Standard='{standard}', Grade='{grade}' are valid."
                    }));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Error adding material: {ex.Message}"
                }));
            }
        }

        static void GetMaterialTable(int pid)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                TableData tableData;

                try
                {
                    tableData = tableReader.ReadTable("Material Properties - General");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read material table: {ex.Message}" }));
                    return;
                }

                var dict   = tableData.ToDictionary();

                // "Material" is the actual ETABS column name (not "Name")
                var names  = dict.ContainsKey("Material") ? dict["Material"] : (dict.ContainsKey("Name") ? dict["Name"] : new List<string>());
                var types  = dict.ContainsKey("Type")     ? dict["Type"]     : new List<string>();
                var syms   = dict.ContainsKey("SymType")  ? dict["SymType"]  : new List<string>();
                var grades = dict.ContainsKey("Grade")    ? dict["Grade"]    : new List<string>();
                var colors = dict.ContainsKey("Color")    ? dict["Color"]    : new List<string>();

                // NOTE: tableData.NumberOfRecords is the ETABS table *schema version* (e.g. 2),
                // NOT the actual row count. The real row count comes from DataArray.Length / FieldNames.Length,
                // which is what ToDictionary() uses. Use names.Count (derived from DataArray) instead.
                int actualRowCount = names.Count;

                var rows = new List<object>();
                for (int i = 0; i < actualRowCount; i++)
                {
                    rows.Add(new
                    {
                        Name    = i < names.Count  ? names[i]  : "",
                        Type    = i < types.Count  ? types[i]  : "",
                        SymType = i < syms.Count   ? syms[i]   : "",
                        Grade   = i < grades.Count ? grades[i] : "",
                        Color   = i < colors.Count ? colors[i] : "",
                    });
                }

                // Full debug info so frontend can verify
                Console.WriteLine(JsonSerializer.Serialize(new {
                    success        = true,
                    fieldNames     = tableData.FieldNames,
                    schemaVersion  = tableData.NumberOfRecords,  // this is table version, not row count
                    dataArrayLen   = tableData.DataArray.Length,
                    fieldNamesLen  = tableData.FieldNames.Length,
                    totalRows      = actualRowCount,
                    allColumnData  = dict,   // every column with all its values
                    materials      = rows
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error reading material table: {ex.Message}" }));
            }
        }

        static void EnsureRebarBarSizes(int pid)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                TableData tableData;

                try
                {
                    tableData = tableReader.ReadTable("Reinforcing Bar Sizes");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read Reinforcing Bar Sizes table: {ex.Message}" }));
                    return;
                }

                var service = new RebarBarSizeService();
                var result = service.AnalyzeAndPrepare(tableData);

                if (result.BarsAdded)
                {
                    try
                    {
                        tableReader.WriteTable("Reinforcing Bar Sizes", result.FieldNames, result.TotalRows, result.DataArray);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to write bar sizes: {ex.Message}" }));
                        return;
                    }
                }

                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    barsAdded = result.BarsAdded,
                    addedCount = result.AddedCount,
                    addedBars = result.AddedBars,
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error ensuring rebar bar sizes: {ex.Message}" }));
            }
        }

        static void GetRebarMaterials(int pid)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                TableData tableData;

                try
                {
                    tableData = tableReader.ReadTable("Material Properties - Rebar Data");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read rebar material table: {ex.Message}" }));
                    return;
                }

                var dict = tableData.ToDictionary();

                // Column names may vary — try common ones
                var names = dict.ContainsKey("Material") ? dict["Material"] : (dict.ContainsKey("Name") ? dict["Name"] : new List<string>());
                var fyValues = dict.ContainsKey("Fy") ? dict["Fy"] : (dict.ContainsKey("fy") ? dict["fy"] : new List<string>());

                int rowCount = names.Count;
                var materials = new List<object>();

                for (int i = 0; i < rowCount; i++)
                {
                    double fy = 0;
                    if (i < fyValues.Count)
                        double.TryParse(fyValues[i], out fy);

                    materials.Add(new
                    {
                        name = i < names.Count ? names[i] : "",
                        fy = fy,
                    });
                }

                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    fieldNames = tableData.FieldNames,
                    materials = materials,
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error reading rebar materials: {ex.Message}" }));
            }
        }

        static void GetConcreteMaterials(int pid)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                TableData tableData;

                try
                {
                    tableData = tableReader.ReadTable("Material Properties - Concrete Data");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to read concrete material table: {ex.Message}" }));
                    return;
                }

                var dict = tableData.ToDictionary();

                // Column names may vary — try common ones
                var names = dict.ContainsKey("Material") ? dict["Material"] : (dict.ContainsKey("Name") ? dict["Name"] : new List<string>());
                var fcValues = dict.ContainsKey("Fc") ? dict["Fc"] : (dict.ContainsKey("fc") ? dict["fc"] : new List<string>());

                int rowCount = names.Count;
                var materials = new List<object>();

                for (int i = 0; i < rowCount; i++)
                {
                    double fc = 0;
                    if (i < fcValues.Count)
                        double.TryParse(fcValues[i], out fc);

                    materials.Add(new
                    {
                        name = i < names.Count ? names[i] : "",
                        fc = fc,
                    });
                }

                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    fieldNames = tableData.FieldNames,
                    materials = materials,
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error reading concrete materials: {ex.Message}" }));
            }
        }

        static void AddColumnDefinition(int pid, string jsonPayload)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"Failed to connect to ETABS: {errorMessage}"
                    }));
                    return;
                }

                var jsonOptions = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };
                var options = JsonSerializer.Deserialize<ColumnDefinitionOptions>(jsonPayload, jsonOptions);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var service = new ColumnDefinitionService();

                var result = service.AddColumnDefinition(tableReader, options);

                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = result.Success,
                    message = result.Message,
                    error = result.Error
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Error adding column definition: {ex.Message}"
                }));
            }
        }

        static void ApplyColumnProps(int pid, string jsonPayload)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Failed to connect to ETABS: {errorMessage}" }));
                    return;
                }

                var jsonOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var options = JsonSerializer.Deserialize<ApplyColumnPropertiesOptions>(jsonPayload, jsonOptions);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var service = new ApplyColumnPropertiesService();
                var result = service.Apply(tableReader, options);

                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success          = result.Success,
                    message          = result.Message,
                    error            = result.Error,
                    sectionsApplied  = result.SectionsApplied,
                    framesAssigned   = result.FramesAssigned
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = $"Error applying column properties: {ex.Message}" }));
            }
        }

        static void AddBeamDefinition(int pid, string jsonPayload)
        {
            try
            {
                bool connected = _connectionService.ConnectToEtabs(pid, out string errorMessage);
                if (!connected)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new
                    {
                        success = false,
                        error = $"Failed to connect to ETABS: {errorMessage}"
                    }));
                    return;
                }

                var jsonOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var options = JsonSerializer.Deserialize<BeamDefinitionOptions>(jsonPayload, jsonOptions);
                if (options == null)
                {
                    Console.WriteLine(JsonSerializer.Serialize(new { success = false, error = "Invalid JSON payload" }));
                    return;
                }

                var tableReader = new EtabsTableReader(_connectionService.SapModel);
                var service     = new BeamDefinitionService();
                var result      = service.AddBeamDefinition(tableReader, options);

                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = result.Success,
                    message = result.Message,
                    error   = result.Error
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Error adding beam definition: {ex.Message}"
                }));
            }
        }

        // Module Cache Operations

        static void InitializeCache()
        {
            try
            {
                string sessionId = _moduleCacheService.InitSession();
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    sessionId = sessionId
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Failed to initialize cache: {ex.Message}"
                }));
            }
        }

        static void WriteCacheData(string sessionId, string moduleId, string jsonData)
        {
            try
            {
                _moduleCacheService.WriteModuleCache(sessionId, moduleId, jsonData);
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    moduleId = moduleId
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Failed to write cache: {ex.Message}"
                }));
            }
        }

        static void ReadCacheData(string sessionId, string moduleId)
        {
            try
            {
                string data = _moduleCacheService.ReadModuleCache(sessionId, moduleId);
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    moduleId = moduleId,
                    data = data // null if not found
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Failed to read cache: {ex.Message}"
                }));
            }
        }

        static void ListCachedModules(string sessionId)
        {
            try
            {
                var modules = _moduleCacheService.ListCachedModules(sessionId);
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    modules = modules
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Failed to list modules: {ex.Message}"
                }));
            }
        }

        static void ClearModuleCache(string sessionId, string moduleId)
        {
            try
            {
                _moduleCacheService.ClearModuleCache(sessionId, moduleId);
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true,
                    moduleId = moduleId
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Failed to clear module cache: {ex.Message}"
                }));
            }
        }

        static void ClearAllCache(string sessionId)
        {
            try
            {
                _moduleCacheService.ClearSession(sessionId);
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = true
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine(JsonSerializer.Serialize(new
                {
                    success = false,
                    error = $"Failed to clear cache: {ex.Message}"
                }));
            }
        }
    }
}
