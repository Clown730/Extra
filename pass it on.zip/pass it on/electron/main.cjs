const { app, BrowserWindow, ipcMain, dialog, screen, shell } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const os = require('os');
const crypto = require('crypto');
const fs = require('fs');
const { checkForUpdates } = require('./updater.cjs');

// ─── License System ───────────────────────────────────────────────────────────
// Flow:
//   1. App starts with no license → user clicks "Generate Request File"
//      → saves a .req file with their MAC + username → sends it to developer
//   2. Developer runs: node electron/generate-license.cjs request.req
//      → generates encrypted license.lic → sends back to user
//   3. User clicks "Load License File" → selects the .lic → app stores it and starts
//
// SECRET KEY — keep private, never share or commit publicly:
const LICENSE_KEY = 'nW3kR9mP2xL5hQ8vT6yJ4bF1cD7gA0sE'; // 32 chars = 256-bit

// Where the license is stored — C:\Users\<user>\AppData\Local\ETABS Analysis App\license.lic
function getLicensePath() {
  const licenseDir = path.join(app.getPath('appData'), '..', 'Local', app.getName());
  if (!fs.existsSync(licenseDir)) fs.mkdirSync(licenseDir, { recursive: true });
  return path.join(licenseDir, 'license.lic');
}

// Collects this machine's identifying info → written into the .req file
function getMachineInfo() {
  const interfaces = os.networkInterfaces();
  const macs = [];
  for (const iface of Object.values(interfaces)) {
    for (const alias of iface) {
      if (!alias.internal && alias.mac && alias.mac !== '00:00:00:00:00:00') {
        macs.push(alias.mac.toLowerCase());
      }
    }
  }
  macs.sort();
  return {
    macs,
    username: os.userInfo().username,
    hostname: os.hostname(),
    requestedAt: new Date().toISOString(),
  };
}

// Decrypts a .lic file and checks it matches the current machine
function verifyLicense() {
  const licensePath = getLicensePath();
  if (!fs.existsSync(licensePath)) return { valid: false, reason: 'no_file' };

  try {
    const raw = fs.readFileSync(licensePath, 'utf8').trim();
    const buf = Buffer.from(raw, 'base64');
    const iv = buf.subarray(0, 12);
    const authTag = buf.subarray(12, 28);
    const encrypted = buf.subarray(28);
    const key = crypto.scryptSync(LICENSE_KEY, '9e-lic-salt-v1', 32);
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(authTag);
    const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
    const data = JSON.parse(decrypted.toString('utf8'));

    const current = getMachineInfo();
    // License is valid only if MAC and username both match
    const licensedMacs = new Set((data.macs || []).map(m => m.toLowerCase()));
    const macMatch = current.macs.some(mac => licensedMacs.has(mac));
    const userMatch = data.username === current.username;

    if (!macMatch || !userMatch) return { valid: false, reason: 'wrong_machine' };
    return { valid: true };
  } catch {
    return { valid: false, reason: 'invalid_file' };
  }
}

// Full license setup dialog — shown when no valid license is found
async function runLicenseSetup() {
  const { response } = await dialog.showMessageBox({
    type: 'warning',
    title: '9e — License Required',
    message: 'No valid license found for this machine.',
    detail: 'This is private software. You need a license file to continue.\n\n• Generate a request file and send it to the administrator to receive a license.\n• Or load an existing license file if you already have one.',
    buttons: ['Generate Request File', 'Load License File', 'Exit'],
    cancelId: 2,
  });

  if (response === 2) {
    app.exit(0);
    return false;
  }

  if (response === 0) {
    // Generate a .req file with this machine's info
    const machineInfo = getMachineInfo();
    const { filePath, canceled } = await dialog.showSaveDialog({
      title: 'Save License Request File',
      defaultPath: `license-request-${machineInfo.hostname}.req`,
      filters: [{ name: 'License Request', extensions: ['req'] }],
    });

    if (!canceled && filePath) {
      fs.writeFileSync(filePath, JSON.stringify(machineInfo, null, 2), 'utf8');
      await dialog.showMessageBox({
        type: 'info',
        title: '9e — Request File Saved',
        message: 'License request file saved.',
        detail: `Send this file to the administrator:\n${filePath}\n\nThey will send you back a license.lic file.`,
        buttons: ['OK'],
      });
    }
    app.exit(0);
    return false;
  }

  if (response === 1) {
    // User picks the .lic file the developer sent them
    const { filePaths, canceled } = await dialog.showOpenDialog({
      title: 'Select License File',
      filters: [{ name: 'License File', extensions: ['lic'] }],
      properties: ['openFile'],
    });

    if (canceled || !filePaths.length) {
      app.exit(0);
      return false;
    }

    // Copy it to the correct storage location
    const licensePath = getLicensePath();
    fs.copyFileSync(filePaths[0], licensePath);

    // Verify the placed license
    const result = verifyLicense();
    if (result.valid) {
      await dialog.showMessageBox({
        type: 'info',
        title: '9e — License Activated',
        message: 'License activated successfully.',
        detail: 'The application will now start.',
        buttons: ['Continue'],
      });
      return true; // proceed to start the app
    }

    // License didn't pass — remove the bad file and explain
    fs.unlinkSync(licensePath);
    const detail = result.reason === 'wrong_machine'
      ? 'This license was issued for a different machine or user.\nContact the administrator for a license for this device.'
      : 'The license file is corrupted or invalid.\nContact the administrator for a new license.';
    await dialog.showMessageBox({
      type: 'error',
      title: '9e — Invalid License',
      message: 'License verification failed.',
      detail,
      buttons: ['Exit'],
    });
    app.exit(1);
    return false;
  }

  return false;
}
// ─────────────────────────────────────────────────────────────────────────────

let mainWindow;
let sessionId = null;
const windowParamsData = new Map();

// Function to get the backend path
function getBackendPath() {
  if (app.isPackaged) {
    // In production: backend.exe is unpacked from asar to app.asar.unpacked folder
    return path.join(process.resourcesPath, 'app.asar.unpacked', 'electron', 'Backend.exe');
  } else {
    // In development: backend files are copied to electron folder
    return path.join(__dirname, 'Backend.exe');
  }
}

// Create the main window
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
    },
    icon: app.isPackaged
      ? path.join(process.resourcesPath, 'app.asar.unpacked', 'electron', 'logo.ico')
      : path.join(__dirname, 'logo.ico'),
  });

  // Load the app
  if (process.env.NODE_ENV === 'development' || !app.isPackaged) {
    mainWindow.loadURL('http://localhost:8080');
    mainWindow.webContents.openDevTools();
  } else {
    // In production, __dirname is the 'resources/app.asar/electron' or 'resources/app/electron' folder
    // The dist folder is at 'resources/app.asar/dist' or 'resources/app/dist'
    const distPath = path.join(__dirname, '..', 'dist', 'index.html');
    console.log('Loading from:', distPath);
    mainWindow.loadFile(distPath);
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Helper function to call C# backend
function callBackend(command, args = []) {
  return new Promise((resolve, reject) => {
    const backendPath = getBackendPath();
    console.log('Backend path:', backendPath);
    const backendProcess = spawn(backendPath, [command, ...args]);
    let stdout = '';
    let stderr = '';

    backendProcess.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    backendProcess.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    backendProcess.on('close', (code) => {
      if (code !== 0 || stderr) {
        reject(new Error(stderr || `Process exited with code ${code}`));
      } else {
        try {
          const result = JSON.parse(stdout);
          resolve(result);
        } catch (e) {
          reject(new Error('Failed to parse JSON response: ' + stdout));
        }
      }
    });

    backendProcess.on('error', (error) => {
      reject(error);
    });
  });
}

// Like callBackend but writes a large JSON payload via stdin instead of as a CLI arg.
// Avoids ENAMETOOLONG when the payload exceeds the OS command-line length limit.
function callBackendWithStdin(command, args = [], stdinPayload = '') {
  return new Promise((resolve, reject) => {
    const backendPath = getBackendPath();
    const backendProcess = spawn(backendPath, [command, ...args]);
    let stdout = '';
    let stderr = '';

    backendProcess.stdout.on('data', (data) => { stdout += data.toString(); });
    backendProcess.stderr.on('data', (data) => { stderr += data.toString(); });

    backendProcess.on('close', (code) => {
      if (code !== 0 || stderr) {
        reject(new Error(stderr || `Process exited with code ${code}`));
      } else {
        try {
          resolve(JSON.parse(stdout));
        } catch (e) {
          reject(new Error('Failed to parse JSON response: ' + stdout));
        }
      }
    });

    backendProcess.on('error', (error) => { reject(error); });

    // Write payload to stdin then close it so the backend knows input is complete
    backendProcess.stdin.write(stdinPayload, 'utf8');
    backendProcess.stdin.end();
  });
}

// IPC Handler: Get ETABS Instances
ipcMain.handle('get-etabs-instances', async () => {
  try {
    console.log('Getting ETABS instances...');
    const result = await callBackend('get-instances');
    return result;
  } catch (error) {
    console.error('Error getting ETABS instances:', error);
    return {
      success: false,
      error: error.message
    };
  }
});

// IPC Handler: Connect to ETABS
ipcMain.handle('connect-to-etabs', async (event, pid) => {
  try {
    console.log('Connecting to ETABS PID:', pid);
    const result = await callBackend('connect', [pid.toString()]);
    return result;
  } catch (error) {
    console.error('Error connecting to ETABS:', error);
    return {
      success: false,
      error: error.message
    };
  }
});

// IPC Handler: Get Connection Status
ipcMain.handle('get-connection-status', async () => {
  try {
    console.log('Getting connection status...');
    const result = await callBackend('status');
    return result;
  } catch (error) {
    console.error('Error getting connection status:', error);
    return {
      success: false,
      error: error.message
    };
  }
});

// IPC Handler: Load ETABS Data (with progress updates)
ipcMain.handle('load-etabs-data', async (event, pid, tableNames = null) => {
  return new Promise((resolve, reject) => {
    try {
      console.log('Loading ETABS data for PID:', pid);
      console.log('Requested tables:', tableNames);
      const backendPath = getBackendPath();
      console.log('Backend path:', backendPath);

      // Build arguments: ['load-data', pid, ...tableNames]
      const args = ['load-data', pid.toString()];
      if (tableNames && Array.isArray(tableNames) && tableNames.length > 0) {
        args.push(...tableNames);
      }

      const backendProcess = spawn(backendPath, args);
      let stdout = '';
      let stderr = '';

      // Listen to stderr for progress updates
      backendProcess.stderr.on('data', (data) => {
        const progressText = data.toString().trim();
        stderr += progressText + '\n';

        // Try to parse progress JSON
        try {
          const progress = JSON.parse(progressText);
          // Send progress update to renderer
          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('load-etabs-data-progress', progress);
          }
        } catch (e) {
          // Not JSON, just log it
          console.log('Progress:', progressText);
        }
      });

      // Collect stdout for final result
      backendProcess.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      backendProcess.on('close', (code) => {
        if (code !== 0) {
          resolve({
            success: false,
            error: `Process exited with code ${code}: ${stderr}`
          });
        } else {
          try {
            const result = JSON.parse(stdout);
            resolve(result);
          } catch (e) {
            resolve({
              success: false,
              error: 'Failed to parse JSON response: ' + stdout
            });
          }
        }
      });

      backendProcess.on('error', (error) => {
        resolve({
          success: false,
          error: error.message
        });
      });
    } catch (error) {
      console.error('Error loading ETABS data:', error);
      resolve({
        success: false,
        error: error.message
      });
    }
  });
});

// IPC Handler: Get Selected Points (for Point mode in Seismic Drift)
ipcMain.handle('get-selected-points', async (event, pid) => {
  try {
    console.log('Getting selected points for PID:', pid);
    const result = await callBackend('get-selected-points', [pid.toString()]);
    return result;
  } catch (error) {
    console.error('Error getting selected points:', error);
    return {
      success: false,
      error: error.message,
      pointLabels: []
    };
  }
});

// IPC Handler: Analyze Base Shear
ipcMain.handle('analyze-base-shear', async (event, pid, options) => {
  try {
    console.log('Analyzing base shear for PID:', pid);
    console.log('Options:', options);

    // Convert options object to JSON string
    const jsonPayload = JSON.stringify(options);

    const result = await callBackend('analyze-base-shear', [pid.toString(), jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error analyzing base shear:', error);
    return {
      success: false,
      error: error.message
    };
  }
});

// IPC Handler: Analyze Wind Drift
ipcMain.handle('analyze-wind-drift', async (event, pid, options) => {
  try {
    const jsonPayload = JSON.stringify(options);
    const result = await callBackend('analyze-wind-drift', [pid.toString(), jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error analyzing wind drift:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Analyze Wind Displacement
ipcMain.handle('analyze-wind-displacement', async (event, pid, options) => {
  try {
    const jsonPayload = JSON.stringify(options);
    const result = await callBackend('analyze-wind-displacement', [pid.toString(), jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error analyzing wind displacement:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Analyze Seismic Drift
ipcMain.handle('analyze-seismic-drift', async (event, pid, options) => {
  try {
    const jsonPayload = JSON.stringify(options);
    const result = await callBackend('analyze-seismic-drift', [pid.toString(), jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error analyzing seismic drift:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Analyze Seismic Deflection
ipcMain.handle('analyze-seismic-deflection', async (event, pid, options) => {
  try {
    const jsonPayload = JSON.stringify(options);
    const result = await callBackend('analyze-seismic-deflection', [pid.toString(), jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error analyzing seismic deflection:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Analyze Torsional Irregularity
ipcMain.handle('analyze-torsional-irregularity', async (event, pid, options) => {
  try {
    const jsonPayload = JSON.stringify(options);
    const result = await callBackend('analyze-torsional-irregularity', [pid.toString(), jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error analyzing torsional irregularity:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Capture ETABS Window
ipcMain.handle('capture-etabs-window', async (event, pid) => {
  try {
    console.log('Capturing ETABS window for PID:', pid);
    const result = await callBackend('capture-etabs-window', [pid.toString()]);
    return result;
  } catch (error) {
    console.error('Error capturing ETABS window:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Analyze Diaphragm Checks
ipcMain.handle('analyze-diaphragm-checks', async (event, pid, options) => {
  try {
    const jsonPayload = JSON.stringify(options);
    const result = await callBackend('analyze-diaphragm-checks', [pid.toString(), jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error analyzing diaphragm checks:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Analyze Mass Irregularity
ipcMain.handle('analyze-mass-irregularity', async (event, pid) => {
  try {
    const result = await callBackend('analyze-mass-irregularity', [pid.toString()]);
    return result;
  } catch (error) {
    console.error('Error analyzing mass irregularity:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Analyze Stiffness Irregularity
ipcMain.handle('analyze-stiffness-irregularity', async (event, pid, options) => {
  try {
    const jsonPayload = JSON.stringify(options);
    const result = await callBackend('analyze-stiffness-irregularity', [pid.toString(), jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error analyzing stiffness irregularity:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('design-columns', async (_event, pid) => {
  try {
    const result = await callBackend('design-columns', [pid.toString()]);
    return result;
  } catch (error) {
    console.error('Error designing columns:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('design-walls', async (_event, pid) => {
  try {
    const result = await callBackend('design-walls', [pid.toString()]);
    return result;
  } catch (error) {
    console.error('Error designing walls:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('load-wall-tables', async (_event, pid) => {
  try {
    const result = await callBackend('load-wall-tables', [pid.toString()]);
    return result;
  } catch (error) {
    console.error('Error loading wall tables:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('analyze-shear-wall', async (event, pid, options) => {
  try {
    const jsonPayload = JSON.stringify(options);
    const result = await callBackend('analyze-shear-wall', [pid.toString(), jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error analyzing shear wall:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Export Wind Drift to Excel
ipcMain.handle('export-wind-drift-excel', async (event, data) => {
  try {
    const { filePath, canceled } = await dialog.showSaveDialog(mainWindow, {
      title: 'Export Wind Drift — Excel',
      defaultPath: `wind_drift_${Date.now()}.xlsx`,
      filters: [{ name: 'Excel Workbook', extensions: ['xlsx'] }],
    });
    if (canceled || !filePath) return { success: true, canceled: true };

    const jsonPayload = JSON.stringify(data);
    const result = await callBackend('export-wind-drift-excel', [jsonPayload, filePath]);
    return result;
  } catch (error) {
    console.error('Error exporting wind drift to Excel:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Export Wind Drift to Word
ipcMain.handle('export-wind-drift-word', async (event, data) => {
  try {
    const { filePath, canceled } = await dialog.showSaveDialog(mainWindow, {
      title: 'Export Wind Drift — Word',
      defaultPath: `wind_drift_${Date.now()}.docx`,
      filters: [{ name: 'Word Document', extensions: ['docx'] }],
    });
    if (canceled || !filePath) return { success: true, canceled: true };

    const jsonPayload = JSON.stringify(data);
    const result = await callBackend('export-wind-drift-word', [jsonPayload, filePath]);
    return result;
  } catch (error) {
    console.error('Error exporting wind drift to Word:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Start New ETABS Instance
ipcMain.handle('start-etabs', async (event, savePath) => {
  try {
    console.log('Starting new ETABS instance...');
    const args = savePath ? [savePath] : [];
    const result = await callBackend('start-etabs', args);
    return result;
  } catch (error) {
    console.error('Error starting ETABS:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Show Save Dialog
ipcMain.handle('show-save-dialog', async (event, options) => {
  try {
    const result = await dialog.showSaveDialog(mainWindow, options);
    return result;
  } catch (error) {
    console.error('Error showing save dialog:', error);
    return { canceled: true };
  }
});

// IPC Handler: Show Open Dialog (folder picker)
ipcMain.handle('show-open-dialog', async (event, options) => {
  try {
    const result = await dialog.showOpenDialog(mainWindow, options);
    return result;
  } catch (error) {
    console.error('Error showing open dialog:', error);
    return { canceled: true };
  }
});

ipcMain.handle('add-material', async (event, pid, options) => {
  try {
    const jsonPayload = JSON.stringify(options);
    const result = await callBackend('add-material', [pid.toString(), jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error adding material:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-material-table', async (event, pid) => {
  try {
    const result = await callBackend('get-material-table', [pid.toString()]);
    return result;
  } catch (error) {
    console.error('Error getting material table:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('ensure-rebar-bar-sizes', async (event, pid) => {
  try {
    const result = await callBackend('ensure-rebar-bar-sizes', [pid.toString()]);
    return result;
  } catch (error) {
    console.error('Error ensuring rebar bar sizes:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-rebar-materials', async (event, pid) => {
  try {
    const result = await callBackend('get-rebar-materials', [pid.toString()]);
    return result;
  } catch (error) {
    console.error('Error getting rebar materials:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-concrete-materials', async (event, pid) => {
  try {
    const result = await callBackend('get-concrete-materials', [pid.toString()]);
    return result;
  } catch (error) {
    console.error('Error getting concrete materials:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Get Selected Frames from ETABS
ipcMain.handle('get-selected-frames', async (event, pid) => {
  try {
    const result = await callBackend('get-selected-frames', [pid.toString()]);
    return result;
  } catch (error) {
    return { success: false, error: error.message, frameNames: [] };
  }
});

// IPC Handler: Apply Column Properties (SetRectangle + SetRebarColumn + SetSection + SetModifiers)
ipcMain.handle('apply-column-props', async (event, pid, options) => {
  try {
    const result = await callBackendWithStdin('apply-column-props', [pid.toString()], JSON.stringify(options));
    return result;
  } catch (error) {
    return { success: false, error: error.message };
  }
});

// IPC Handler: Add Column Definition
ipcMain.handle('add-column-definition', async (event, pid, options) => {
  try {
    console.log('Adding column definition for PID:', pid);
    const result = await callBackendWithStdin('add-column-definition', [pid.toString()], JSON.stringify(options));
    return result;
  } catch (error) {
    console.error('Error adding column definition:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Add Beam Definition
ipcMain.handle('add-beam-definition', async (event, pid, options) => {
  try {
    console.log('Adding beam definition for PID:', pid);
    const jsonPayload = JSON.stringify(options);
    const result = await callBackend('add-beam-definition', [pid.toString(), jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error adding beam definition:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Export multiple modules to Excel (multi-sheet workbook)
ipcMain.handle('export-multi-excel', async (event, moduleIds) => {
  try {
    if (!sessionId) return { success: false, error: 'Session not initialized' };

    const { filePath, canceled } = await dialog.showSaveDialog(mainWindow, {
      title: 'Export Analysis Results — Excel',
      defaultPath: `analysis_${Date.now()}.xlsx`,
      filters: [{ name: 'Excel Workbook', extensions: ['xlsx'] }],
    });
    if (canceled || !filePath) return { success: true, canceled: true };

    const modulesArg = moduleIds.join(',');
    const result = await callBackend('export-multi-excel', [sessionId, modulesArg, filePath]);
    return result;
  } catch (error) {
    console.error('Error exporting multi-module Excel:', error);
    return { success: false, error: error.message };
  }
});

// Module Cache IPC Handlers
ipcMain.handle('cache-write', async (event, moduleId, cacheData) => {
  try {
    if (!sessionId) {
      return { success: false, error: 'Session not initialized' };
    }
    const jsonPayload = JSON.stringify(cacheData);
    const result = await callBackend('cache-write', [sessionId, moduleId, jsonPayload]);
    return result;
  } catch (error) {
    console.error('Error writing cache:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('cache-read', async (event, moduleId) => {
  try {
    if (!sessionId) {
      return { success: false, error: 'Session not initialized' };
    }
    const result = await callBackend('cache-read', [sessionId, moduleId]);
    if (result.success && result.data) {
      // Parse the JSON data string back to object
      try {
        result.parsedData = JSON.parse(result.data);
      } catch (parseError) {
        console.error('Error parsing cached data:', parseError);
        result.parsedData = null;
      }
    }
    return result;
  } catch (error) {
    console.error('Error reading cache:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('cache-list', async () => {
  try {
    if (!sessionId) {
      return { success: false, error: 'Session not initialized' };
    }
    const result = await callBackend('cache-list', [sessionId]);
    return result;
  } catch (error) {
    console.error('Error listing cache:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('cache-clear', async (event, moduleId = null) => {
  try {
    if (!sessionId) {
      return { success: false, error: 'Session not initialized' };
    }
    const result = moduleId
      ? await callBackend('cache-clear', [sessionId, moduleId])
      : await callBackend('cache-clear', [sessionId]);
    return result;
  } catch (error) {
    console.error('Error clearing cache:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-session-id', async () => {
  return { success: true, sessionId };
});

// Column Design State Persistence — 4 files: story-s1, story-s2, column-s1, column-s2
const columnDesignStateDir = path.join(app.getPath('userData'), 'column-design-state');

ipcMain.handle('column-design:save-state', async (event, stateKey, data) => {
  try {
    if (!fs.existsSync(columnDesignStateDir)) {
      fs.mkdirSync(columnDesignStateDir, { recursive: true });
    }
    const filePath = path.join(columnDesignStateDir, `${stateKey}.json`);
    fs.writeFileSync(filePath, JSON.stringify(data), 'utf8');
    return { success: true };
  } catch (err) {
    console.error('column-design:save-state error:', err);
    return { success: false, error: err.message };
  }
});

ipcMain.handle('column-design:load-state', async (event, stateKey) => {
  try {
    const filePath = path.join(columnDesignStateDir, `${stateKey}.json`);
    if (!fs.existsSync(filePath)) return { success: true, data: null };
    const raw = fs.readFileSync(filePath, 'utf8');
    return { success: true, data: JSON.parse(raw) };
  } catch (err) {
    console.error('column-design:load-state error:', err);
    return { success: false, error: err.message, data: null };
  }
});

// IPC Handler: Cleanup — Scan Folder
ipcMain.handle('cleanup-scan-folder', async (event, { folderPath, includeSubfolders, excludedExtensions }) => {
  try {
    const excludedSet = new Set(
      (excludedExtensions || []).map(e => e.toLowerCase())
    );

    const files = [];

    function scanDir(dirPath) {
      const entries = fs.readdirSync(dirPath, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(dirPath, entry.name);
        if (entry.isDirectory()) {
          if (includeSubfolders) scanDir(fullPath);
        } else if (entry.isFile()) {
          const ext = path.extname(entry.name).toLowerCase();
          // Also handle extensions like ".$et" where extname returns ".$et"
          // Check both the normal extname and the full name suffix for dot-prefixed names
          const extOriginal = path.extname(entry.name);
          if (!excludedSet.has(ext) && !excludedSet.has(extOriginal)) {
            const stat = fs.statSync(fullPath);
            files.push({ name: entry.name, path: fullPath, size: stat.size });
          }
        }
      }
    }

    scanDir(folderPath);
    return { success: true, files };
  } catch (error) {
    console.error('Error scanning folder:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Cleanup — Delete Files (move to Recycle Bin)
ipcMain.handle('cleanup-delete-files', async (event, { filePaths }) => {
  try {
    let deletedCount = 0;
    const errors = [];
    for (const filePath of filePaths) {
      try {
        await shell.trashItem(filePath);
        deletedCount++;
      } catch (err) {
        errors.push(`${path.basename(filePath)}: ${err.message}`);
      }
    }
    if (errors.length > 0 && deletedCount === 0) {
      return { success: false, error: errors.join('; ') };
    }
    return { success: true, deletedCount, errors };
  } catch (error) {
    console.error('Error deleting files:', error);
    return { success: false, error: error.message };
  }
});

// IPC Handler: Snip Capture (user draws selection on screen)
ipcMain.handle('snip-capture', async () => {
  const primaryDisplay = screen.getPrimaryDisplay();
  const { width, height } = primaryDisplay.size;
  const { x, y } = primaryDisplay.bounds;

  // Save main window state before hiding so we can restore it exactly
  const prevBounds = mainWindow ? mainWindow.getBounds() : null;
  const prevMaximized = mainWindow ? mainWindow.isMaximized() : false;

  // Minimize (not hide) — less disruptive to Windows display compositing
  if (mainWindow) mainWindow.minimize();
  await new Promise(r => setTimeout(r, 350));

  // Take screenshot via C# backend
  let screenshotDataUrl = null;
  try {
    const result = await callBackend('capture-screen');
    if (!result.success) throw new Error(result.error || 'Unknown error');
    screenshotDataUrl = result.imageBase64;
  } catch (err) {
    console.error('capture-screen failed:', err);
    if (mainWindow) { if (prevMaximized) { mainWindow.maximize(); } else { if (prevBounds) mainWindow.setBounds(prevBounds); mainWindow.restore(); } }
    return { success: false, error: 'Screenshot failed: ' + err.message };
  }

  // show:false — window is hidden until snip.html signals it's ready to display
  let snipWindow = new BrowserWindow({
    width, height, x, y,
    show: false,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    resizable: false,
    movable: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    }
  });

  snipWindow.loadFile(path.join(__dirname, 'snip.html'));

  // Send screenshot once loaded; snip.html will call 'snip-ready' when canvas is painted
  snipWindow.webContents.once('did-finish-load', () => {
    snipWindow.webContents.send('screenshot', { dataUrl: screenshotDataUrl, width, height });
  });

  // Show the snip window only after snip.html has drawn the screenshot on canvas
  ipcMain.once('snip-ready', () => {
    if (snipWindow && !snipWindow.isDestroyed()) snipWindow.show();
  });

  return new Promise((resolve) => {
    let settled = false;

    const finish = (result) => {
      if (settled) return;
      settled = true;
      ipcMain.removeListener('snip-region-selected', onSelected);
      ipcMain.removeListener('snip-cancelled', onCancelled);
      resolve(result);
      if (snipWindow && !snipWindow.isDestroyed()) snipWindow.close();
      snipWindow = null;
      ipcMain.removeListener('snip-ready', () => {});
      if (mainWindow) {
        if (prevMaximized) {
          mainWindow.maximize();
        } else {
          if (prevBounds) mainWindow.setBounds(prevBounds);
          mainWindow.restore();
        }
      }
    };

    const onSelected = (_evt, dataUrl) => finish({ success: true, imageBase64: dataUrl });
    const onCancelled = () => finish({ success: false, cancelled: true });

    ipcMain.once('snip-region-selected', onSelected);
    ipcMain.once('snip-cancelled', onCancelled);
    snipWindow.once('closed', () => finish({ success: false, cancelled: true }));
  });
});

// IPC Handler: Open Independent Window
ipcMain.handle('open-independent-window', async (event, options) => {
  const { route, windowParams, width = 1000, height = 700, minWidth = 800, minHeight = 500, title = '9e Analysis' } = options;
  
  const newWin = new BrowserWindow({
    width,
    height,
    minWidth,
    minHeight,
    title,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
    },
    icon: app.isPackaged
      ? path.join(process.resourcesPath, 'app.asar.unpacked', 'electron', 'logo.ico')
      : path.join(__dirname, 'logo.ico'),
  });

  newWin.setMenu(null);

  const newWinWebContentsId = newWin.webContents.id;
  windowParamsData.set(newWinWebContentsId, windowParams);

  newWin.on('closed', () => {
    windowParamsData.delete(newWinWebContentsId);
  });

  const targetUrl = app.isPackaged
    ? `file://${path.join(__dirname, '..', 'dist', 'index.html')}#/window/${route}`
    : `http://localhost:8080/#/window/${route}`;

  newWin.loadURL(targetUrl);
  
  return { success: true, webContentsId: newWin.webContents.id };
});

// IPC Handler: Get Window Data
ipcMain.handle('get-window-data', (event) => {
  const data = windowParamsData.get(event.sender.id) || null;
  return { success: true, data };
});

// App lifecycle
app.whenReady().then(async () => {
  // License check
  const licenseResult = verifyLicense();
  if (!licenseResult.valid) {
    const ok = await runLicenseSetup();
    if (!ok) return;
  }

  // Update check — runs after license, before any window is created
  await checkForUpdates();

  // Initialize cache session
  try {
    const result = await callBackend('cache-init');
    if (result.success) {
      sessionId = result.sessionId;
      console.log('Cache session initialized:', sessionId);
    } else {
      console.error('Failed to initialize cache:', result.error);
    }
  } catch (error) {
    console.error('Error initializing cache:', error);
  }

  createWindow();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Clean up cache on app quit
app.on('before-quit', async (event) => {
  if (sessionId) {
    event.preventDefault();
    try {
      await callBackend('cache-clear');
      console.log('Cache cleared on quit');
    } catch (error) {
      console.error('Error clearing cache on quit:', error);
    } finally {
      sessionId = null;
      app.exit(0);
    }
  }
});
