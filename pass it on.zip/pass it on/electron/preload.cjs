const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electronAPI', {
  // ETABS Connection Operations
  getEtabsInstances: () => ipcRenderer.invoke('get-etabs-instances'),
  connectToEtabs: (pid) => ipcRenderer.invoke('connect-to-etabs', pid),
  getConnectionStatus: () => ipcRenderer.invoke('get-connection-status'),
  startEtabs: (savePath) => ipcRenderer.invoke('start-etabs', savePath),
  showSaveDialog: (options) => ipcRenderer.invoke('show-save-dialog', options),
  showOpenDialog: (options) => ipcRenderer.invoke('show-open-dialog', options),

  // Load ETABS Data with Progress
  loadEtabsData: (pid, onProgress, tableNames = null) => {
    // Set up progress listener
    if (onProgress) {
      const progressHandler = (event, progress) => {
        onProgress(progress);
      };
      ipcRenderer.on('load-etabs-data-progress', progressHandler);

      // Return promise that cleans up listener when done
      return ipcRenderer.invoke('load-etabs-data', pid, tableNames).finally(() => {
        ipcRenderer.removeListener('load-etabs-data-progress', progressHandler);
      });
    }

    return ipcRenderer.invoke('load-etabs-data', pid, tableNames);
  },

  // Get Selected Points (for Point mode in Seismic Drift)
  getSelectedPoints: (pid) => ipcRenderer.invoke('get-selected-points', pid),

  // Base Shear Analysis
  analyzeBaseShear: (pid, options) => ipcRenderer.invoke('analyze-base-shear', pid, options),

  // Wind Drift Analysis
  analyzeWindDrift: (pid, options) => ipcRenderer.invoke('analyze-wind-drift', pid, options),

  // Wind Displacement Analysis
  analyzeWindDisplacement: (pid, options) => ipcRenderer.invoke('analyze-wind-displacement', pid, options),

  // Seismic Drift Analysis
  analyzeSeismicDrift: (pid, options) => ipcRenderer.invoke('analyze-seismic-drift', pid, options),

  // Seismic Deflection Analysis
  analyzeSeismicDeflection: (pid, options) => ipcRenderer.invoke('analyze-seismic-deflection', pid, options),

  // Torsional Irregularity Analysis
  analyzeTorsionalIrregularity: (pid, options) => ipcRenderer.invoke('analyze-torsional-irregularity', pid, options),

  // Capture ETABS Window
  captureEtabsWindow: (pid) => ipcRenderer.invoke('capture-etabs-window', pid),

  // Snip Capture (user draws selection region)
  snipCapture: () => ipcRenderer.invoke('snip-capture'),

  // Diaphragm Checks Analysis
  analyzeDiaphragmChecks: (pid, options) => ipcRenderer.invoke('analyze-diaphragm-checks', pid, options),

  // Mass Irregularity Analysis
  analyzeMassIrregularity: (pid) => ipcRenderer.invoke('analyze-mass-irregularity', pid),

  // Stiffness Irregularity Analysis
  analyzeStiffnessIrregularity: (pid, options) => ipcRenderer.invoke('analyze-stiffness-irregularity', pid, options),

  // Column Design
  designColumns: (pid) => ipcRenderer.invoke('design-columns', pid),
  saveColumnDesignState: (stateKey, data) => ipcRenderer.invoke('column-design:save-state', stateKey, data),
  loadColumnDesignState: (stateKey) => ipcRenderer.invoke('column-design:load-state', stateKey),

  // Wall Design
  designWalls: (pid) => ipcRenderer.invoke('design-walls', pid),
  loadWallTables: (pid) => ipcRenderer.invoke('load-wall-tables', pid),

  // Shear Wall Design Analysis
  analyzeShearWall: (pid, options) => ipcRenderer.invoke('analyze-shear-wall', pid, options),

  // Wind Drift Export
  exportWindDriftExcel: (data) => ipcRenderer.invoke('export-wind-drift-excel', data),
  exportWindDriftWord:  (data) => ipcRenderer.invoke('export-wind-drift-word',  data),

  // Material Definition
  addMaterial: (pid, options) => ipcRenderer.invoke('add-material', pid, options),
  getMaterialTable: (pid) => ipcRenderer.invoke('get-material-table', pid),

  // Rebar Bar Sizes & Materials
  ensureRebarBarSizes: (pid) => ipcRenderer.invoke('ensure-rebar-bar-sizes', pid),
  getRebarMaterials: (pid) => ipcRenderer.invoke('get-rebar-materials', pid),
  getConcreteMaterials: (pid) => ipcRenderer.invoke('get-concrete-materials', pid),

  // Column Definition
  addColumnDefinition: (pid, options) => ipcRenderer.invoke('add-column-definition', pid, options),

  // Get Selected Frames from ETABS (FrameObj.GetSelected)
  getSelectedFrames: (pid) => ipcRenderer.invoke('get-selected-frames', pid),

  // Apply Column Properties (SetRectangle + SetRebarColumn + SetSection + SetModifiers)
  applyColumnProperties: (pid, options) => ipcRenderer.invoke('apply-column-props', pid, options),

  // Beam Definition
  addBeamDefinition: (pid, options) => ipcRenderer.invoke('add-beam-definition', pid, options),

  // Module Cache Operations
  cacheWrite: (moduleId, cacheData) => ipcRenderer.invoke('cache-write', moduleId, cacheData),
  cacheRead: (moduleId) => ipcRenderer.invoke('cache-read', moduleId),
  cacheList: () => ipcRenderer.invoke('cache-list'),
  cacheClear: (moduleId = null) => ipcRenderer.invoke('cache-clear', moduleId),
  getSessionId: () => ipcRenderer.invoke('get-session-id'),

  // Multi-module Export
  exportMultiExcel: (moduleIds) => ipcRenderer.invoke('export-multi-excel', moduleIds),

  // Cleanup
  cleanupScanFolder: (options) => ipcRenderer.invoke('cleanup-scan-folder', options),
  cleanupDeleteFiles: (options) => ipcRenderer.invoke('cleanup-delete-files', options),

  // Independent Windows
  openIndependentWindow: (options) => ipcRenderer.invoke('open-independent-window', options),
  getWindowData: () => ipcRenderer.invoke('get-window-data'),
});
